#!/usr/bin/env python3
"""Source-level structural guard for compact homepage and gear button.
Live rendering must still be checked by Android emulator before final release.
"""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
activity=(root/'app/src/main/java/com/decor/clientmanager/MainActivity.java').read_text()
icons=(root/'app/src/main/java/com/decor/clientmanager/UiIcon.java').read_text()

assert 'final int heroHeight=fontIndex==3?177:fontIndex==2?155:fontIndex==1?128:118;' in activity, 'Welcome area height must fit compact home layout'
assert '今日工作安排' not in activity.split('private void homeHero()')[1].split('private LinearLayout homeReminderTile(')[0], 'Schedule should not be drawn over living-room photo'
assert 'private void homeQuickAdd()' in activity, 'Persistent add-client action missing'
assert 'root.addView(dock,root.getChildCount()-1' in activity, 'Add-client action must be docked above bottom navigation'
assert 'homeQuickAdd();' in activity, 'Home does not mount persistent add-client action'
assert 'homeReminderTile(task)' in activity, 'Homepage reminder cards should be compact'
assert 'softButton("＋ 添加提醒"' not in activity.split('private void showHome()')[1].split('private void showMonthSignedClients')[0], 'Duplicate homepage add-reminder button'
assert 'softButton("全部提醒' not in activity.split('private void showHome()')[1].split('private void showMonthSignedClients')[0], 'Duplicate all-reminders button'
assert 'body.addView(button("＋ 新增客户"' not in activity.split('private void showHome()')[1].split('private void showMonthSignedClients')[0], 'Old scrolled add-client button still present'
assert 'new FrameLayout.LayoutParams(dp(22),dp(22),Gravity.CENTER)' in activity, 'Gear artwork not constrained inside tap target'
assert 'titleRow.addView(settingsHit,lp(44,44))' in activity, 'Gear tap target missing'
assert 'case "settings":' in icons and 'case "settings": circle(12,12,4);circle(12,12,9);' not in icons, 'Settings glyph is still target, not gear'
print('PASS: compact hero, persistent add-client action, gear art/touch target')
