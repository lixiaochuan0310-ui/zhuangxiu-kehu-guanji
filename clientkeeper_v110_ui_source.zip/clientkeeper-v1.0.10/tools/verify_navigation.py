from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'app/src/main/java/com/decor/clientmanager/MainActivity.java').read_text()
d=(root/'app/src/main/java/com/decor/clientmanager/Db.java').read_text()
checks=['metricGrid(','showMonthSignedClients(','showMonthReceipts(','showPickReminderClient(','showTaskDetail(','showFollowForm(','showTaskForm(','showSourceStatistics(','onBackPressed()','button("＋ 添加提醒"','setOnClickListener(v->showTaskDetail(t.id))','showClients("",null,"高意向")']
for check in checks:assert check in s,check
for check in ['updateTask(','reopenTask(','deleteTask(','updateFollow(','deleteFollow(']:assert check in d,check
print('PASS 页面导航：指标钻取、提醒增改删/恢复、沟通修改、来源统计')
