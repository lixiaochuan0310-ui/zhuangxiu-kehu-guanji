#!/usr/bin/env python3
"""V1.0.6 offline regressions; tests JDK business rules, Java syntax, SQL, manifests and security guards.
Cannot replace Android SDK compilation, emulator or device tests.
"""
from pathlib import Path
import re,sqlite3,subprocess,tempfile,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'app/src/main/java/com/decor/clientmanager'
main=(SRC/'MainActivity.java').read_text()
db_code=(SRC/'Db.java').read_text()
transfer=(SRC/'Transfer.java').read_text()
assert 'out.putString("pending_file_operation",fileOperation)' in main
assert 'fileOperation=b.getString("pending_file_operation","")' in main
assert 'if(!"backup".equals(op)&&!"xlsx".equals(op)&&!"restore".equals(op)&&!"import_xlsx".equals(op))' in main
assert 'else if("backup".equals(operation))Transfer.backup(db,out)' in main
assert '"wt"' in main
assert 'savedClientScrollY' in main and 'restoreClientPosition' in main
assert 'clientsPage(' in main and 'clientsPage(' in db_code
assert 'homePriorityTasks(3,' in main and 'LIMIT ?' in db_code
assert 'tasksPage(' in main and 'tasksPage(' in db_code
assert 'SourcePalette.color(i)' in main and 'SourcePalette.color(i)' in (SRC/'SourceDonutView.java').read_text()
assert 'if(date1904)' not in transfer # workbook metadata is passed to pure helper instead
assert 'ExcelDates.parse(acquiredValue,use1904)' in transfer
assert 'CLIENTKEEPER_KEYSTORE_PASSWORD' in (ROOT/'app/build.gradle').read_text()
assert 'app-release.apk' in (ROOT/'.github/workflows/build-apk.yml').read_text()
assert 'android.permission.INTERNET' not in (ROOT/'app/src/main/AndroidManifest.xml').read_text()
for x in (ROOT/'app/src/main').rglob('*.xml'): ET.parse(x)
with tempfile.TemporaryDirectory() as d:
    files=[str(p) for p in SRC.glob('*.java')]
    subprocess.run(['javac','-encoding','UTF-8','-d',d,str(ROOT/'tools/SyntaxAudit.java')],check=True,capture_output=True)
    subprocess.run(['java','-cp',d,'SyntaxAudit',*files,str(ROOT/'tools/CoreRulesTest.java')],check=True)
    subprocess.run(['javac','-encoding','UTF-8','-d',d,*[str(SRC/x) for x in ['Money.java','PhoneKey.java','ExcelDates.java','ExcelCellNumber.java','CommissionRule.java','ReminderPriority.java']],str(ROOT/'tools/CoreRulesTest.java'),str(ROOT/'tools/ReminderPriorityTest.java')],check=True)
    subprocess.run(['java','-cp',d,'com.decor.clientmanager.CoreRulesTest'],check=True)
    subprocess.run(['java','-cp',d,'com.decor.clientmanager.ReminderPriorityTest'],check=True)
# schema from actual Db constants
schema={name:re.search(r'static final String '+name+r'="([^"]+)";',db_code).group(1) for name in ['CLIENT_TABLE','CONTRACT_TABLE','RECEIPT_TABLE']}
conn=sqlite3.connect(':memory:');conn.execute('PRAGMA foreign_keys=ON')
conn.execute(schema['CLIENT_TABLE'])
conn.execute('CREATE TABLE reminders (id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,due_at INTEGER NOT NULL,content TEXT NOT NULL DEFAULT \'\',status TEXT NOT NULL DEFAULT \'pending\' CHECK(status IN (\'pending\',\'done\')))')
conn.execute(schema['CONTRACT_TABLE']);conn.execute(schema['RECEIPT_TABLE'])
conn.execute('CREATE INDEX idx_reminder_due ON reminders(status,due_at)')
with conn:
    for i in range(1000):
        conn.execute('INSERT INTO clients(name,created_at,updated_at,acquired_at,intent) VALUES (?,?,?,?,?)',(f'客户{i}',1,i,1,['高意向','一般意向','低意向','待判断'][i%4]))
        if i<900:
            conn.execute('INSERT INTO reminders(client_id,due_at,content) VALUES (?,?,?)',(i+1,100+(i//4),f'提醒{i}'))
    conn.execute("INSERT INTO contracts(client_id,signed_at,amount,commission_type,commission_rate,fixed_commission) VALUES (1,10000,101,'percent',2.5,0)")
    conn.execute("INSERT INTO contracts(client_id,signed_at,amount,commission_type,commission_rate,fixed_commission) VALUES (1,10000,3000,'fixed',0,500)")
    conn.execute("INSERT INTO receipts(contract_id,received_at,amount) VALUES (1,11000,1.01)")
    conn.execute("INSERT INTO receipts(contract_id,received_at,amount) VALUES (1,11001,1.01)")
assert conn.execute('SELECT COUNT(*) FROM clients').fetchone()[0]==1000
assert conn.execute('SELECT COUNT(*) FROM reminders').fetchone()[0]==900
assert conn.execute('SELECT COUNT(*) FROM clients WHERE name LIKE ? ORDER BY updated_at DESC LIMIT 60 OFFSET 0',('%客户%',)).fetchall() is not None
# SQL order matches priority: same due time -> high, medium, low, unknown
result=conn.execute("SELECT c.intent,r.due_at FROM reminders r JOIN clients c ON c.id=r.client_id WHERE r.status='pending' AND r.due_at<200 ORDER BY r.due_at, CASE c.intent WHEN '高意向' THEN 0 WHEN '一般意向' THEN 1 WHEN '低意向' THEN 2 ELSE 3 END,r.id LIMIT 4").fetchall()
assert [x[0] for x in result]==['高意向','一般意向','低意向','待判断'], result
assert conn.execute('SELECT COUNT(DISTINCT client_id) FROM contracts').fetchone()[0]==1
assert conn.execute('SELECT SUM(amount) FROM receipts').fetchone()[0]==2.02
# rollback simulation: malformed child is rejected without deleting original data
try:
    with conn:
        conn.execute('DELETE FROM receipts');conn.execute('DELETE FROM contracts')
        conn.execute("INSERT INTO receipts(contract_id,received_at,amount) VALUES (999999,1,1)")
except sqlite3.IntegrityError:
    pass
assert conn.execute('SELECT COUNT(*) FROM contracts').fetchone()[0]==2
assert conn.execute('SELECT COUNT(*) FROM receipts').fetchone()[0]==2
with conn: conn.execute('DELETE FROM clients WHERE id=1')
assert conn.execute('SELECT COUNT(*) FROM contracts').fetchone()[0]==0
assert conn.execute('SELECT COUNT(*) FROM receipts').fetchone()[0]==0
assert conn.execute('SELECT COUNT(*) FROM reminders WHERE client_id=1').fetchone()[0]==0
print('V1.0.6 checks PASS: JDK syntax/business tests, 1000 clients/900 reminders SQL, FK rollback, filters, file routing, visuals and signing settings')
