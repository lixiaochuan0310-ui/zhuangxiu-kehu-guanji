from pathlib import Path
p=Path(__file__).resolve().parents[1]
s=(p/'app/src/main/java/com/decor/clientmanager/MainActivity.java').read_text()
assert (p/'app/src/main/java/com/decor/clientmanager/UiIcon.java').exists()
for x in ('showHome()','showSourceChoices(','sourceChoiceIcon(','更新业务进展','更新客户意向','改变','客户来源','高意向','待判断','showContractForm(','showReceiptForm(','补录沟通日期','获客日期','showSourceStatistics','添加提醒','修改提醒','恢复待办','删除提醒','字体大小'):
 if x=='改变':continue
 assert x in s,x
assert 'chip.setMinHeight' not in s and 'chip.setMinimumHeight' in s
assert 'case "待判断":return BLUE;' in s
assert 'fontIndex>=2?1:2' in s
assert 'showTaskDetail(t.id)' in s and 'tile.setOnClickListener' in s
print('PASS UI：客户来源图标、提醒交互、动态字号、状态配色、合同/到账独立入口')
