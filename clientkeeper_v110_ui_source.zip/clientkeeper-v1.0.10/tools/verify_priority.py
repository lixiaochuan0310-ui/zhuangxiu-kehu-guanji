"""Build and run the same pure Java reminder comparator used by the Android app."""
from pathlib import Path
import subprocess,tempfile
src=Path(__file__).resolve().parents[1]/'app/src/main/java/com/decor/clientmanager/ReminderPriority.java'
test=Path(__file__).with_name('ReminderPriorityTest.java')
with tempfile.TemporaryDirectory() as tmp:
 subprocess.run(['javac','-encoding','UTF-8','-d',tmp,str(src),str(test)],check=True)
 subprocess.run(['java','-cp',tmp,'com.decor.clientmanager.ReminderPriorityTest'],check=True)
