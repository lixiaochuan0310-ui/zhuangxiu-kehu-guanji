from pathlib import Path
import sqlite3,re
base=Path(__file__).resolve().parents[1]
src=base/'app/src/main/java/com/decor/clientmanager'
db_java=(src/'Db.java').read_text();transfer=(src/'Transfer.java').read_text()
schema=re.search(r'static final String CLIENT_TABLE="([^"]+)";',db_java).group(1)
assert "gender TEXT NOT NULL DEFAULT '未选择'" in schema
schema_v3=schema.replace("gender TEXT NOT NULL DEFAULT '未选择',",'')
conn=sqlite3.connect(':memory:');conn.execute('PRAGMA foreign_keys=ON')
conn.execute(schema_v3)
conn.execute('CREATE TABLE reminders (id INTEGER PRIMARY KEY,client_id INTEGER REFERENCES clients(id),due_at INTEGER,content TEXT,status TEXT)')
conn.execute('CREATE TABLE contracts (id INTEGER PRIMARY KEY,client_id INTEGER REFERENCES clients(id),signed_at INTEGER,amount REAL,commission_type TEXT,commission_rate REAL,fixed_commission REAL,note TEXT)')
conn.execute('CREATE TABLE receipts (id INTEGER PRIMARY KEY,contract_id INTEGER REFERENCES contracts(id),received_at INTEGER,amount REAL,note TEXT)')
conn.execute("INSERT INTO clients(id,name,phone,stage,intent,created_at,updated_at,acquired_at) VALUES(7,'老客户','13000000000','已签约','高意向',100,100,90)")
conn.execute("INSERT INTO reminders VALUES(23,7,200,'电话联系','pending')")
conn.execute("INSERT INTO contracts VALUES(5,7,110,100000,'fixed',0,2500,'旧合同')")
conn.execute("INSERT INTO receipts VALUES(2,5,120,1000,'部分到账')")
conn.execute("ALTER TABLE clients ADD COLUMN gender TEXT NOT NULL DEFAULT '未选择'")
assert conn.execute('SELECT id,name,phone,gender,stage,intent FROM clients').fetchone()==(7,'老客户','13000000000','未选择','已签约','高意向')
assert conn.execute('SELECT COUNT(*) FROM reminders').fetchone()[0]==1
assert conn.execute('SELECT COUNT(*) FROM contracts').fetchone()[0]==1
assert conn.execute('SELECT SUM(amount) FROM receipts').fetchone()[0]==1000
assert 'data.put("version",4)' in transfer and 'version!=4' in transfer
assert 'if(vers<=3 && t==0)record.put("gender","未选择")' in transfer
assert 'c.gender' in transfer and '"性别"' in transfer
print('PASS: V3→V4升级保留客户/合同/提醒/到账，旧JSON性别兼容，Excel性别导入导出')
