package com.decor.clientmanager;

public final class ReminderPriorityTest {
    static void require(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    public static void main(String[] args){
        long now=1_000_000L;
        // 超时优先于今天，即使今天的客户意向更高。
        require(ReminderPriority.compare(now-1000,"低意向",now+1000,"高意向",now)<0,"逾期任务应排在今天任务前面");
        // 时间早的逾期任务始终优先。
        require(ReminderPriority.compare(now-5000,"待判断",now-1000,"高意向",now)<0,"逾期较久任务优先");
        // 时间早的今天任务优先。
        require(ReminderPriority.compare(now+1000,"低意向",now+5000,"高意向",now)<0,"时间更早优先");
        // 时间相同才以客户意向决胜。
        require(ReminderPriority.compare(now+5000,"高意向",now+5000,"一般意向",now)<0,"同一时间高意向优先");
        require(ReminderPriority.compare(now+5000,"一般意向",now+5000,"低意向",now)<0,"一般意向优先于低意向");
        require(ReminderPriority.compare(now+5000,"低意向",now+5000,"待判断",now)<0,"低意向优先于待判断");
        require(ReminderPriority.compare(now+5000,"待判断",now+5000,"待判断",now)==0,"完全相同应保持稳定排序");
        System.out.println("PASS: overdue/clock/intent priority (7 assertions)");
    }
}
