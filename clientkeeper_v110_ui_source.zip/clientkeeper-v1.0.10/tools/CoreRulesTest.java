package com.decor.clientmanager;

/** JDK-only regression tests for money, phone duplication and Excel day conversions. */
public final class CoreRulesTest {
  private static void eq(Object actual,Object expected){if(!expected.equals(actual))throw new AssertionError("expected="+expected+" actual="+actual);}
  private static void ok(boolean good){if(!good)throw new AssertionError("condition failed");}
  public static void main(String[] args) {
    eq(Money.format(Money.expected("percent",100.05,2.5,0)),"2.50");
    eq(Money.format(Money.expected("percent",101,2.5,0)),"2.53");
    eq(Money.format(Money.expected("fixed",9999,0,321.237)),"321.24");
    eq(Money.format(Money.sum(0.1,0.2)),"0.30");
    eq(PhoneKey.normalize("+86 138 0000 0000"),"13800000000");
    eq(PhoneKey.normalize("138-0000-0000"),"13800000000");
    eq(ExcelCellNumber.normalize("1.38E+10"),"13800000000");
    ok(!PhoneKey.normalize("13800000000").equals(PhoneKey.normalize("13900000000")));
    eq(ExcelDates.formatDate(ExcelDates.parse("2026/10/12",false)),"2026-10-12");
    eq(ExcelDates.formatDate(ExcelDates.parse("46307",false)),"2026-10-12");
    eq(ExcelDates.formatDate(ExcelDates.parse("46307.5",false)),"2026-10-12");
    eq(ExcelDates.formatDate(ExcelDates.parse("44845",true)),"2026-10-12");
    boolean error=false;try{ExcelDates.parse("bad-date",false);}catch(IllegalArgumentException e){error=true;}
    ok(error);
    System.out.println("CoreRulesTest passed");
  }
}
