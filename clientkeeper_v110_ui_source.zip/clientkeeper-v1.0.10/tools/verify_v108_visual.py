#!/usr/bin/env python3
"""V1.0.8 UI source guards; actual rendering requires Android device/emulator."""
from pathlib import Path
src=(Path(__file__).resolve().parents[1]/'app/src/main/java/com/decor/clientmanager/MainActivity.java').read_text()
hero=src.split('private void homeHero()')[1].split('private LinearLayout homeReminderTile')[0]
home=src.split('private void showHome()')[1].split('private void homeQuickAdd()')[0]
chooser=src.split('private void showChoicesAsCards(')[1].split('private TextView selectField')[0]
assert '今日工作安排' not in hero
assert 'schedule.setOnClickListener(v->showTasks("今天"))' in home
assert 'homePriorityTasks(3,' in home
assert 'empty.setGravity(Gravity.CENTER)' in home
assert 'homeReminderTile(task)' in home
reminder=src.split('private LinearLayout homeReminderTile(')[1].split('private LinearLayout reminderTile(')[0]
assert 'setMaxLines(fontIndex>=2?2:1)' in reminder
assert 'homeQuickAdd();' in home
assert 'sourceIcon(option)' in chooser and 'setSingleChoiceItems' not in chooser
assert 'private void section(String label)' in src and 'sectionAccent' in src
assert 'fontCard.addView(option' in src
assert '选择提醒客户' in src and 'showSourceStatistics' in src and 'showStats' in src
print('PASS V1.0.8 global UI source guard')
