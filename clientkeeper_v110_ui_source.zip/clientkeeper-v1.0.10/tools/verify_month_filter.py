#!/usr/bin/env python3
"""TDD check for month selection and signed-month drill-down; requires local JDK only."""
from pathlib import Path
import subprocess, tempfile
root=Path(__file__).resolve().parents[1]
java=root/'app/src/main/java/com/decor/clientmanager'
main=(java/'MainActivity.java').read_text()
assert 'reportingMonth' in main, 'Missing selected reporting month state'
assert 'selectReportingMonth()' in main, 'Missing year/month picker'
assert 'new MonthPeriod(year.getValue(), month.getValue())' in main, 'Missing year/month picker values'
assert '"mine".equals(origin)?reportingMonth.bounds():currentMonthBounds()' in main, 'Signed-month list must use selected stats month'
assert 'db.stats(bounds[0],bounds[1])' in main, 'Stats must use month bounds'
assert 'reportingMonth.label()' in main, 'Selected year/month must be shown'
period=(java/'MonthPeriod.java')
with tempfile.TemporaryDirectory() as d:
    harness=Path(d)/'MonthPeriodTest.java'
    harness.write_text('''package com.decor.clientmanager;
import java.util.Calendar;
public class MonthPeriodTest {
  public static void main(String[] args) {
    MonthPeriod dec=new MonthPeriod(2025,12);
    if(!dec.plusMonths(1).label().equals("2026年1月"))throw new AssertionError("Dec+1");
    if(!dec.plusMonths(-11).label().equals("2025年1月"))throw new AssertionError("Dec-11");
    MonthPeriod jan=new MonthPeriod(2026,1);
    if(!jan.plusMonths(-1).label().equals("2025年12月"))throw new AssertionError("Jan-1");
    long[] b=jan.bounds();Calendar c=Calendar.getInstance();
    c.setTimeInMillis(b[0]);if(c.get(Calendar.YEAR)!=2026||c.get(Calendar.MONTH)!=0||c.get(Calendar.DAY_OF_MONTH)!=1||c.get(Calendar.HOUR_OF_DAY)!=0)throw new AssertionError("start");
    c.setTimeInMillis(b[1]);if(c.get(Calendar.YEAR)!=2026||c.get(Calendar.MONTH)!=1||c.get(Calendar.DAY_OF_MONTH)!=1||c.get(Calendar.HOUR_OF_DAY)!=0)throw new AssertionError("end");
    if(!(b[0]<b[1]))throw new AssertionError("inverted range");
    boolean failed=false;try{new MonthPeriod(2026,13);}catch(IllegalArgumentException e){failed=true;}
    if(!failed)throw new AssertionError("reject month 13");
    System.out.println("MonthPeriod boundary and year rollover: PASS");
  }
}''')
    subprocess.run(['javac','-d',d,str(period),str(harness)],check=True)
    subprocess.run(['java','-cp',d,'com.decor.clientmanager.MonthPeriodTest'],check=True)
print('Month selection UI and selected-month drill-down: PASS')
