import com.sun.source.util.JavacTask;
import javax.tools.*;
import java.util.*;
import java.io.File;

/** Only syntax parsing, intentionally does not claim Android type or APK compilation. */
public final class SyntaxAudit {
  public static void main(String[] args) throws Exception {
    if(args.length==0)throw new IllegalArgumentException("Supply Java files");
    JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
    DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
    try(StandardJavaFileManager manager=compiler.getStandardFileManager(diagnostics,null,null)){
      List<File> files=new ArrayList<>();for(String name:args)files.add(new File(name));
      Iterable<? extends JavaFileObject> units=manager.getJavaFileObjectsFromFiles(files);
      JavacTask task=(JavacTask)compiler.getTask(null,manager,diagnostics,List.of("-proc:none","--release","17"),null,units);
      task.parse();
    }
    boolean failed=false;
    for(Diagnostic<? extends JavaFileObject> issue:diagnostics.getDiagnostics()){
      if(issue.getKind()==Diagnostic.Kind.ERROR){System.err.println(issue.getSource()+":"+issue.getLineNumber()+" "+issue.getMessage(Locale.ROOT));failed=true;}
    }
    if(failed)System.exit(1);
    System.out.println("SyntaxAudit passed for "+args.length+" Java files (syntax only)");
  }
}
