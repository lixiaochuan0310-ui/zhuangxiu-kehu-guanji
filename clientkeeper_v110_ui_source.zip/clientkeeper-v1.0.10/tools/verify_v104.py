from pathlib import Path
import re,sqlite3,unittest
BASE=Path(__file__).resolve().parents[1]
DB=(BASE/'app/src/main/java/com/decor/clientmanager/Db.java').read_text()
UI=(BASE/'app/src/main/java/com/decor/clientmanager/MainActivity.java').read_text()
TRANS=(BASE/'app/src/main/java/com/decor/clientmanager/Transfer.java').read_text()
class Requirements(unittest.TestCase):
 def test_no_contract_wipe_on_stage_change(self):
  self.assertNotIn('if(!"已签约".equals(c.stage)) c.signedAt=0',DB)
 def test_contracts_multiple_and_receipts(self):
  for name in ('CREATE TABLE contracts','CREATE TABLE receipts','long saveContract','long addReceipt','monthReceived','COUNT(DISTINCT','getContracts'):
   self.assertIn(name,DB)
 def test_acquired_and_follow_edit(self):
  for name in ('acquired_at','updateFollow','deleteFollow'):self.assertIn(name,DB)
  for label in ('获客日期','修改跟进记录','补录沟通日期'):self.assertIn(label,UI)
 def test_reminder_reopen_delete(self):
  for name in ('reopenTask','deleteTask'):self.assertIn(name,DB)
  for label in ('恢复待办','删除提醒'):self.assertIn(label,UI)
 def test_receive_history(self):
  self.assertIn('到账日期',UI);self.assertIn('删除这笔到账',UI)
  self.assertIn('收款日期',TRANS)
 def test_month_statistics_source(self):
  self.assertIn('按到账日期',UI);self.assertIn('客户来源统计',UI)
 def test_restore_backward(self):
  self.assertIn('version!=1&&version!=2&&version!=3',TRANS)
  self.assertIn('public static BackupInfo inspect',TRANS)
 def test_no_company_source(self):
  self.assertIn('"门店"',DB)
  self.assertNotIn('"公司分配"',DB)
 def test_import_excel(self):
  self.assertIn('importExcel',TRANS)
  self.assertIn('导入Excel',UI)
if __name__=='__main__':unittest.main()
