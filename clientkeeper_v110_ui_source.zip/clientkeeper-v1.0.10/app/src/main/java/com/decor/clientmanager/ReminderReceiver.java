package com.decor.clientmanager;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

public final class ReminderReceiver extends BroadcastReceiver {
    static final String CHANNEL_ID="decoration_followups";
    @Override public void onReceive(Context context,Intent intent) {
        long id=intent.getLongExtra("reminder_id",0);if(id<=0)return;
        Db db=new Db(context);Db.Task task;
        try{task=db.task(id);}finally{db.close();}
        if(task==null||!"pending".equals(task.status))return;
        if(task.dueAt>System.currentTimeMillis()+60_000){ReminderScheduler.schedule(context,task);return;}
        if(Build.VERSION.SDK_INT>=33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm==null)return;
        nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID,"客户跟进提醒",NotificationManager.IMPORTANCE_DEFAULT));
        Intent open=new Intent(context,MainActivity.class);open.putExtra("open_client_id",task.clientId);open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(context,(int)(task.id^(task.id>>>32)),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification n=new android.app.Notification.Builder(context,CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("需要联系："+task.clientName)
            .setContentText(task.content.isEmpty()?"您设置的客户跟进时间已到":task.content)
            .setStyle(new android.app.Notification.BigTextStyle().bigText(task.content))
            .setAutoCancel(true).setContentIntent(pi).build();
        nm.notify((int)(id^(id>>>32)),n);
    }
}
