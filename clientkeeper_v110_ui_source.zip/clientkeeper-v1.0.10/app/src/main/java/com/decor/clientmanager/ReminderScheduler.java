package com.decor.clientmanager;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

/** 采用系统允许的非精确闹钟；勿向用户承诺分秒准确。 */
public final class ReminderScheduler {
    private ReminderScheduler(){}
    private static PendingIntent intent(Context context,long id) {
        Intent i=new Intent(context,ReminderReceiver.class);i.putExtra("reminder_id",id);
        return PendingIntent.getBroadcast(context,(int)(id^(id>>>32)),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    public static void schedule(Context context,Db.Task task) {
        if(task==null||!"pending".equals(task.status))return;
        AlarmManager manager=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        if(manager!=null)manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,Math.max(task.dueAt,System.currentTimeMillis()+1200),intent(context,task.id));
    }
    public static void cancel(Context context,long id) {
        AlarmManager manager=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        if(manager!=null)manager.cancel(intent(context,id));
    }
    public static void rescheduleAll(Context context) {
        Db db=new Db(context);
        try { for(Db.Task task: db.tasks("待处理",0))schedule(context,task); }
        finally{db.close();}
    }
}
