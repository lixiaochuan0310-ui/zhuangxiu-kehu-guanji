package com.decor.clientmanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/** 原子化完整备份/恢复、无第三方依赖的真实XLSX导出及客户基础资料导入。 */
public final class Transfer {
    private Transfer(){}
    private static final String[] TABLES={"clients","followups","reminders","contracts","receipts"};
    private static final String[][] KEYS={
        {"id","name","gender","phone","wechat","source","community","building","area","budget","renovation_type","needs","notes","stage","intent","signed_at","contract_amount","commission_rate","commission_type","fixed_commission","received_amount","created_at","updated_at","acquired_at"},
        {"id","client_id","happened_at","content"},
        {"id","client_id","due_at","content","status"},
        {"id","client_id","signed_at","amount","commission_type","commission_rate","fixed_commission","note"},
        {"id","contract_id","received_at","amount","note"}
    };
    static String date(long ms){return ms<=0?"":new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.CHINA).format(new Date(ms));}
    private static JSONArray dump(SQLiteDatabase db,String table)throws Exception{
        JSONArray all=new JSONArray();try(Cursor c=db.query(table,null,null,null,null,null,"id ASC")){
            String[] columns=c.getColumnNames();while(c.moveToNext()){
                JSONObject row=new JSONObject();for(int i=0;i<columns.length;i++){
                    switch(c.getType(i)){
                        case Cursor.FIELD_TYPE_NULL:row.put(columns[i],JSONObject.NULL);break;
                        case Cursor.FIELD_TYPE_INTEGER:row.put(columns[i],c.getLong(i));break;
                        case Cursor.FIELD_TYPE_FLOAT:row.put(columns[i],c.getDouble(i));break;
                        default:row.put(columns[i],c.getString(i));
                    }
                }all.put(row);
            }
        }return all;
    }
    public static void backup(Db db,OutputStream output)throws Exception{
        JSONObject data=new JSONObject();data.put("format","DECORATION_CLIENTS_BACKUP");data.put("version",4);data.put("created_at",System.currentTimeMillis());
        SQLiteDatabase d=db.getReadableDatabase();for(String table:TABLES)data.put(table,dump(d,table));
        output.write(data.toString(2).getBytes(StandardCharsets.UTF_8));output.flush();
    }
    private static byte[] read(InputStream in,int max)throws Exception{
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;
        while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>max)throw new Exception("文件超过允许大小");}
        return out.toByteArray();
    }
    public static class BackupInfo {
        public long createdAt;public int clients,followups,reminders,contracts,receipts,version;
        public String summary(){return "备份时间："+date(createdAt)+"\n客户："+clients+" 人\n跟进记录："+followups+
            " 条\n提醒："+reminders+" 条\n合同："+(version>=3?contracts+" 份":"旧版合同将自动转换")+"\n到账："+(version>=3?receipts+" 笔":"旧版无到账日期")+"\n\n恢复会替换本机全部数据。";}
    }
    private static JSONObject parse(InputStream in)throws Exception{return new JSONObject(new String(read(in,80*1024*1024),StandardCharsets.UTF_8));}
    private static int version(JSONObject data)throws Exception{
        int version=data.optInt("version");
        if(!"DECORATION_CLIENTS_BACKUP".equals(data.optString("format"))||(version!=1&&version!=2&&version!=3&&version!=4))throw new Exception("不是受支持的装修客户管家备份文件");
        return version;
    }
    public static BackupInfo inspect(InputStream in)throws Exception{
        JSONObject data=parse(in);BackupInfo x=new BackupInfo();x.version=version(data);x.createdAt=data.optLong("created_at",0);
        x.clients=data.getJSONArray("clients").length();x.followups=data.getJSONArray("followups").length();x.reminders=data.getJSONArray("reminders").length();
        if(x.version>=3){x.contracts=data.getJSONArray("contracts").length();x.receipts=data.getJSONArray("receipts").length();}
        else{x.contracts=-1;x.receipts=-1;}return x;
    }
    public static void restore(Context context,Db db,InputStream in)throws Exception{
        JSONObject data=parse(in);int vers=version(data);
        JSONArray[] all=new JSONArray[TABLES.length];for(int i=0;i<3;i++)all[i]=data.getJSONArray(TABLES[i]);
        if(vers>=3){all[3]=data.getJSONArray("contracts");all[4]=data.getJSONArray("receipts");}
        else{all[3]=new JSONArray();all[4]=new JSONArray();}
        Set<Long> clients=new HashSet<>(),contracts=new HashSet<>();
        for(int t=0;t<all.length;t++){
            Set<Long> unique=new HashSet<>();for(int n=0;n<all[t].length();n++){
                JSONObject record=all[t].getJSONObject(n);long id=record.getLong("id");
                if(vers==1 && t==0){record.put("commission_type","percent");record.put("fixed_commission",0);}
                if(vers<=2 && t==0)record.put("acquired_at",record.getLong("created_at"));
                if(vers<=3 && t==0)record.put("gender","未选择");
                if(id<=0||!unique.add(id))throw new Exception("备份存在无效或重复编号");
                for(String column:KEYS[t])if(!record.has(column)||record.isNull(column))throw new Exception("备份缺少字段："+column);
                if(t==0){clients.add(id);if(record.getString("name").trim().isEmpty()&&record.getString("phone").trim().isEmpty())throw new Exception("客户姓名和电话不能同时为空");}
                else if(t==1||t==2||t==3){if(!clients.contains(record.getLong("client_id")))throw new Exception("存在无对应客户的记录");}
                if(t==2&&!"pending".equals(record.getString("status"))&&!"done".equals(record.getString("status")))throw new Exception("提醒状态不正确");
                if(t==3){contracts.add(id);String mode=record.getString("commission_type");if(!"percent".equals(mode)&&!"fixed".equals(mode))throw new Exception("合同提成类型不正确");
                    if(record.getLong("signed_at")<=0||invalid(record.getDouble("amount"))||invalid(record.getDouble("commission_rate"))||invalid(record.getDouble("fixed_commission")))throw new Exception("合同金额或日期不正确");}
                if(t==4){if(!contracts.contains(record.getLong("contract_id"))||record.getLong("received_at")<0||record.getDouble("amount")<=0||!Double.isFinite(record.getDouble("amount")))throw new Exception("到账数据不正确");}
            }
        }
        SQLiteDatabase d=db.getWritableDatabase();List<Db.Task> pending=db.tasks("待处理",0);
        d.beginTransaction();try{
            // 先清空孩子表，避免FK错误；所有记录和ID在同一事务中恢复，任何失败立即回滚。
            d.delete("receipts",null,null);d.delete("contracts",null,null);d.delete("reminders",null,null);d.delete("followups",null,null);d.delete("clients",null,null);
            for(int t=0;t<all.length;t++)for(int i=0;i<all[t].length();i++){
                JSONObject record=all[t].getJSONObject(i);ContentValues values=new ContentValues();
                for(String key:KEYS[t]){
                    Object value=record.get(key);
                    if(value instanceof Integer||value instanceof Long)values.put(key,((Number)value).longValue());
                    else if(value instanceof Number)values.put(key,((Number)value).doubleValue());
                    else values.put(key,String.valueOf(value));
                }
                d.insertOrThrow(TABLES[t],null,values);
            }
            if(vers<=2){
                d.execSQL("INSERT INTO contracts(client_id,signed_at,amount,commission_type,commission_rate,fixed_commission,note) SELECT id,signed_at,contract_amount,CASE WHEN commission_type='fixed' THEN 'fixed' ELSE 'percent' END,commission_rate,fixed_commission,'从旧版备份恢复' FROM clients WHERE signed_at>0");
                d.execSQL("INSERT INTO receipts(contract_id,received_at,amount,note) SELECT contracts.id,0,clients.received_amount,'旧版累计已收，到账日期待补' FROM contracts JOIN clients ON clients.id=contracts.client_id WHERE clients.received_amount>0");
            }
            d.setTransactionSuccessful();
        }finally{d.endTransaction();}
        for(Db.Task task:pending)ReminderScheduler.cancel(context,task.id);
        ReminderScheduler.rescheduleAll(context);
    }
    private static boolean invalid(double n){return !Double.isFinite(n)||n<0;}
    /** 真正的XLSX报表：六张表，包含每份合同、每笔到账及来源统计。 */
    public static void exportExcel(Db db,OutputStream output)throws Exception{
        ZipOutputStream zip=new ZipOutputStream(output,StandardCharsets.UTF_8);
        String[] names={"客户资料","跟进记录","跟进提醒","签约合同","提成到账","客户来源统计"};
        StringBuilder types=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>");
        StringBuilder workbook=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");
        StringBuilder rels=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
        for(int i=0;i<names.length;i++){int id=i+1;types.append("<Override PartName=\"/xl/worksheets/sheet").append(id).append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
            workbook.append("<sheet name=\"").append(names[i]).append("\" sheetId=\"").append(id).append("\" r:id=\"rId").append(id).append("\"/>");
            rels.append("<Relationship Id=\"rId").append(id).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet").append(id).append(".xml\"/>");}
        add(zip,"[Content_Types].xml",types.append("</Types>").toString());
        add(zip,"_rels/.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
        add(zip,"xl/workbook.xml",workbook.append("</sheets></workbook>").toString());
        add(zip,"xl/_rels/workbook.xml.rels",rels.append("</Relationships>").toString());
        List<String[]> people=new ArrayList<>();people.add(new String[]{"编号","姓名/称呼","性别","手机号","微信号","客户来源","小区","楼栋房号","面积(㎡)","装修预算","装修类型","装修需求","备注","业务进展","意向程度","获客日期","建档时间"});
        for(Db.Client c:db.clients("",null,null))people.add(new String[]{""+c.id,c.name,c.gender,c.phone,c.wechat,c.source,c.community,c.building,c.area,c.budget,c.renovationType,c.needs,c.notes,c.stage,c.intent,date(c.acquiredAt),date(c.createdAt)});
        add(zip,"xl/worksheets/sheet1.xml",sheet(people));
        List<String[]> follows=new ArrayList<>();follows.add(new String[]{"客户编号","客户姓名","沟通日期","沟通内容"});
        try(Cursor c=db.getReadableDatabase().rawQuery("SELECT f.client_id,c.name,c.phone,f.happened_at,f.content FROM followups f JOIN clients c ON c.id=f.client_id ORDER BY f.happened_at DESC",null)){
            while(c.moveToNext())follows.add(new String[]{""+c.getLong(0),c.getString(1).isEmpty()?c.getString(2):c.getString(1),date(c.getLong(3)),c.getString(4)});}
        add(zip,"xl/worksheets/sheet2.xml",sheet(follows));
        List<String[]> tasks=new ArrayList<>();tasks.add(new String[]{"客户编号","客户","提醒日期","事项","状态"});
        for(Db.Task t:db.tasks("全部",0))tasks.add(new String[]{""+t.clientId,t.clientName,date(t.dueAt),t.content,"done".equals(t.status)?"已完成":(t.overdue()?"已逾期":"待跟进")});
        add(zip,"xl/worksheets/sheet3.xml",sheet(tasks));
        List<String[]> contracts=new ArrayList<>();contracts.add(new String[]{"合同编号","客户编号","客户","签约日期","合同金额","提成方式","提成比例(%)","固定金额","预计提成","已收合计","备注"});
        try(Cursor c=db.getReadableDatabase().rawQuery("SELECT id,client_id FROM contracts ORDER BY signed_at DESC",null)){
            while(c.moveToNext()){Db.Contract x=db.contract(c.getLong(0));Db.Client client=db.client(x.clientId);if(client==null)continue;
                contracts.add(new String[]{""+x.id,""+x.clientId,client.displayName(),date(x.signedAt),Money.format(x.amount),"fixed".equals(x.commissionType)?"固定金额":"按比例",""+x.commissionRate,Money.format(x.fixedCommission),Money.format(x.expected()),Money.format(db.receivedForContract(x.id)),x.note});}}
        add(zip,"xl/worksheets/sheet4.xml",sheet(contracts));
        List<String[]> receipts=new ArrayList<>();receipts.add(new String[]{"到账编号","合同编号","客户","收款日期","到账金额","备注"});
        try(Cursor c=db.getReadableDatabase().rawQuery("SELECT receipts.id,receipts.contract_id FROM receipts ORDER BY received_at DESC,id DESC",null)){
            while(c.moveToNext()){Db.Receipt x=db.receipt(c.getLong(0));Db.Contract contract=db.contract(x.contractId);Db.Client client=contract==null?null:db.client(contract.clientId);if(client!=null)receipts.add(new String[]{""+x.id,""+x.contractId,client.displayName(),x.receivedAt<=0?"历史日期待补":date(x.receivedAt),Money.format(x.amount),x.note});}}
        add(zip,"xl/worksheets/sheet5.xml",sheet(receipts));
        List<String[]> source=new ArrayList<>();source.add(new String[]{"客户来源","累计客户数","累计签约客户数"});
        for(String src:Db.SOURCES){int count=0,signed=0;try(Cursor cur=db.getReadableDatabase().rawQuery("SELECT COUNT(DISTINCT clients.id),COUNT(DISTINCT contracts.client_id) FROM clients LEFT JOIN contracts ON contracts.client_id=clients.id WHERE source=?",new String[]{src})){if(cur.moveToFirst()){count=cur.getInt(0);signed=cur.getInt(1);}}source.add(new String[]{src,""+count,""+signed});}
        add(zip,"xl/worksheets/sheet6.xml",sheet(source));zip.finish();zip.flush();
    }
    private static void add(ZipOutputStream z,String name,String text)throws Exception{z.putNextEntry(new ZipEntry(name));z.write(text.getBytes(StandardCharsets.UTF_8));z.closeEntry();}
    private static String xml(String s){if(s==null)return "";StringBuilder out=new StringBuilder();for(int i=0;i<s.length();i++){
        char c=s.charAt(i);if(c=='&')out.append("&amp;");else if(c=='<')out.append("&lt;");else if(c=='>')out.append("&gt;");else if(c=='\"')out.append("&quot;");else if(c=='\'')out.append("&apos;");else if(c==9||c==10||c==13||c>=32)out.append(c);}
        return out.toString();}
    private static String sheet(List<String[]> rows){StringBuilder out=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");
        for(int i=0;i<rows.size();i++){out.append("<row r=\"").append(i+1).append("\">");String[] row=rows.get(i);
            for(int k=0;k<row.length;k++){int x=k+1;StringBuilder key=new StringBuilder();while(x>0){x--;key.insert(0,(char)('A'+(x%26)));x/=26;}
                // 所有单元格均按文本输出，防止Excel将客户输入的 = + - @ 公式执行。
                out.append("<c r=\"").append(key).append(i+1).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(xml(row[k])).append("</t></is></c>");}
            out.append("</row>");}
        return out.append("</sheetData></worksheet>").toString();}
    /** 仅导入第一张客户表的基础资料；重复手机号跳过，绝不覆盖已有客户、合同或提醒。 */
    public static String importExcel(Db db,InputStream input)throws Exception{
        byte[] zip=read(input,20*1024*1024);byte[] worksheet=null,strings=null,workbook=null;
        try(ZipInputStream in=new ZipInputStream(new ByteArrayInputStream(zip),StandardCharsets.UTF_8)){
            ZipEntry entry;int size=0;
            while((entry=in.getNextEntry())!=null){String name=entry.getName();if(name.equals("xl/worksheets/sheet1.xml")||name.equals("xl/sharedStrings.xml")||name.equals("xl/workbook.xml")){
                byte[] data=read(in,8*1024*1024);size+=data.length;if(size>12*1024*1024)throw new Exception("工作表内容过大");
                if(name.endsWith("sheet1.xml"))worksheet=data;else if(name.endsWith("workbook.xml"))workbook=data;else strings=data;}
                in.closeEntry();}
        }
        if(worksheet==null)throw new Exception("Excel文件缺少第一张工作表");
        boolean date1904=false;
        if(workbook!=null){Document book=parseXml(workbook);NodeList props=book.getElementsByTagNameNS("*","workbookPr");
            if(props.getLength()>0){String mode=((Element)props.item(0)).getAttribute("date1904");date1904="1".equals(mode)||"true".equalsIgnoreCase(mode);}}
        final boolean use1904=date1904;
        List<String> shared=new ArrayList<>();if(strings!=null){Document doc=parseXml(strings);NodeList items=doc.getElementsByTagNameNS("*","si");
            for(int i=0;i<items.getLength();i++)shared.add(items.item(i).getTextContent());}
        Document doc=parseXml(worksheet);NodeList rowNodes=doc.getElementsByTagNameNS("*","row");if(rowNodes.getLength()<1)throw new Exception("Excel工作表为空");
        List<List<String>> rows=new ArrayList<>();for(int i=0;i<rowNodes.getLength();i++){
            NodeList cells=((Element)rowNodes.item(i)).getElementsByTagNameNS("*","c");List<String> record=new ArrayList<>();
            for(int k=0;k<cells.getLength();k++){Element cell=(Element)cells.item(k);String ref=cell.getAttribute("r");int col=0;
                for(int j=0;j<ref.length()&&Character.isLetter(ref.charAt(j));j++)col=col*26+Character.toUpperCase(ref.charAt(j))-'A'+1;
                col--;if(col<0||col>100)continue;while(record.size()<=col)record.add("");
                String value="";NodeList inners=cell.getElementsByTagNameNS("*","is");NodeList v=cell.getElementsByTagNameNS("*","v");
                if("s".equals(cell.getAttribute("t"))&&v.getLength()>0){int index=Integer.parseInt(v.item(0).getTextContent());if(index>=0&&index<shared.size())value=shared.get(index);}
                else if(inners.getLength()>0)value=inners.item(0).getTextContent();
                else if(v.getLength()>0)value=ExcelCellNumber.normalize(v.item(0).getTextContent());
                record.set(col,value==null?"":value.trim());}
            rows.add(record);
        }
        if(rows.size()<2)return "Excel没有可导入的客户行";
        Map<String,Integer> columns=new HashMap<>();for(int i=0;i<rows.get(0).size();i++)columns.put(rows.get(0).get(i).replace(" ","").trim(),i);
        if(col(columns,"客户姓名","姓名","姓名/称呼","客户","客户名称")<0&&col(columns,"手机号","电话","联系电话","手机号码")<0)throw new Exception("第一行须有姓名或手机号列");
        int imported=0,duplicates=0,ignored=0;
        SQLiteDatabase sqlite=db.getWritableDatabase();sqlite.beginTransaction();try{
            Set<String> numbers=new HashSet<>();try(Cursor old=sqlite.rawQuery("SELECT phone FROM clients WHERE phone!=''",null)){while(old.moveToNext())numbers.add(PhoneKey.normalize(old.getString(0)));}
            for(int i=1;i<rows.size();i++){List<String> row=rows.get(i);
                String name=colValue(row,columns,"客户姓名","姓名","姓名/称呼","客户","客户名称");
                String phone=colValue(row,columns,"手机号","电话","联系电话","手机号码");
                if(name.isEmpty()&&phone.isEmpty()){ignored++;continue;}
                if(!phone.isEmpty()&&numbers.contains(PhoneKey.normalize(phone))){duplicates++;continue;}
                String source=colValue(row,columns,"客户来源","来源");boolean validSource=false;for(String option:Db.SOURCES)if(option.equals(source))validSource=true;
                if(!validSource)source="其他";
                ContentValues cv=new ContentValues();long now=System.currentTimeMillis();
                cv.put("name",name);cv.put("phone",phone);cv.put("source",source);
                String gender=colValue(row,columns,"性别","客户性别");cv.put("gender",("男".equals(gender)||"女".equals(gender))?gender:"未选择");
                cv.put("wechat",colValue(row,columns,"微信号","微信"));cv.put("community",colValue(row,columns,"小区","小区名称"));
                cv.put("building",colValue(row,columns,"楼栋房号","楼栋","房号"));cv.put("area",colValue(row,columns,"面积","面积(㎡)","房屋面积","房屋面积(㎡)"));
                cv.put("budget",colValue(row,columns,"装修预算","预算"));cv.put("needs",colValue(row,columns,"装修需求","需求"));
                cv.put("notes",colValue(row,columns,"备注"));cv.put("stage","新客户");cv.put("intent","待判断");
                String acquiredValue=colValue(row,columns,"获客日期","获客时间");
                long acquired=now;
                if(!acquiredValue.isEmpty()){
                    try{acquired=ExcelDates.parse(acquiredValue,use1904);}catch(IllegalArgumentException badDate){
                        throw new Exception("Excel第"+(i+1)+"行获客日期错误："+badDate.getMessage()+"；原数据未变更");
                    }
                }
                cv.put("acquired_at",acquired);
                cv.put("created_at",now);cv.put("updated_at",now);
                sqlite.insertOrThrow("clients",null,cv);imported++;if(!phone.isEmpty())numbers.add(PhoneKey.normalize(phone));
            }sqlite.setTransactionSuccessful();
        }finally{sqlite.endTransaction();}
        return "导入 "+imported+" 人；重复手机号跳过 "+duplicates+" 人；空行跳过 "+ignored+" 行。合同、提成和跟进记录不会自动导入。";
    }
    private static int col(Map<String,Integer> columns,String... names){for(String name:names)if(columns.containsKey(name))return columns.get(name);return -1;}
    private static String colValue(List<String> row,Map<String,Integer> cols,String... labels){int index=col(cols,labels);return index>=0&&index<row.size()?row.get(index).trim():"";}
    private static Document parseXml(byte[] xml)throws Exception{
        DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();factory.setNamespaceAware(true);
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);
        factory.setFeature("http://xml.org/sax/features/external-general-entities",false);
        factory.setFeature("http://xml.org/sax/features/external-parameter-entities",false);
        return factory.newDocumentBuilder().parse(new ByteArrayInputStream(xml));
    }
}
