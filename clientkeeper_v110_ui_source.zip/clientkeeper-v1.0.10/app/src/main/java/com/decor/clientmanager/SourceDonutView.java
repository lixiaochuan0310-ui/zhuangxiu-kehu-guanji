package com.decor.clientmanager;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** 仅画真实数据圆环；图例改用安卓可自适应文字组件，避免特大字体裁切。 */
public final class SourceDonutView extends View {
    private final int[] values;
    private final float scale;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    public SourceDonutView(Context context,int[] values,float fontScale){
        super(context);this.values=values.clone();this.scale=fontScale;
        int count=0;for(int v:values)count+=Math.max(0,v);
        setContentDescription("客户来源统计，共"+count+"人，详情见下方文字图例");
    }
    private float dp(float value){return value*getResources().getDisplayMetrics().density;}
    private float sp(float value){return value*getResources().getDisplayMetrics().scaledDensity*scale;}
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);
        int total=0;for(int v:values)total+=Math.max(0,v);
        float w=getWidth(),h=getHeight(),cx=w/2,cy=h/2;
        float radius=Math.max(dp(36),Math.min(w,h)*.35f);
        RectF oval=new RectF(cx-radius,cy-radius,cx+radius,cy+radius);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(18));paint.setColor(0xffdbece9);
        canvas.drawArc(oval,-90,360,false,paint);
        if(total>0){float start=-90;for(int i=0;i<values.length;i++){
            int count=Math.max(0,values[i]);if(count==0)continue;
            float sweep=360f*count/total;paint.setColor(SourcePalette.color(i));
            canvas.drawArc(oval,start,sweep,false,paint);start+=sweep;
        }}
        paint.setStyle(Paint.Style.FILL);paint.setTextAlign(Paint.Align.CENTER);paint.setColor(0xff263d4a);
        paint.setFakeBoldText(true);paint.setTextSize(Math.min(sp(18),radius*.60f));
        canvas.drawText(String.valueOf(total),cx,cy,paint);
        paint.setFakeBoldText(false);paint.setTextSize(Math.min(sp(11),radius*.33f));paint.setColor(0xff536975);
        canvas.drawText("新增客户",cx,cy+dp(19),paint);
    }
}
