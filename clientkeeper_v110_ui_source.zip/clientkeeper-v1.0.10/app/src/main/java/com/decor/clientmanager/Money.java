package com.decor.clientmanager;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** 金额始终以分为最小统计单位；合同先计算各自的应计提成，再汇总。 */
final class Money {
    private Money(){}
    static BigDecimal cents(double value){
        if(!Double.isFinite(value)||value<0)throw new IllegalArgumentException("金额必须是有效的非负数字");
        return BigDecimal.valueOf(value).setScale(2,RoundingMode.HALF_UP);
    }
    static double round(double value){return cents(value).doubleValue();}
    static double expected(String type,double amount,double rate,double fixed){
        if("fixed".equals(type))return round(fixed);
        if(!"percent".equals(type)||!Double.isFinite(rate)||rate<0||rate>100)throw new IllegalArgumentException("提成方式或比例不正确");
        return cents(amount).multiply(BigDecimal.valueOf(rate)).divide(BigDecimal.valueOf(100),2,RoundingMode.HALF_UP).doubleValue();
    }
    static double sum(double a,double b){return cents(a).add(cents(b)).doubleValue();}
    static String format(double value){return cents(value).toPlainString();}
}
