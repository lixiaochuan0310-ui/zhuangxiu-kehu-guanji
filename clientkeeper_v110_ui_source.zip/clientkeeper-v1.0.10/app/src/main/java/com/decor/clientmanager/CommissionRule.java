package com.decor.clientmanager;

/** Pure numeric business rule used consistently by cards and contract details. */
final class CommissionRule {
    private CommissionRule() {}
    static double expected(String type,double contractAmount,double rate,double fixedAmount) {
        if("fixed".equals(type)) return Money.expected("fixed",contractAmount,rate,fixedAmount);
        return Money.expected("percent",contractAmount,rate,fixedAmount);
    }
}
