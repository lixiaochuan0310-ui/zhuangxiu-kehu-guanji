package com.decor.clientmanager;
/** 六种客户来源的全局固定配色，图标和统计必须使用同一顺序。 */
final class SourcePalette {
    private static final int[] COLORS={0xff2A8BD4,0xff13A59B,0xff5372D0,0xffC2871B,0xff8654C0,0xffB48A2D};
    private SourcePalette(){}
    static int color(int index){return COLORS[Math.floorMod(index,COLORS.length)];}
}
