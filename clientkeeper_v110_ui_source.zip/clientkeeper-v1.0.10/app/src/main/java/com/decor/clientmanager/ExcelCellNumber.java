package com.decor.clientmanager;

import java.math.BigDecimal;

/** 将Excel数值单元格的科学计数法还原为常规数字文本，避免手机号显示为1.38E10。 */
final class ExcelCellNumber {
    private ExcelCellNumber(){}
    static String normalize(String input){
        if(input==null)return "";
        String value=input.trim();
        if(value.matches("[+-]?(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)[Ee][+-]?[0-9]+")){
            try{return new BigDecimal(value).stripTrailingZeros().toPlainString();}
            catch(NumberFormatException ignored){}
        }
        return value;
    }
}
