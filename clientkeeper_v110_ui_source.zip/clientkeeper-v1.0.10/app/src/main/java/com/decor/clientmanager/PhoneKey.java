package com.decor.clientmanager;

/** 仅用于重复提醒，保留客户录入的原始号码，不擅自合并。 */
final class PhoneKey {
    private PhoneKey(){}
    static String normalize(String value){
        if(value==null)return "";
        String digits=value.replaceAll("[^0-9]","");
        if(digits.length()==13&&digits.startsWith("86")&&digits.substring(2).startsWith("1"))return digits.substring(2);
        if(digits.length()==15&&digits.startsWith("0086")&&digits.substring(4).startsWith("1"))return digits.substring(4);
        return digits;
    }
}
