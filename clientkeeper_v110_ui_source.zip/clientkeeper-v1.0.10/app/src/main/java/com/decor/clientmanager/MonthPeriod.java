package com.decor.clientmanager;

import java.util.Calendar;

/** A locally selected calendar month; end bound is exclusive. */
final class MonthPeriod {
    final int year;
    final int month; // 1..12

    MonthPeriod(int year, int month) {
        if (year < 1 || month < 1 || month > 12) throw new IllegalArgumentException("Invalid year/month");
        this.year = year;
        this.month = month;
    }

    static MonthPeriod current() {
        Calendar c = Calendar.getInstance();
        return new MonthPeriod(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1);
    }

    MonthPeriod plusMonths(int shift) {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(year, month - 1, 1);
        c.add(Calendar.MONTH, shift);
        return new MonthPeriod(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1);
    }

    long[] bounds() {
        Calendar start = Calendar.getInstance();
        start.clear();
        start.set(year, month - 1, 1);
        Calendar end = (Calendar) start.clone();
        end.add(Calendar.MONTH, 1);
        return new long[]{start.getTimeInMillis(), end.getTimeInMillis()};
    }

    String label() { return year + "年" + month + "月"; }
}
