package com.decor.clientmanager;

/** 首页提醒排序。先过期，再今天；时间相同才比较客户意向。无外部依赖，便于独立测试。 */
final class ReminderPriority {
    private ReminderPriority() {}
    static int intentRank(String intent) {
        if("高意向".equals(intent)) return 0;
        if("一般意向".equals(intent)) return 1;
        if("低意向".equals(intent)) return 2;
        return 3;
    }
    static int compare(long dueA,String intentA,long dueB,String intentB,long now) {
        boolean overdueA=dueA<now,overdueB=dueB<now;
        if(overdueA!=overdueB) return overdueA?-1:1;
        int date=Long.compare(dueA,dueB);
        return date!=0?date:Integer.compare(intentRank(intentA),intentRank(intentB));
    }
}
