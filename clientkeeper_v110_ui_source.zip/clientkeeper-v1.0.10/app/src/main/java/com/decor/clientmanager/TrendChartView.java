package com.decor.clientmanager;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;
import java.text.DecimalFormat;

/** 本地真实合同数据柱状图；按实际图宽测量标签并避免金额裁切。 */
public final class TrendChartView extends View {
    private final float scale;
    private final double[] amounts;
    private final String[] labels;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    public TrendChartView(Context c,double[] amounts,String[] labels,float fontScale){
        super(c);this.scale=fontScale;this.amounts=amounts.clone();this.labels=labels.clone();
        StringBuilder spoken=new StringBuilder("近六个月签约金额：");
        for(int i=0;i<amounts.length;i++)spoken.append(labels[i]).append(' ').append(Money.format(Math.max(0,amounts[i]))).append("元；");
        setContentDescription(spoken.toString());
    }
    private float dp(float x){return x*getResources().getDisplayMetrics().density;}
    private float sp(float x){return x*getResources().getDisplayMetrics().scaledDensity*scale;}
    private String brief(double value){
        if(value>=100000000)return new DecimalFormat("0.#").format(value/100000000d)+"亿";
        if(value>=10000)return new DecimalFormat("0.#").format(value/10000d)+"万";
        return new DecimalFormat("0.#").format(value);
    }
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);
        float width=getWidth(),height=getHeight();if(width<=0||height<=0)return;
        float top=dp(25),bottom=height-dp(28),usable=Math.max(dp(15),bottom-top);
        paint.setStyle(Paint.Style.STROKE);paint.setColor(0xffdce8e8);paint.setStrokeWidth(dp(1));
        canvas.drawLine(dp(9),bottom,width-dp(9),bottom,paint);
        paint.setStyle(Paint.Style.FILL);
        double max=0;for(double v:amounts)max=Math.max(max,v);
        if(max<=0){paint.setColor(0xff536975);paint.setTextAlign(Paint.Align.CENTER);paint.setTextSize(sp(13));
            canvas.drawText("该时段没有签约记录",width/2,height/2,paint);return;}
        int columns=Math.max(1,amounts.length);
        float slot=(width-dp(18))/columns;
        float bw=Math.min(dp(27),slot*.57f);
        for(int i=0;i<columns;i++){
            float x=dp(9)+slot*(i+.5f);
            float barHeight=(float)(Math.max(0,amounts[i])/max*(usable-dp(29)));
            if(barHeight>0){
                paint.setShader(new LinearGradient(x,bottom-barHeight,x,bottom,0xff53c9b1,0xff0d9889,Shader.TileMode.CLAMP));
                canvas.drawRoundRect(new RectF(x-bw/2,bottom-barHeight,x+bw/2,bottom),dp(4),dp(4),paint);
                paint.setShader(null);
            }
            paint.setTextAlign(Paint.Align.CENTER);paint.setColor(0xff506573);paint.setTextSize(Math.min(sp(11),slot*.32f));
            canvas.drawText(labels[i],x,height-dp(7),paint);
            if(scale<1.31f){
                paint.setColor(0xff2d4655);
                String text=brief(amounts[i]);float desired=sp(10.5f);
                paint.setTextSize(Math.min(desired,Math.max(dp(8),desired*slot/Math.max(slot,paint.measureText(text)+dp(4)))));
                canvas.drawText(text,x,bottom-barHeight-dp(5),paint);
            }
        }
    }
}
