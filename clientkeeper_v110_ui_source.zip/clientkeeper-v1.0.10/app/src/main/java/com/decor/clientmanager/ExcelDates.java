package com.decor.clientmanager;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.math.BigDecimal;

/** 支持Excel 1900/1904日期系统、文本日期；错误日期明确拒绝，不改为今天。 */
final class ExcelDates {
    private ExcelDates(){}
    static long parse(String raw,boolean date1904){
        if(raw==null||raw.trim().isEmpty())throw new IllegalArgumentException("获客日期为空");
        String text=raw.trim();
        if(text.matches("[0-9]{4,5}(\\.[0-9]+)?")){
            double days;
            try{days=new BigDecimal(text).doubleValue();}catch(NumberFormatException e){throw new IllegalArgumentException("Excel日期无效");}
            if(!Double.isFinite(days)||days<1||days>2958465)throw new IllegalArgumentException("Excel日期序列不合法");
            Calendar calendar=Calendar.getInstance();calendar.clear();calendar.set(date1904?1904:1899,date1904?0:11,date1904?1:30,0,0,0);
            calendar.add(Calendar.DATE,(int)Math.floor(days));
            calendar.add(Calendar.SECOND,(int)Math.round((days-Math.floor(days))*86400));
            return calendar.getTimeInMillis();
        }
        String[] patterns={"yyyy-MM-dd HH:mm:ss","yyyy-MM-dd HH:mm","yyyy-MM-dd","yyyy/M/d H:mm","yyyy/M/d","yyyy年M月d日","yyyy.M.d"};
        for(String pattern:patterns){SimpleDateFormat fmt=new SimpleDateFormat(pattern,Locale.CHINA);fmt.setLenient(false);
            ParsePosition p=new ParsePosition(0);Date date=fmt.parse(text,p);
            if(date!=null&&p.getIndex()==text.length())return date.getTime();
        }
        throw new IllegalArgumentException("无法识别的获客日期："+text);
    }
    static String formatDate(long millis){return new SimpleDateFormat("yyyy-MM-dd",Locale.CHINA).format(new Date(millis));}
}
