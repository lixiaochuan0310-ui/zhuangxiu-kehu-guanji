package com.decor.clientmanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

/** 个人离线客户数据库。合同、提成到账独立于随时可能变化的客户业务进展。 */
public final class Db extends SQLiteOpenHelper {
    static final String[] SOURCES={"电话","微信","跑小区","门店","熟人介绍","其他"};
    static final String[] STAGES={"新客户","已联系","有意向","已量房","已报价","已签约","暂不考虑"};
    static final String[] INTENTS={"待判断","高意向","一般意向","低意向"};
    static final String[] RENOVATIONS={"未确定","新房装修","旧房翻新","局部装修"};
    Db(Context context){super(context,"decoration_clients.db",null,3);}
    static final String CLIENT_TABLE="CREATE TABLE clients (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL DEFAULT '',phone TEXT NOT NULL DEFAULT '',wechat TEXT NOT NULL DEFAULT '',source TEXT NOT NULL DEFAULT '其他',community TEXT NOT NULL DEFAULT '',building TEXT NOT NULL DEFAULT '',area TEXT NOT NULL DEFAULT '',budget TEXT NOT NULL DEFAULT '',renovation_type TEXT NOT NULL DEFAULT '未确定',needs TEXT NOT NULL DEFAULT '',notes TEXT NOT NULL DEFAULT '',stage TEXT NOT NULL DEFAULT '新客户',intent TEXT NOT NULL DEFAULT '待判断',signed_at INTEGER NOT NULL DEFAULT 0,contract_amount REAL NOT NULL DEFAULT 0,commission_rate REAL NOT NULL DEFAULT 0,commission_type TEXT NOT NULL DEFAULT 'percent',fixed_commission REAL NOT NULL DEFAULT 0,received_amount REAL NOT NULL DEFAULT 0,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL,acquired_at INTEGER NOT NULL DEFAULT 0)";
    static final String CONTRACT_TABLE="CREATE TABLE contracts (id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,signed_at INTEGER NOT NULL,amount REAL NOT NULL CHECK(amount>=0),commission_type TEXT NOT NULL CHECK(commission_type IN ('percent','fixed')),commission_rate REAL NOT NULL DEFAULT 0,fixed_commission REAL NOT NULL DEFAULT 0,note TEXT NOT NULL DEFAULT '')";
    static final String RECEIPT_TABLE="CREATE TABLE receipts (id INTEGER PRIMARY KEY AUTOINCREMENT,contract_id INTEGER NOT NULL REFERENCES contracts(id) ON DELETE CASCADE,received_at INTEGER NOT NULL,amount REAL NOT NULL CHECK(amount>0),note TEXT NOT NULL DEFAULT '')";
    @Override public void onConfigure(SQLiteDatabase d){super.onConfigure(d);d.setForeignKeyConstraintsEnabled(true);}
    @Override public void onCreate(SQLiteDatabase d){
        d.execSQL(CLIENT_TABLE);
        d.execSQL("CREATE TABLE followups (id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,happened_at INTEGER NOT NULL,content TEXT NOT NULL DEFAULT '')");
        d.execSQL("CREATE TABLE reminders (id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,due_at INTEGER NOT NULL,content TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','done')))");
        d.execSQL(CONTRACT_TABLE);d.execSQL(RECEIPT_TABLE);
        d.execSQL("CREATE INDEX idx_client_phone ON clients(phone)");d.execSQL("CREATE INDEX idx_reminder_due ON reminders(status,due_at)");
        d.execSQL("CREATE INDEX idx_follow_client ON followups(client_id,happened_at)");
        d.execSQL("CREATE INDEX idx_contract_client ON contracts(client_id,signed_at)");
        d.execSQL("CREATE INDEX idx_receipt_month ON receipts(received_at)");
    }
    @Override public void onUpgrade(SQLiteDatabase d,int from,int to){
        if(from<2){d.execSQL("ALTER TABLE clients ADD COLUMN commission_type TEXT NOT NULL DEFAULT 'percent'");d.execSQL("ALTER TABLE clients ADD COLUMN fixed_commission REAL NOT NULL DEFAULT 0");}
        if(from<3){
            d.execSQL("ALTER TABLE clients ADD COLUMN acquired_at INTEGER NOT NULL DEFAULT 0");
            d.execSQL("UPDATE clients SET acquired_at=created_at");
            d.execSQL(CONTRACT_TABLE);d.execSQL(RECEIPT_TABLE);
            d.execSQL("CREATE INDEX idx_contract_client ON contracts(client_id,signed_at)");
            d.execSQL("CREATE INDEX idx_receipt_month ON receipts(received_at)");
            // 旧版本只有累计已收、没有收款日期：转为“历史到账（日期不详）”，不得伪造月份。
            d.execSQL("INSERT INTO contracts(client_id,signed_at,amount,commission_type,commission_rate,fixed_commission,note) SELECT id,signed_at,contract_amount,CASE WHEN commission_type='fixed' THEN 'fixed' ELSE 'percent' END,commission_rate,fixed_commission,'旧版合同自动迁移' FROM clients WHERE signed_at>0");
            d.execSQL("INSERT INTO receipts(contract_id,received_at,amount,note) SELECT contracts.id,0,clients.received_amount,'旧版累计已收，日期未记录（可编辑补录）' FROM contracts JOIN clients ON clients.id=contracts.client_id WHERE clients.received_amount>0");
        }
    }
    static class Client {
        long id,signedAt,createdAt,updatedAt,acquiredAt;
        String name="",phone="",wechat="",source="其他",community="",building="",area="",budget="",renovationType="未确定",needs="",notes="",stage="新客户",intent="待判断";
        double contractAmount,commissionRate,fixedCommission,receivedAmount;
        String commissionType="percent";
        String displayName(){return name.isEmpty()?(phone.isEmpty()?"未命名客户":phone):name;}
        double expected(){return CommissionRule.expected(commissionType,contractAmount,commissionRate,fixedCommission);}
    }
    static class Contract {
        long id,clientId,signedAt;double amount,commissionRate,fixedCommission;String commissionType="percent",note="";
        double expected(){return CommissionRule.expected(commissionType,amount,commissionRate,fixedCommission);}
    }
    static class Receipt {long id,contractId,receivedAt;double amount;String note="";}
    static class Follow {long id,clientId,happenedAt;String content;}
    static class Task {long id,clientId,dueAt;String clientName,community,content,status;boolean overdue(){return "pending".equals(status)&&dueAt<System.currentTimeMillis();}}
    static class Stats {int customers,highIntent,monthSigned;double monthAmount,monthExpected,monthReceived;}
    static class SourceStats {String source;int customers,signed;SourceStats(String name){source=name;}}
    private static String value(Cursor c,String col){String v=c.getString(c.getColumnIndexOrThrow(col));return v==null?"":v;}
    private static Client readClient(Cursor cur){
        Client c=new Client();c.id=cur.getLong(cur.getColumnIndexOrThrow("id"));
        c.name=value(cur,"name");c.phone=value(cur,"phone");c.wechat=value(cur,"wechat");c.source=value(cur,"source");
        c.community=value(cur,"community");c.building=value(cur,"building");c.area=value(cur,"area");c.budget=value(cur,"budget");
        c.renovationType=value(cur,"renovation_type");c.needs=value(cur,"needs");c.notes=value(cur,"notes");
        c.stage=value(cur,"stage");c.intent=value(cur,"intent");c.signedAt=cur.getLong(cur.getColumnIndexOrThrow("signed_at"));
        c.contractAmount=cur.getDouble(cur.getColumnIndexOrThrow("contract_amount"));c.commissionRate=cur.getDouble(cur.getColumnIndexOrThrow("commission_rate"));
        c.commissionType=value(cur,"commission_type");c.fixedCommission=cur.getDouble(cur.getColumnIndexOrThrow("fixed_commission"));
        c.receivedAmount=cur.getDouble(cur.getColumnIndexOrThrow("received_amount"));
        c.createdAt=cur.getLong(cur.getColumnIndexOrThrow("created_at"));c.updatedAt=cur.getLong(cur.getColumnIndexOrThrow("updated_at"));
        c.acquiredAt=cur.getLong(cur.getColumnIndexOrThrow("acquired_at"));return c;
    }
    List<Client> clients(String search,String stage,String intent){
        List<Client> out=new ArrayList<>();StringBuilder where=new StringBuilder("1=1");List<String> args=new ArrayList<>();
        if(search!=null&&!search.trim().isEmpty()){
            where.append(" AND (name LIKE ? ESCAPE '\\' OR phone LIKE ? ESCAPE '\\' OR wechat LIKE ? ESCAPE '\\' OR community LIKE ? ESCAPE '\\' OR building LIKE ? ESCAPE '\\')");
            String safe=search.trim().replace("\\","\\\\").replace("%","\\%").replace("_","\\_");
            for(int i=0;i<5;i++)args.add("%"+safe+"%");
        }
        if(stage!=null&&!stage.equals("全部状态")){where.append(" AND stage=?");args.add(stage);}
        if(intent!=null&&!intent.equals("全部意向")){where.append(" AND intent=?");args.add(intent);}
        try(Cursor cur=getReadableDatabase().query("clients",null,where.toString(),args.toArray(new String[0]),null,null,"updated_at DESC,id DESC")){while(cur.moveToNext())out.add(readClient(cur));}return out;
    }
    Client client(long id){try(Cursor cur=getReadableDatabase().query("clients",null,"id=?",new String[]{String.valueOf(id)},null,null,null)){return cur.moveToFirst()?readClient(cur):null;}}
    long duplicatePhone(String phone,long skipId){if(phone==null||phone.trim().isEmpty())return 0;
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id FROM clients WHERE phone=? AND id!=? LIMIT 1",new String[]{phone.trim(),String.valueOf(skipId)})){return c.moveToFirst()?c.getLong(0):0;}}
    long saveClient(Client c){long now=System.currentTimeMillis();ContentValues v=new ContentValues();
        v.put("name",c.name.trim());v.put("phone",c.phone.trim());v.put("wechat",c.wechat.trim());v.put("source",c.source);
        v.put("community",c.community.trim());v.put("building",c.building.trim());v.put("area",c.area.trim());v.put("budget",c.budget.trim());
        v.put("renovation_type",c.renovationType);v.put("needs",c.needs.trim());v.put("notes",c.notes.trim());
        v.put("stage",c.stage);v.put("intent",c.intent);v.put("updated_at",now);
        v.put("acquired_at",c.acquiredAt>0?c.acquiredAt:now);
        // 不再根据业务进展增删旧签约日期，合同由 contracts 表永久管理。
        if(c.id<=0){v.put("created_at",now);return getWritableDatabase().insertOrThrow("clients",null,v);}
        getWritableDatabase().update("clients",v,"id=?",new String[]{String.valueOf(c.id)});return c.id;
    }
    void deleteClient(long id){getWritableDatabase().delete("clients","id=?",new String[]{String.valueOf(id)});}
    int countClients(){try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM clients",null)){return c.moveToFirst()?c.getInt(0):0;}}
    int countHigh(){try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM clients WHERE intent='高意向'",null)){return c.moveToFirst()?c.getInt(0):0;}}
    List<Follow> follows(long clientId){List<Follow> out=new ArrayList<>();try(Cursor c=getReadableDatabase().query("followups",null,"client_id=?",new String[]{""+clientId},null,null,"happened_at DESC,id DESC")){
        while(c.moveToNext()){Follow f=new Follow();f.id=c.getLong(c.getColumnIndexOrThrow("id"));f.clientId=clientId;f.happenedAt=c.getLong(c.getColumnIndexOrThrow("happened_at"));f.content=value(c,"content");out.add(f);}}return out;}
    long addFollow(long clientId,long at,String content){ContentValues v=new ContentValues();v.put("client_id",clientId);v.put("happened_at",at);v.put("content",content.trim());return getWritableDatabase().insertOrThrow("followups",null,v);}
    void updateFollow(long id,long at,String content){ContentValues v=new ContentValues();v.put("happened_at",at);v.put("content",content.trim());getWritableDatabase().update("followups",v,"id=?",new String[]{""+id});}
    void deleteFollow(long id){getWritableDatabase().delete("followups","id=?",new String[]{""+id});}
    long addTask(long clientId,long dueAt,String content){ContentValues v=new ContentValues();v.put("client_id",clientId);v.put("due_at",dueAt);v.put("content",content.trim());v.put("status","pending");return getWritableDatabase().insertOrThrow("reminders",null,v);}
    void updateTask(long id,long dueAt,String content){ContentValues v=new ContentValues();v.put("due_at",dueAt);v.put("content",content.trim());getWritableDatabase().update("reminders",v,"id=?",new String[]{""+id});}
    void completeTask(long id){ContentValues v=new ContentValues();v.put("status","done");getWritableDatabase().update("reminders",v,"id=?",new String[]{""+id});}
    void reopenTask(long id){ContentValues v=new ContentValues();v.put("status","pending");getWritableDatabase().update("reminders",v,"id=?",new String[]{""+id});}
    void deleteTask(long id){getWritableDatabase().delete("reminders","id=?",new String[]{""+id});}
    Task task(long id){try(Cursor c=getReadableDatabase().rawQuery("SELECT r.id,r.client_id,r.due_at,r.content,r.status,c.name,c.phone,c.community FROM reminders r JOIN clients c ON c.id=r.client_id WHERE r.id=?",new String[]{""+id})){return c.moveToFirst()?readTask(c):null;}}
    private Task readTask(Cursor c){Task t=new Task();t.id=c.getLong(0);t.clientId=c.getLong(1);t.dueAt=c.getLong(2);t.content=c.getString(3);t.status=c.getString(4);String name=c.getString(5),phone=c.getString(6);t.clientName=name==null||name.isEmpty()?phone:name;t.community=c.getString(7);return t;}
    List<Task> tasks(String mode,long clientId){List<Task> out=new ArrayList<>();String where="1=1";List<String>a=new ArrayList<>();
        if(clientId>0){where+=" AND r.client_id=?";a.add(""+clientId);}if("待处理".equals(mode))where+=" AND r.status='pending'";if("已完成".equals(mode))where+=" AND r.status='done'";
        try(Cursor c=getReadableDatabase().rawQuery("SELECT r.id,r.client_id,r.due_at,r.content,r.status,c.name,c.phone,c.community FROM reminders r JOIN clients c ON c.id=r.client_id WHERE "+where+" ORDER BY CASE WHEN r.status='pending' THEN 0 ELSE 1 END,r.due_at ASC",a.toArray(new String[0]))){while(c.moveToNext())out.add(readTask(c));}return out;}
    int todayCount(){java.util.Calendar c=java.util.Calendar.getInstance();c.set(java.util.Calendar.HOUR_OF_DAY,0);c.set(java.util.Calendar.MINUTE,0);c.set(java.util.Calendar.SECOND,0);c.set(java.util.Calendar.MILLISECOND,0);c.add(java.util.Calendar.DAY_OF_MONTH,1);
        try(Cursor cur=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM reminders WHERE status='pending' AND due_at<?",new String[]{""+c.getTimeInMillis()})){return cur.moveToFirst()?cur.getInt(0):0;}}
    private static Contract readContract(Cursor c){Contract x=new Contract();x.id=c.getLong(c.getColumnIndexOrThrow("id"));x.clientId=c.getLong(c.getColumnIndexOrThrow("client_id"));x.signedAt=c.getLong(c.getColumnIndexOrThrow("signed_at"));x.amount=c.getDouble(c.getColumnIndexOrThrow("amount"));x.commissionType=value(c,"commission_type");x.commissionRate=c.getDouble(c.getColumnIndexOrThrow("commission_rate"));x.fixedCommission=c.getDouble(c.getColumnIndexOrThrow("fixed_commission"));x.note=value(c,"note");return x;}
    List<Contract> getContracts(long clientId){List<Contract> out=new ArrayList<>();try(Cursor c=getReadableDatabase().query("contracts",null,"client_id=?",new String[]{""+clientId},null,null,"signed_at DESC,id DESC")){while(c.moveToNext())out.add(readContract(c));}return out;}
    Contract contract(long id){try(Cursor c=getReadableDatabase().query("contracts",null,"id=?",new String[]{""+id},null,null,null)){return c.moveToFirst()?readContract(c):null;}}
    List<Contract> contractsMonth(long start,long end){List<Contract> out=new ArrayList<>();try(Cursor c=getReadableDatabase().query("contracts",null,"signed_at>=? AND signed_at<?",new String[]{""+start,""+end},null,null,"signed_at DESC")){while(c.moveToNext())out.add(readContract(c));}return out;}
    long saveContract(Contract contract){ContentValues v=new ContentValues();v.put("client_id",contract.clientId);v.put("signed_at",contract.signedAt);v.put("amount",contract.amount);v.put("commission_type",contract.commissionType);v.put("commission_rate",contract.commissionRate);v.put("fixed_commission",contract.fixedCommission);v.put("note",contract.note.trim());
        if(contract.id>0){getWritableDatabase().update("contracts",v,"id=?",new String[]{""+contract.id});return contract.id;}
        return getWritableDatabase().insertOrThrow("contracts",null,v);}
    void deleteContract(long id){getWritableDatabase().delete("contracts","id=?",new String[]{""+id});}
    private static Receipt readReceipt(Cursor c){Receipt r=new Receipt();r.id=c.getLong(c.getColumnIndexOrThrow("id"));r.contractId=c.getLong(c.getColumnIndexOrThrow("contract_id"));r.receivedAt=c.getLong(c.getColumnIndexOrThrow("received_at"));r.amount=c.getDouble(c.getColumnIndexOrThrow("amount"));r.note=value(c,"note");return r;}
    List<Receipt> receipts(long contractId){List<Receipt> out=new ArrayList<>();try(Cursor c=getReadableDatabase().query("receipts",null,"contract_id=?",new String[]{""+contractId},null,null,"received_at DESC,id DESC")){while(c.moveToNext())out.add(readReceipt(c));}return out;}
    Receipt receipt(long id){try(Cursor c=getReadableDatabase().query("receipts",null,"id=?",new String[]{""+id},null,null,null)){return c.moveToFirst()?readReceipt(c):null;}}
    List<Receipt> receiptsMonth(long start,long end){List<Receipt> out=new ArrayList<>();try(Cursor c=getReadableDatabase().query("receipts",null,"received_at>=? AND received_at<?",new String[]{""+start,""+end},null,null,"received_at DESC")){while(c.moveToNext())out.add(readReceipt(c));}return out;}
    long addReceipt(Receipt receipt){ContentValues v=new ContentValues();v.put("contract_id",receipt.contractId);v.put("received_at",receipt.receivedAt);v.put("amount",receipt.amount);v.put("note",receipt.note.trim());
        if(receipt.id>0){getWritableDatabase().update("receipts",v,"id=?",new String[]{""+receipt.id});return receipt.id;}
        return getWritableDatabase().insertOrThrow("receipts",null,v);}
    void deleteReceipt(long id){getWritableDatabase().delete("receipts","id=?",new String[]{""+id});}
    double receivedForContract(long id){try(Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM receipts WHERE contract_id=?",new String[]{""+id})){return c.moveToFirst()?c.getDouble(0):0;}}
    Stats stats(long monthStart,long nextMonthStart){Stats s=new Stats();s.customers=countClients();s.highIntent=countHigh();String[] args={""+monthStart,""+nextMonthStart};
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(DISTINCT client_id),COALESCE(SUM(amount),0),COALESCE(SUM(CASE WHEN commission_type='fixed' THEN fixed_commission ELSE amount*commission_rate/100.0 END),0) FROM contracts WHERE signed_at>=? AND signed_at<?",args)){
            if(c.moveToFirst()){s.monthSigned=c.getInt(0);s.monthAmount=c.getDouble(1);s.monthExpected=c.getDouble(2);}}
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM receipts WHERE received_at>=? AND received_at<?",args)){if(c.moveToFirst())s.monthReceived=c.getDouble(0);}return s;
    }
    List<SourceStats> sourceStats(long monthStart,long nextMonthStart){List<SourceStats> stats=new ArrayList<>();for(String x:SOURCES){SourceStats s=new SourceStats(x);
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM clients WHERE source=? AND acquired_at>=? AND acquired_at<?",new String[]{x,""+monthStart,""+nextMonthStart})){if(c.moveToFirst())s.customers=c.getInt(0);}
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(DISTINCT contracts.client_id) FROM contracts JOIN clients ON clients.id=contracts.client_id WHERE clients.source=? AND contracts.signed_at>=? AND contracts.signed_at<?",new String[]{x,""+monthStart,""+nextMonthStart})){if(c.moveToFirst())s.signed=c.getInt(0);}stats.add(s);
    }return stats;}
}
