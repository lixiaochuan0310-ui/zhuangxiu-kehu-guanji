from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
java=root/'app/src/main/java/com/decor/clientmanager/CommissionRule.java'
with tempfile.TemporaryDirectory() as d:
 test=Path(d)/'CommissionTest.java';test.write_text('''package com.decor.clientmanager;
public class CommissionTest {
public static void main(String[] a){
assertEq(CommissionRule.expected("percent",150000,3,0),4500);
assertEq(CommissionRule.expected("fixed",150000,3,2000),2000);
assertEq(CommissionRule.expected("fixed",0,0,1000),1000);
assertEq(CommissionRule.expected("percent",100000,0,1000),0);
}static void assertEq(double a,double b){if(Math.abs(a-b)>.001)throw new AssertionError(a+" vs "+b);}
}''')
 subprocess.run(['javac','-encoding','UTF-8','-d',d,str(java),str(test)],check=True)
 subprocess.run(['java','-cp',d,'com.decor.clientmanager.CommissionTest'],check=True)
print('PASS 提成计算：比例/固定/零值')
