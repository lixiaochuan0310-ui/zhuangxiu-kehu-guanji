#!/usr/bin/env python3
"""提成方式、数据库升级与原备份兼容性验证（不替代 Android 编译）。"""
from pathlib import Path
import re, sqlite3, subprocess, tempfile
p = Path(__file__).resolve().parents[1]
src = p/'app/src/main/java/com/decor/clientmanager'
db = (src/'Db.java').read_text()
ui = (src/'MainActivity.java').read_text()
transfer = (src/'Transfer.java').read_text()
assert 'commission_type TEXT NOT NULL DEFAULT' in db
assert 'fixed_commission REAL NOT NULL DEFAULT 0' in db
assert 'super(context, "decoration_clients.db", null, 2)' in db
assert 'ALTER TABLE clients ADD COLUMN commission_type' in db
assert 'ALTER TABLE clients ADD COLUMN fixed_commission' in db
assert 'c.commissionType' in db and 'c.fixedCommission' in db
assert 'SUM(CASE WHEN commission_type=' in db
assert 'CommissionRule.expected(commissionType,contractAmount,commissionRate,fixedCommission)' in db
assert '固定金额' in ui and '按比例' in ui and '固定提成金额（元）' in ui
assert 'commission_type' in transfer and 'fixed_commission' in transfer
assert 'if(version == 1 && t==0)' in transfer and 'data.put("version",2)' in transfer
assert '固定提成金额(元)' in transfer
# Verify fresh SQLite and safe V1-to-V2 data migration with production statements.
sqls = re.findall(r'db\.execSQL\("(CREATE (?:TABLE|INDEX) .*?)"\);', db)
assert len(sqls)==6
fresh=sqlite3.connect(':memory:')
for sql in sqls: fresh.execute(sql)
cols=[x[1] for x in fresh.execute('PRAGMA table_info(clients)')]
assert 'commission_type' in cols and 'fixed_commission' in cols
legacy=sqlite3.connect(':memory:')
for sql in sqls:
    legacy.execute(sql.replace(", commission_type TEXT NOT NULL DEFAULT 'percent', fixed_commission REAL NOT NULL DEFAULT 0", ""))
legacy.execute('INSERT INTO clients(name,created_at,updated_at,contract_amount,commission_rate) VALUES(?,?,?,?,?)',('老客户',1,1,150000,3))
legacy.execute('INSERT INTO followups(client_id,happened_at,content) VALUES(?,?,?)',(1,1,'保留历史'))
legacy.execute('INSERT INTO reminders(client_id,due_at,content) VALUES(?,?,?)',(1,1,'保留提醒'))
for sql in re.findall(r'db\.execSQL\("(ALTER TABLE clients .*?)"\);', db):
    legacy.execute(sql)
assert legacy.execute('SELECT content FROM followups').fetchone()[0]=='保留历史'
assert legacy.execute('SELECT content FROM reminders').fetchone()[0]=='保留提醒'
row=legacy.execute('SELECT commission_type,fixed_commission,contract_amount*commission_rate/100.0 FROM clients').fetchone()
assert row==('percent',0,4500),row
legacy.execute("UPDATE clients SET commission_type='fixed',fixed_commission=2000")
assert legacy.execute("SELECT CASE WHEN commission_type='fixed' THEN fixed_commission ELSE contract_amount*commission_rate/100.0 END FROM clients").fetchone()[0]==2000
# Compile and execute real Java calculation, independent of Android SDK.
calculator=src/'CommissionRule.java'
assert calculator.exists()
with tempfile.TemporaryDirectory() as tmp:
    test=Path(tmp)/'CommissionRuleTest.java'
    test.write_text('''package com.decor.clientmanager;\npublic class CommissionRuleTest {\n  public static void main(String[] args) {\n    check(CommissionRule.expected("percent",150000,3,0),4500);\n    check(CommissionRule.expected("fixed",150000,3,2000),2000);\n    check(CommissionRule.expected("fixed",0,0,800),800);\n    check(CommissionRule.expected("percent",100000,0,800),0);\n  }\n  static void check(double actual,double desired) {if(Math.abs(actual-desired)>0.001)throw new RuntimeException(actual+" != "+desired);}\n}\n''')
    subprocess.run(['javac','-encoding','UTF-8','-d',tmp,str(calculator),str(test)],check=True)
    subprocess.run(['java','-cp',tmp,'com.decor.clientmanager.CommissionRuleTest'],check=True)
print('提成模式选择、数据库旧版迁移、金额计算、旧备份兼容接口与导出结构：通过（源码级）')
