package com.decor.clientmanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

/** 仅在应用私有目录存储客户信息，绝不访问网络。 */
public final class Db extends SQLiteOpenHelper {
    static final String[] SOURCES = {"电话", "微信", "跑小区", "门店", "熟人介绍", "其他"};
    static final String[] STAGES = {"新客户", "已联系", "有意向", "已量房", "已报价", "已签约", "暂不考虑"};
    static final String[] INTENTS = {"待判断", "高意向", "一般意向", "低意向"};
    static final String[] RENOVATIONS = {"未确定", "新房装修", "旧房翻新", "局部装修"};

    Db(Context context) { super(context, "decoration_clients.db", null, 2); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE clients (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '', wechat TEXT NOT NULL DEFAULT '', source TEXT NOT NULL DEFAULT '其他', community TEXT NOT NULL DEFAULT '', building TEXT NOT NULL DEFAULT '', area TEXT NOT NULL DEFAULT '', budget TEXT NOT NULL DEFAULT '', renovation_type TEXT NOT NULL DEFAULT '未确定', needs TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', stage TEXT NOT NULL DEFAULT '新客户', intent TEXT NOT NULL DEFAULT '待判断', signed_at INTEGER NOT NULL DEFAULT 0, contract_amount REAL NOT NULL DEFAULT 0, commission_rate REAL NOT NULL DEFAULT 0, commission_type TEXT NOT NULL DEFAULT 'percent', fixed_commission REAL NOT NULL DEFAULT 0, received_amount REAL NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE followups (id INTEGER PRIMARY KEY AUTOINCREMENT, client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE, happened_at INTEGER NOT NULL, content TEXT NOT NULL DEFAULT '')");
        db.execSQL("CREATE TABLE reminders (id INTEGER PRIMARY KEY AUTOINCREMENT, client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE, due_at INTEGER NOT NULL, content TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','done'))) ");
        db.execSQL("CREATE INDEX idx_client_phone ON clients(phone)");
        db.execSQL("CREATE INDEX idx_reminder_due ON reminders(status,due_at)");
        db.execSQL("CREATE INDEX idx_follow_client ON followups(client_id,happened_at)");
    }
    @Override public void onConfigure(SQLiteDatabase db) { super.onConfigure(db); db.setForeignKeyConstraintsEnabled(true); }
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) {
        // V1 users' client records and follow-up/reminder tables remain untouched.
        if(oldVersion<2){
            db.execSQL("ALTER TABLE clients ADD COLUMN commission_type TEXT NOT NULL DEFAULT 'percent'");
            db.execSQL("ALTER TABLE clients ADD COLUMN fixed_commission REAL NOT NULL DEFAULT 0");
        }
    }

    static class Client {
        long id, signedAt, createdAt, updatedAt;
        String name="", phone="", wechat="", source="其他", community="", building="", area="", budget="", renovationType="未确定", needs="", notes="", stage="新客户", intent="待判断";
        double contractAmount, commissionRate, fixedCommission, receivedAmount;
        String commissionType="percent";
        String displayName() { return name.isEmpty() ? (phone.isEmpty()?"未命名客户":phone) : name; }
        double expected() { return CommissionRule.expected(commissionType,contractAmount,commissionRate,fixedCommission); }
    }
    static class Follow {
        long id, clientId, happenedAt;
        String content;
    }
    static class Task {
        long id, clientId, dueAt;
        String clientName, community, content, status;
        boolean overdue() { return "pending".equals(status) && dueAt < System.currentTimeMillis(); }
    }
    static class Stats {
        int customers, highIntent, monthSigned;
        double monthAmount, monthExpected, monthReceived;
    }

    private static String value(Cursor c, String column) { String v=c.getString(c.getColumnIndexOrThrow(column)); return v==null?"":v; }
    private static Client readClient(Cursor cur) {
        Client c=new Client();
        c.id=cur.getLong(cur.getColumnIndexOrThrow("id"));
        c.name=value(cur,"name"); c.phone=value(cur,"phone"); c.wechat=value(cur,"wechat");
        c.source=value(cur,"source"); c.community=value(cur,"community"); c.building=value(cur,"building");
        c.area=value(cur,"area"); c.budget=value(cur,"budget"); c.renovationType=value(cur,"renovation_type");
        c.needs=value(cur,"needs"); c.notes=value(cur,"notes"); c.stage=value(cur,"stage"); c.intent=value(cur,"intent");
        c.signedAt=cur.getLong(cur.getColumnIndexOrThrow("signed_at"));
        c.contractAmount=cur.getDouble(cur.getColumnIndexOrThrow("contract_amount"));
        c.commissionRate=cur.getDouble(cur.getColumnIndexOrThrow("commission_rate"));
        c.commissionType=value(cur,"commission_type");
        c.fixedCommission=cur.getDouble(cur.getColumnIndexOrThrow("fixed_commission"));
        c.receivedAmount=cur.getDouble(cur.getColumnIndexOrThrow("received_amount"));
        c.createdAt=cur.getLong(cur.getColumnIndexOrThrow("created_at")); c.updatedAt=cur.getLong(cur.getColumnIndexOrThrow("updated_at"));
        return c;
    }
    List<Client> clients(String search, String stage, String intent) {
        List<Client> out=new ArrayList<>();
        StringBuilder where=new StringBuilder("1=1"); List<String> args=new ArrayList<>();
        if(search!=null&&!search.trim().isEmpty()) {
            where.append(" AND (name LIKE ? ESCAPE '\\' OR phone LIKE ? ESCAPE '\\' OR wechat LIKE ? ESCAPE '\\' OR community LIKE ? ESCAPE '\\' OR building LIKE ? ESCAPE '\\')");
            String safe=search.trim().replace("\\","\\\\").replace("%","\\%").replace("_","\\_");
            for(int i=0;i<5;i++) args.add("%"+safe+"%");
        }
        if(stage!=null&&!stage.equals("全部状态")) { where.append(" AND stage=?"); args.add(stage); }
        if(intent!=null&&!intent.equals("全部意向")) { where.append(" AND intent=?"); args.add(intent); }
        try(Cursor cur=getReadableDatabase().query("clients",null,where.toString(),args.toArray(new String[0]),null,null,"updated_at DESC,id DESC")) {
            while(cur.moveToNext()) out.add(readClient(cur));
        }
        return out;
    }
    Client client(long id) {
        try(Cursor cur=getReadableDatabase().query("clients",null,"id=?",new String[]{String.valueOf(id)},null,null,null)) {
            return cur.moveToFirst()?readClient(cur):null;
        }
    }
    long duplicatePhone(String phone,long skipId) {
        if(phone==null || phone.trim().isEmpty())return 0;
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id FROM clients WHERE phone=? AND id!=? LIMIT 1",new String[]{phone.trim(),String.valueOf(skipId)})) { return c.moveToFirst()?c.getLong(0):0; }
    }
    long saveClient(Client c) {
        long now=System.currentTimeMillis(); ContentValues v=new ContentValues();
        v.put("name",c.name.trim());v.put("phone",c.phone.trim());v.put("wechat",c.wechat.trim());
        v.put("source",c.source);v.put("community",c.community.trim());v.put("building",c.building.trim());
        v.put("area",c.area.trim());v.put("budget",c.budget.trim());v.put("renovation_type",c.renovationType);
        v.put("needs",c.needs.trim());v.put("notes",c.notes.trim());v.put("stage",c.stage);v.put("intent",c.intent);
        if("已签约".equals(c.stage)&&c.signedAt<=0)c.signedAt=now;
        if(!"已签约".equals(c.stage)) c.signedAt=0;
        v.put("signed_at",c.signedAt);v.put("contract_amount",Math.max(0,c.contractAmount));v.put("commission_rate",Math.max(0,c.commissionRate));
        v.put("commission_type","fixed".equals(c.commissionType)?"fixed":"percent");
        v.put("fixed_commission",Math.max(0,c.fixedCommission));
        v.put("received_amount",Math.max(0,c.receivedAmount));v.put("updated_at",now);
        if(c.id<=0){ v.put("created_at",now);return getWritableDatabase().insertOrThrow("clients",null,v); }
        getWritableDatabase().update("clients",v,"id=?",new String[]{String.valueOf(c.id)});return c.id;
    }
    void deleteClient(long id) {
        SQLiteDatabase db=getWritableDatabase();
        db.delete("clients","id=?",new String[]{String.valueOf(id)});
    }
    int countClients() {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM clients",null)){return c.moveToFirst()?c.getInt(0):0;}
    }
    int countHigh() {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM clients WHERE intent='高意向'",null)){return c.moveToFirst()?c.getInt(0):0;}
    }
    List<Follow> follows(long clientId) {
        List<Follow> out=new ArrayList<>();
        try(Cursor c=getReadableDatabase().query("followups",null,"client_id=?",new String[]{String.valueOf(clientId)},null,null,"happened_at DESC,id DESC")) {
            while(c.moveToNext()){Follow f=new Follow();f.id=c.getLong(c.getColumnIndexOrThrow("id"));f.clientId=clientId;f.happenedAt=c.getLong(c.getColumnIndexOrThrow("happened_at"));f.content=value(c,"content");out.add(f);}
        }
        return out;
    }
    void addFollow(long clientId,String content) {
        ContentValues v=new ContentValues();v.put("client_id",clientId);v.put("happened_at",System.currentTimeMillis());v.put("content",content.trim());getWritableDatabase().insertOrThrow("followups",null,v);
    }
    long addTask(long clientId,long dueAt,String content) {
        ContentValues v=new ContentValues();v.put("client_id",clientId);v.put("due_at",dueAt);v.put("content",content.trim());v.put("status","pending");return getWritableDatabase().insertOrThrow("reminders",null,v);
    }
    void updateTask(long id,long dueAt,String content) {
        ContentValues v=new ContentValues();v.put("due_at",dueAt);v.put("content",content.trim());
        getWritableDatabase().update("reminders",v,"id=? AND status='pending'",new String[]{String.valueOf(id)});
    }
    void completeTask(long id) {ContentValues v=new ContentValues();v.put("status","done");getWritableDatabase().update("reminders",v,"id=?",new String[]{String.valueOf(id)});}
    Task task(long id) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT r.id,r.client_id,r.due_at,r.content,r.status,c.name,c.phone,c.community FROM reminders r JOIN clients c ON c.id=r.client_id WHERE r.id=?",new String[]{String.valueOf(id)})) {
            return c.moveToFirst()?readTask(c):null;
        }
    }
    private Task readTask(Cursor c) {
        Task t=new Task();t.id=c.getLong(0);t.clientId=c.getLong(1);t.dueAt=c.getLong(2);t.content=c.getString(3);
        t.status=c.getString(4);String name=c.getString(5),phone=c.getString(6);t.clientName=name==null||name.isEmpty()?phone:name;t.community=c.getString(7);return t;
    }
    List<Task> tasks(String mode,long clientId) {
        List<Task> out=new ArrayList<>();
        String where="1=1";List<String> a=new ArrayList<>();
        if(clientId>0){where+=" AND r.client_id=?";a.add(String.valueOf(clientId));}
        if("待处理".equals(mode)){where+=" AND r.status='pending'";}
        if("已完成".equals(mode)){where+=" AND r.status='done'";}
        try(Cursor c=getReadableDatabase().rawQuery("SELECT r.id,r.client_id,r.due_at,r.content,r.status,c.name,c.phone,c.community FROM reminders r JOIN clients c ON c.id=r.client_id WHERE "+where+" ORDER BY CASE WHEN r.status='pending' THEN 0 ELSE 1 END, r.due_at ASC",a.toArray(new String[0]))) {
            while(c.moveToNext())out.add(readTask(c));
        }
        return out;
    }
    int todayCount() {
        java.util.Calendar c=java.util.Calendar.getInstance();c.set(java.util.Calendar.HOUR_OF_DAY,0);c.set(java.util.Calendar.MINUTE,0);c.set(java.util.Calendar.SECOND,0);c.set(java.util.Calendar.MILLISECOND,0);
        c.add(java.util.Calendar.DAY_OF_MONTH,1);long next=c.getTimeInMillis();
        try(Cursor cur=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM reminders WHERE status='pending' AND due_at<?",new String[]{String.valueOf(next)})){return cur.moveToFirst()?cur.getInt(0):0;}
    }
    Stats stats(long monthStart,long nextMonthStart){
        Stats s=new Stats();s.customers=countClients();s.highIntent=countHigh();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*),COALESCE(SUM(contract_amount),0),COALESCE(SUM(CASE WHEN commission_type='fixed' THEN fixed_commission ELSE contract_amount*commission_rate/100.0 END),0),COALESCE(SUM(received_amount),0) FROM clients WHERE stage='已签约' AND signed_at>=? AND signed_at<?",new String[]{String.valueOf(monthStart),String.valueOf(nextMonthStart)})){
            if(c.moveToFirst()){s.monthSigned=c.getInt(0);s.monthAmount=c.getDouble(1);s.monthExpected=c.getDouble(2);s.monthReceived=c.getDouble(3);}
        }
        return s;
    }
}
