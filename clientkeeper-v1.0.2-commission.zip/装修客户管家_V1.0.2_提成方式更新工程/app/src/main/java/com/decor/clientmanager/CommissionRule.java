package com.decor.clientmanager;

/** Pure numeric business rule used consistently by cards and contract details. */
final class CommissionRule {
    private CommissionRule() {}
    static double expected(String type,double contractAmount,double rate,double fixedAmount) {
        if("fixed".equals(type)) return Math.max(0,fixedAmount);
        return Math.max(0,contractAmount*rate/100.0);
    }
}
