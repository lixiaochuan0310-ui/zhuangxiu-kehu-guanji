package com.decor.clientmanager;
/** 六种客户来源的全局固定配色，图标和统计必须使用同一顺序。 */
final class SourcePalette {
    private static final int[] COLORS={0xff2461ab,0xff006f67,0xff275e99,0xff875200,0xff7543ad,0xff536c75};
    private SourcePalette(){}
    static int color(int index){return COLORS[Math.floorMod(index,COLORS.length)];}
}
