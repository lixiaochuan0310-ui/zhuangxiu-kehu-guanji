package com.decor.clientmanager;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** 本地矢量图标，不依赖网络、Emoji 字体或第三方素材。 */
public final class UiIcon extends View {
    private final String kind;
    private final int color;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    public UiIcon(Context c,String kind,int color){super(c);this.kind=kind;this.color=color;setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    private void line(float... pts){path.reset();path.moveTo(pts[0],pts[1]);for(int i=2;i<pts.length;i+=2)path.lineTo(pts[i],pts[i+1]);p.setStyle(Paint.Style.STROKE);getCanvas().drawPath(path,p);}
    private Canvas work;
    private Canvas getCanvas(){return work;}
    private void circle(float x,float y,float radius){p.setStyle(Paint.Style.STROKE);work.drawCircle(x,y,radius,p);}
    private void fillCircle(float x,float y,float radius){p.setStyle(Paint.Style.FILL);work.drawCircle(x,y,radius,p);}
    private void rect(float l,float t,float r,float b,float radius){p.setStyle(Paint.Style.STROKE);work.drawRoundRect(new RectF(l,t,r,b),radius,radius,p);}
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);work=canvas;canvas.save();
        float s=Math.min(getWidth(),getHeight())/24f;canvas.translate((getWidth()-24*s)/2f,(getHeight()-24*s)/2f);canvas.scale(s,s);
        p.setColor(color);p.setStrokeWidth(1.9f);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);p.setStyle(Paint.Style.STROKE);
        switch(kind){
            case "phone": line(7,3,4,3,3,6,3,10,7,16,13,21,17,21,21,17,21,14,18,13,15,16,12,12,8,9,11,6,7,3);break;
            case "chat": rect(3,4,21,17,5);line(8,17,6,21,13,17);line(7,9,17,9);line(7,13,14,13);break;
            case "walk": circle(13,4,2);line(12,7,9,11,5,13);line(12,7,16,11,20,12);line(9,11,13,14,10,21);line(13,14,18,21);break;
            case "store": line(3,10,5,4,19,4,21,10);line(4,12,4,21,20,21,20,12);line(9,21,9,15,15,15,15,21);line(3,10,7,10,9,12,12,10,15,12,17,10,21,10);break;
            case "users": circle(9,8,3);circle(17,9,2.4f);line(3,20,3,18,6,14,12,14,15,18,15,20,3,20);line(16,15,20,15,22,18,22,20,18,20);break;
            case "user": circle(12,7,4);line(4,21,4,19,7,14,17,14,20,19,20,21,4,21);break;
            case "other": fillCircle(5,12,1.7f);fillCircle(12,12,1.7f);fillCircle(19,12,1.7f);break;
            case "settings": circle(12,12,4);circle(12,12,9);line(12,1,12,3);line(12,21,12,23);line(1,12,3,12);line(21,12,23,12);break;
            case "home": line(2,11,12,3,22,11);line(5,10,5,21,19,21,19,10);line(10,21,10,15,14,15,14,21);break;
            case "bell": line(6,17,8,14,8,9,9,6,12,5,15,6,16,9,16,14,18,17,6,17);line(4,19,20,19);circle(12,20,1);break;
            case "chart": line(4,20,4,13,8,13,8,20);line(10,20,10,9,14,9,14,20);line(16,20,16,4,20,4,20,20);break;
            case "calendar": rect(3,5,21,21,2);line(3,10,21,10);line(8,2,8,7);line(16,2,16,7);line(8,15,11,18,17,12);break;
            case "star": path.reset();for(int i=0;i<10;i++){double a=-Math.PI/2+i*Math.PI/5;float r=i%2==0?10:4.3f;float x=12+(float)(r*Math.cos(a)),y=12+(float)(r*Math.sin(a));if(i==0)path.moveTo(x,y);else path.lineTo(x,y);}path.close();canvas.drawPath(path,p);break;
            case "coin": canvas.drawOval(new RectF(3,5,21,10),p);line(3,7,3,18,6,20,18,20,21,18,21,7);line(3,12,8,15,16,15,21,12);break;
            case "clipboard": rect(5,5,19,22,2);rect(9,2,15,7,1);line(9,12,15,12);line(9,16,15,16);break;
            case "clock": circle(12,12,9);line(12,7,12,12,16,14);break;
            case "edit": line(5,18,5,21,8,21,20,9,16,5,5,16,5,18);line(13,8,17,12);break;
            case "check": circle(12,12,9);line(7,12,11,16,17,9);break;
            case "database": canvas.drawOval(new RectF(3,4,21,9),p);line(3,7,3,19,6,21,18,21,21,19,21,7);line(3,13,7,15,17,15,21,13);break;
            case "cloud": line(6,19,4,18,3,15,4,12,7,10,9,10,11,6,15,6,18,10,21,12,21,16,18,19,6,19);break;
            case "excel": rect(4,3,20,21,2);line(8,8,16,16);line(16,8,8,16);break;
            case "mobile": rect(7,2,17,22,2);line(10,19,14,19);break;
            case "plus": line(12,4,12,20);line(4,12,20,12);break;
            case "arrow": line(8,5,15,12,8,19);break;
            case "house": line(2,10,12,3,22,10);line(5,10,5,21,19,21,19,10);break;
            default: circle(12,12,8);break;
        }
        canvas.restore();work=null;
    }
}
