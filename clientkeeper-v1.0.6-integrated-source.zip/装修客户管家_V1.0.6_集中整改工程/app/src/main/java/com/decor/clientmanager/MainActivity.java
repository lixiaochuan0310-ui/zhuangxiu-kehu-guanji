package com.decor.clientmanager;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.graphics.drawable.Drawable;
import java.util.ArrayList;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int BG=Color.rgb(246,250,251),WHITE=Color.WHITE,INK=Color.rgb(28,48,61),MUTED=Color.rgb(84,103,115);
    private static final int TEAL=Color.rgb(0,113,106),BLUE=Color.rgb(35,99,178),RED=Color.rgb(182,48,49),LINE=Color.rgb(226,236,239);
    private static final int REQUEST_FILE=200, REQUEST_NOTICE=300;
    private final String[] FONT_LABELS={"标准","大字体","超大字体","特大字体"};
    private final float[] FONT_SCALES={1.00f,1.15f,1.31f,1.52f};
    private Db db;
    private LinearLayout root,body;
    private ScrollView pageScroll;
    private String savedClientSearch="",savedClientStage=null,savedClientIntent=null,savedClientSource=null;
    private int savedClientScrollY=0, clientListLimit=60;
    private boolean restoreClientPosition=false;
    private int taskListLimit=60,savedTaskScrollY=0;
    private boolean restoreTaskPosition=false;
    private String currentPage="home",fileOperation="";
    private long currentClientId=0;
    private String lastTaskMode="今天", signedListReturn="home";
    private boolean taskFormFromList=false;
    private long editingTaskId=0;
    private int fontIndex=1;
    private MonthPeriod reportingMonth=MonthPeriod.current();

    @Override public void onCreate(Bundle b){super.onCreate(b);db=new Db(this);
        if(b!=null){fileOperation=b.getString("pending_file_operation","");savedClientSearch=b.getString("client_search","");
            savedClientStage=b.getString("client_stage");savedClientIntent=b.getString("client_intent");
            savedClientSource=b.getString("client_source");savedClientScrollY=b.getInt("client_scroll_y",0);
            clientListLimit=b.getInt("client_limit",60);
            taskListLimit=b.getInt("task_limit",60);savedTaskScrollY=b.getInt("task_scroll_y",0);}
        fontIndex=Math.max(0,Math.min(3,getPreferences(0).getInt("font_size",1)));
        long target=getIntent().getLongExtra("open_client_id",0);
        if(target>0&&db.client(target)!=null)showClient(target);else showHome();}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);
        long target=intent.getLongExtra("open_client_id",0);if(target>0 && db.client(target)!=null)showClient(target);}
    @Override protected void onSaveInstanceState(Bundle out){
        out.putString("pending_file_operation",fileOperation);
        out.putString("client_search",savedClientSearch);
        out.putString("client_stage",savedClientStage);
        out.putString("client_intent",savedClientIntent);
        out.putString("client_source",savedClientSource);
        out.putInt("client_scroll_y",savedClientScrollY);
        out.putInt("client_limit",clientListLimit);
        out.putInt("task_limit",taskListLimit);out.putInt("task_scroll_y",savedTaskScrollY);
        super.onSaveInstanceState(out);
    }
    @Override protected void onDestroy(){db.close();super.onDestroy();}
    @Override public void onBackPressed(){
        if("home".equals(currentPage)){super.onBackPressed();return;}
        if("client".equals(currentPage)){restoreClientPosition=true;showClients(savedClientSearch,savedClientStage,savedClientIntent,savedClientSource);return;}
        if("task_detail".equals(currentPage)||"reminder_picker".equals(currentPage)){
            restoreTaskPosition=true;showTasks(lastTaskMode);return;}
        if("signed_month".equals(currentPage)){if("mine".equals(signedListReturn))showStats();else showHome();return;}
        if("received_month".equals(currentPage)||"source_stats".equals(currentPage)){showStats();return;}
        if("receipt_form".equals(currentPage)&&currentClientId>0){showClient(currentClientId);return;}
        if("task_form".equals(currentPage)&&editingTaskId>0){showTaskDetail(editingTaskId);return;}
        if("task_form".equals(currentPage)&&taskFormFromList){showTasks(lastTaskMode);return;}
        if(("client_form".equals(currentPage)||"contract_form".equals(currentPage)||"follow_form".equals(currentPage)||"task_form".equals(currentPage))&&currentClientId>0){showClient(currentClientId);return;}
        showHome();
    }
    private int dp(float n){return (int)(getResources().getDisplayMetrics().density*n+0.5f);}
    private GradientDrawable shape(int fill,int radius,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private void pad(View v,int l,int t,int r,int b){v.setPadding(dp(l),dp(t),dp(r),dp(b));}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout.LayoutParams lp(int width,int height){return new LinearLayout.LayoutParams(width<0?width:dp(width),height<0?height:dp(height));}
    private void gap(LinearLayout l,int height){View v=new View(this);l.addView(v,lp(1,height));}
    private TextView txt(String value,float sp,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(TypedValue.COMPLEX_UNIT_SP,sp*FONT_SCALES[fontIndex]);t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);t.setIncludeFontPadding(true);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private TextView button(String title,boolean primary,View.OnClickListener action){TextView t=txt(title,15,primary?WHITE:TEAL,true);t.setGravity(Gravity.CENTER);t.setMinHeight(dp(50));
        t.setBackground(shape(primary?TEAL:Color.rgb(234,248,246),14,primary?0:Color.rgb(175,221,215)));pad(t,15,10,15,10);t.setOnClickListener(action);return t;}
    private TextView softButton(String title,View.OnClickListener action){TextView t=txt(title,14,BLUE,true);t.setGravity(Gravity.CENTER);t.setMinHeight(dp(46));
        t.setBackground(shape(Color.rgb(234,243,253),12,0));pad(t,13,8,13,8);t.setOnClickListener(action);return t;}
    private LinearLayout card(){LinearLayout l=vertical();l.setBackground(shape(WHITE,17,LINE));pad(l,13,13,13,13);l.setElevation(dp(1));return l;}
    private void addCard(LinearLayout parent,View card){LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(9);parent.addView(card,p);}
    private GradientDrawable gradient(int first,int last,int radius){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{first,last});d.setCornerRadius(dp(radius));return d;}
    private ImageView avatarView(String gender,int size){ImageView view=new ImageView(this);
        int resource="男".equals(gender)?R.drawable.avatar_male:"女".equals(gender)?R.drawable.avatar_female:R.drawable.avatar_neutral;
        view.setImageResource(resource);view.setScaleType(ImageView.ScaleType.FIT_CENTER);
        view.setContentDescription("男".equals(gender)?"男性默认头像":"女".equals(gender)?"女性默认头像":"未选择性别头像");return view;}
    private void sourceMiniChart(int[] values){
        LinearLayout chart=card();chart.addView(txt("客户来源分布",17,INK,true));gap(chart,9);
        int widthDp=(int)(getResources().getDisplayMetrics().widthPixels/getResources().getDisplayMetrics().density);
        boolean stacked=fontIndex>=2||widthDp<365;
        LinearLayout area=stacked?vertical():horizontal();
        SourceDonutView circle=new SourceDonutView(this,values,FONT_SCALES[fontIndex]);
        int height=fontIndex>=2?185:165;
        if(stacked){area.addView(circle,lp(-1,height));gap(area,8);}
        else area.addView(circle,new LinearLayout.LayoutParams(0,dp(height),1));
        LinearLayout legend=vertical();int total=0;for(int v:values)total+=Math.max(0,v);
        for(int i=0;i<Db.SOURCES.length;i++){
            LinearLayout one=horizontal();int c=SourcePalette.color(i);
            View dot=new View(this);dot.setBackground(shape(c,8,0));one.addView(dot,lp(10,10));
            TextView label=txt(Db.SOURCES[i]+" · "+(i<values.length?values[i]:0)+"人",13,INK,false);
            LinearLayout.LayoutParams pl=new LinearLayout.LayoutParams(0,-2,1);pl.leftMargin=dp(8);one.addView(label,pl);
            legend.addView(one,lp(-1,-2));gap(legend,7);
        }
        if(stacked)area.addView(legend,lp(-1,-2));
        else{LinearLayout.LayoutParams z=new LinearLayout.LayoutParams(0,-2,1);z.leftMargin=dp(7);area.addView(legend,z);}
        chart.addView(area,lp(-1,-2));
        chart.addView(txt(total==0?"所选月份尚无新增客户":"共 "+total+" 位新增客户",13,MUTED,false));
        addCard(body,chart);
    }
    /** 统一的家居顶部主视觉：照片铺在右侧，与左深右浅的渐变和安全文本区融合。 */
    private void homeHero(){
        final int heroHeight=fontIndex>=2?280:238;
        FrameLayout hero=new FrameLayout(this);
        hero.setBackground(gradient(Color.rgb(4,118,112),Color.rgb(13,164,146),19));hero.setClipToOutline(true);
        int deviceWidth=getResources().getDisplayMetrics().widthPixels;
        int photoWidth=(int)(deviceWidth*0.59f);
        ImageView picture=new ImageView(this);
        picture.setImageResource(R.drawable.home_living_room);
        picture.setScaleType(ImageView.ScaleType.CENTER_CROP);
        picture.setAlpha(0.97f);
        FrameLayout.LayoutParams photo=new FrameLayout.LayoutParams(photoWidth,dp(heroHeight),Gravity.RIGHT|Gravity.TOP);
        hero.addView(picture,photo);
        View shading=new View(this);
        GradientDrawable fade=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{Color.rgb(2,106,102),Color.rgb(5,130,120),Color.argb(184,7,138,126),Color.argb(0,7,138,126)});
        shading.setBackground(fade);
        hero.addView(shading,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout contents=vertical();pad(contents,15,15,15,13);
        LinearLayout titleRow=horizontal();titleRow.addView(icon("home",WHITE,24),lp(24,24));
        TextView app=txt("装修客户管家",19,WHITE,true);
        LinearLayout.LayoutParams appParams=new LinearLayout.LayoutParams(0,-2,1);appParams.leftMargin=dp(8);
        titleRow.addView(app,appParams);
        UiIcon settings=icon("settings",WHITE,23);settings.setContentDescription("打开设置");
        settings.setOnClickListener(v->showSettings());titleRow.addView(settings,lp(44,44));
        contents.addView(titleRow,lp(-1,-2));gap(contents,fontIndex>=2?17:14);
        String greet=Calendar.getInstance().get(Calendar.HOUR_OF_DAY)<12?"早上好！":Calendar.getInstance().get(Calendar.HOUR_OF_DAY)<18?"下午好！":"晚上好！";
        TextView hello=txt(greet,19,WHITE,true);contents.addView(hello,lp(-1,-2));gap(contents,3);
        TextView blessing=txt("今天也要顺顺利利",15,WHITE,true);
        blessing.setMaxWidth((int)(deviceWidth*.61f));contents.addView(blessing,lp(-1,-2));gap(contents,5);
        TextView tag=txt("客户跟进，有条不紊",12,Color.rgb(234,255,251),false);
        tag.setMaxWidth((int)(deviceWidth*.64f));contents.addView(tag,lp(-1,-2));
        hero.addView(contents,new FrameLayout.LayoutParams(-1,-2,Gravity.TOP));
        TextView calendar=txt("▣  今日工作安排   ·   "+new SimpleDateFormat("M月d日 E",Locale.CHINA).format(new Date()),13,WHITE,true);
        calendar.setGravity(Gravity.CENTER_VERTICAL);calendar.setBackground(shape(Color.argb(225,5,128,117),12,0));
        pad(calendar,12,10,12,10);calendar.setMinHeight(dp(44));
        calendar.setOnClickListener(v->showTasks("今天"));
        FrameLayout.LayoutParams bottom=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);
        bottom.setMargins(dp(12),0,dp(12),dp(12));hero.addView(calendar,bottom);
        LinearLayout.LayoutParams params=lp(-1,heroHeight);
        root.addView(hero,0,params);
    }
    private LinearLayout reminderTile(Db.Task task){LinearLayout tile=card();LinearLayout row=horizontal();
        View accent=new View(this);accent.setBackground(shape(task.overdue()?RED:Color.rgb(24,166,145),3,0));row.addView(accent,lp(3,57));
        LinearLayout.LayoutParams a=new LinearLayout.LayoutParams(dp(46),dp(46));a.leftMargin=dp(9);row.addView(avatarView(task.gender,46),a);
        LinearLayout detail=vertical();detail.addView(txt(task.clientName,16,INK,true));gap(detail,2);
        detail.addView(txt(task.community==null||task.community.isEmpty()?"未填小区":task.community,12,MUTED,false));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-2,1);cp.leftMargin=dp(9);row.addView(detail,cp);
        if(fontIndex<2)row.addView(pill("done".equals(task.status)?"已完成":task.overdue()?"已逾期":"待跟进", "done".equals(task.status)?TEAL:task.overdue()?RED:BLUE));
        tile.addView(row,lp(-1,-2));gap(tile,7);tile.addView(txt(task.content==null||task.content.isEmpty()?"联系客户":task.content,14,INK,false));gap(tile,5);
        LinearLayout footer=horizontal();TextView due=txt(date(task.dueAt),12,task.overdue()?RED:MUTED,false);footer.addView(due,new LinearLayout.LayoutParams(0,-2,1));
        if(fontIndex>=2)footer.addView(pill("done".equals(task.status)?"已完成":task.overdue()?"已逾期":"待跟进","done".equals(task.status)?TEAL:task.overdue()?RED:BLUE));
        footer.addView(txt("  ›",17,TEAL,true));tile.addView(footer,lp(-1,-2));
        tile.setOnClickListener(v->{if("tasks".equals(currentPage)&&pageScroll!=null)savedTaskScrollY=pageScroll.getScrollY();showTaskDetail(task.id);});tile.setClickable(true);tile.setFocusable(true);tile.setContentDescription(task.clientName+" "+task.content+"，点击查看提醒详情");return tile;}
    private LinearLayout rowSpace(){LinearLayout r=horizontal();r.setGravity(Gravity.CENTER_VERTICAL);return r;}
    private void separator(LinearLayout l){View v=new View(this);v.setBackgroundColor(LINE);LinearLayout.LayoutParams p=lp(-1,1);p.topMargin=dp(10);p.bottomMargin=dp(10);l.addView(v,p);}
    private void screen(String title,String page,boolean showNav){currentPage=page;root=vertical();root.setBackgroundColor(BG);setContentView(root);
        LinearLayout top=horizontal();pad(top,16,14,16,13);top.setBackground(gradient(Color.rgb(5,132,123),Color.rgb(17,166,150),0));top.setMinimumHeight(dp(66));
        if(!"home".equals(page)){TextView back=txt("‹",30,WHITE,false);pad(back,2,0,15,0);back.setOnClickListener(v->onBackPressed());top.addView(back,lp(-2,-2));}
        else{UiIcon mark=icon("home",WHITE,25);LinearLayout.LayoutParams m=lp(26,26);m.rightMargin=dp(9);top.addView(mark,m);}
        TextView heading=txt(title,20,WHITE,true);top.addView(heading,new LinearLayout.LayoutParams(0,-2,1));
        if("home".equals(page)){UiIcon settings=icon("settings",WHITE,23);pad(settings,5,4,5,4);settings.setOnClickListener(v->showSettings());top.addView(settings,lp(44,44));}
        if(!"home".equals(page))root.addView(top,lp(-1,-2));
        ScrollView scroll=new ScrollView(this);pageScroll=scroll;scroll.setFillViewport(false);scroll.setClipToPadding(false);
        body=vertical();pad(body,14,"home".equals(page)?9:14,14,24);scroll.addView(body,new ScrollView.LayoutParams(-1,-2));root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(showNav)navbar(page);
    }
    private void navbar(String selected){LinearLayout nav=horizontal();nav.setBackgroundColor(WHITE);pad(nav,5,7,5,7);
        String[] labels={"工作台","客户","提醒","我的"};String[] icons={"home","users","bell","user"};String[] pages={"home","clients","tasks","mine"};
        for(int i=0;i<labels.length;i++){final String page=pages[i];LinearLayout cell=vertical();cell.setGravity(Gravity.CENTER);pad(cell,2,5,2,5);
            int color=selected.equals(page)?TEAL:MUTED;UiIcon ico=icon(icons[i],color,23);TextView lab=txt(labels[i],12,color,selected.equals(page));lab.setGravity(Gravity.CENTER);
            cell.addView(ico,lp(25,25));gap(cell,3);cell.addView(lab,lp(-1,-2));cell.setOnClickListener(v->{switch(page){case "home":showHome();break;case "clients":showClients("",null,null);break;case "tasks":showTasks("待处理");break;default:showStats();}});
            nav.addView(cell,new LinearLayout.LayoutParams(0,-2,1));}
        nav.setElevation(dp(6));root.addView(nav,lp(-1,-2));
    }
    private void section(String label){TextView t=txt(label,18,INK,true);LinearLayout.LayoutParams p=lp(-1,-2);p.topMargin=dp(8);p.bottomMargin=dp(12);body.addView(t,p);}
    private String date(long timestamp){return timestamp<=0?"未设置":new SimpleDateFormat("yyyy年M月d日 HH:mm",Locale.CHINA).format(new Date(timestamp));}
    private String day(long t){return t<=0?"未签约":new SimpleDateFormat("yyyy-MM-dd",Locale.CHINA).format(new Date(t));}
    private String yuan(double v){DecimalFormat df=new DecimalFormat("¥#,##0.00");df.setRoundingMode(java.math.RoundingMode.HALF_UP);return df.format(v);}
    private int stageColor(String status){switch(status){case "新客户":return Color.rgb(0,91,118);case "已联系":return BLUE;case "有意向":return Color.rgb(0,113,106);case "已量房":return Color.rgb(103,58,183);case "已报价":return Color.rgb(144,80,10);case "已签约":return Color.rgb(8,107,45);default:return MUTED;}}
    private int intentColor(String intent){switch(intent){case "高意向":return Color.rgb(0,108,67);case "一般意向":return Color.rgb(141,79,5);case "待判断":return BLUE;default:return MUTED;}}
    private TextView pill(String title,int color){TextView t=txt(title,13,color,true);pad(t,12,6,12,6);t.setBackground(shape(tint(color),22,0));return t;}
    private int tint(int color){int r=Color.red(color),g=Color.green(color),b=Color.blue(color);return Color.rgb((r+255*7)/8,(g+255*7)/8,(b+255*7)/8);}
    private void tags(LinearLayout l,String stage,String intent){HorizontalScrollView h=new HorizontalScrollView(this);h.setHorizontalScrollBarEnabled(false);LinearLayout r=horizontal();r.addView(pill(stage,stageColor(stage)));View space=new View(this);r.addView(space,lp(8,1));r.addView(pill(intent,intentColor(intent)));h.addView(r);l.addView(h,lp(-1,-2));}
    private void info(LinearLayout l,String title,String value){LinearLayout r=horizontal();TextView a=txt(title,14,MUTED,false),b=txt(value==null||value.isEmpty()?"未填写":value,15,INK,false);
        r.addView(a,lp(94,-2));r.addView(b,new LinearLayout.LayoutParams(0,-2,1));l.addView(r,lp(-1,-2));gap(l,10);}
    private UiIcon icon(String name,int color,int size){UiIcon i=new UiIcon(this,name,color);i.setMinimumWidth(dp(size));i.setMinimumHeight(dp(size));return i;}
    private LinearLayout iconRow(String name,String value,int color,float size){LinearLayout row=horizontal();row.addView(icon(name,color,22),lp(22,22));
        TextView t=txt(value,size,color,false);LinearLayout.LayoutParams p=lp(-2,-2);p.leftMargin=dp(9);row.addView(t,p);return row;}
    private LinearLayout statistic(String name,String num,int color){
        LinearLayout c=card();c.setMinimumHeight(dp(100));c.setBackground(shape(tint(color),17,0));
        String symbol="chart";if(name.contains("客户"))symbol="users";if(name.contains("意向"))symbol="star";
        if(name.contains("签约"))symbol="check";if(name.contains("提成"))symbol="coin";if(name.contains("金额"))symbol="database";
        LinearLayout heading=horizontal();heading.addView(icon(symbol,color,23),lp(23,23));TextView label=txt(name,13,INK,true);
        LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,-2,1);q.leftMargin=dp(7);heading.addView(label,q);c.addView(heading,lp(-1,-2));gap(c,6);
        c.addView(txt(num,22,color,true),lp(-1,-2));return c;
    }
    private void metricGrid(String[] names,String[] values,int[] colors){metricGrid(names,values,colors,null);}
    private void metricGrid(String[] names,String[] values,int[] colors,View.OnClickListener[] actions){
        int columns=fontIndex>=2?1:2;
        for(int i=0;i<names.length;i+=columns){LinearLayout r=horizontal();r.setGravity(Gravity.TOP);
            for(int j=i;j<Math.min(i+columns,names.length);j++){
                LinearLayout tile=statistic(names[j],values[j],colors[j]);
                if(actions!=null && j<actions.length && actions[j]!=null){
                    tile.setOnClickListener(actions[j]);tile.setClickable(true);tile.setFocusable(true);
                    tile.setContentDescription(names[j]+" "+values[j]+"，点击查看详情");
                    TextView arrow=txt("点击查看  ›",11,colors[j],true);gap(tile,4);tile.addView(arrow,lp(-1,-2));
                }
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.rightMargin=columns==2&&j%2==0?dp(8):0;r.addView(tile,p);
            }
            LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(9);body.addView(r,p);
        }
    }
    private Calendar[] monthBounds(){Calendar start=Calendar.getInstance();start.set(Calendar.DAY_OF_MONTH,1);start.set(Calendar.HOUR_OF_DAY,0);start.set(Calendar.MINUTE,0);start.set(Calendar.SECOND,0);start.set(Calendar.MILLISECOND,0);
        Calendar end=(Calendar)start.clone();end.add(Calendar.MONTH,1);return new Calendar[]{start,end};}
    private long[] currentMonthBounds(){Calendar[] c=monthBounds();return new long[]{c[0].getTimeInMillis(),c[1].getTimeInMillis()};}
    private void showHome(){screen("装修客户管家","home",true);Calendar[] bounds=monthBounds();
        Db.Stats s=db.stats(bounds[0].getTimeInMillis(),bounds[1].getTimeInMillis());homeHero();
        LinearLayout title=horizontal();title.addView(icon("calendar",TEAL,21),lp(21,21));
        TextView countText=txt("今日待跟进（"+db.todayCount()+"）",17,INK,true);LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(0,-2,1);wp.leftMargin=dp(7);title.addView(countText,wp);
        TextView more=txt("查看全部  ›",13,BLUE,true);more.setOnClickListener(v->showTasks("今天"));title.addView(more);body.addView(title,lp(-1,-2));gap(body,9);
        Calendar tomorrow=Calendar.getInstance();tomorrow.set(Calendar.HOUR_OF_DAY,0);tomorrow.set(Calendar.MINUTE,0);tomorrow.set(Calendar.SECOND,0);tomorrow.set(Calendar.MILLISECOND,0);tomorrow.add(Calendar.DAY_OF_MONTH,1);
        int count=0;
        for(Db.Task task:db.homePriorityTasks(3,tomorrow.getTimeInMillis())){
            addCard(body,reminderTile(task));count++;
        }
        if(count==0){LinearLayout empty=card();empty.addView(iconRow("calendar","今天没有待跟进事项",TEAL,15));
            gap(empty,6);empty.addView(txt("已逾期的任务也会在这里优先显示。",13,MUTED,false));addCard(body,empty);}
        LinearLayout small=horizontal();small.addView(softButton("＋ 添加提醒",v->showPickReminderClient()),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams spacer=new LinearLayout.LayoutParams(0,-2,1);spacer.leftMargin=dp(8);small.addView(softButton("全部提醒  ›",v->showTasks("待处理")),spacer);
        body.addView(small,lp(-1,-2));gap(body,12);
        LinearLayout headline=horizontal();headline.addView(txt("我的客户与业绩",17,INK,true),new LinearLayout.LayoutParams(0,-2,1));headline.addView(icon("chart",TEAL,22),lp(22,22));body.addView(headline,lp(-1,-2));gap(body,9);
        metricGrid(new String[]{"客户总数","高意向客户","本月签约","预计提成"},
            new String[]{""+s.customers,""+s.highIntent,""+s.monthSigned,yuan(s.monthExpected)},
            new int[]{BLUE,Color.rgb(0,106,80),Color.rgb(117,67,173),Color.rgb(140,80,13)},
            new View.OnClickListener[]{v->showClients("",null,null),v->showClients("",null,"高意向"),v->showMonthSignedClients("home"),v->{reportingMonth=MonthPeriod.current();showStats();}});
        long lastBacked=getPreferences(0).getLong("last_backup",0);
        if(db.countClients()>0&&(lastBacked<=0||System.currentTimeMillis()-lastBacked>7L*24*60*60*1000)){
            LinearLayout backup=card();backup.addView(txt("提醒：最近7天没有备份客户资料",14,BLUE,true));gap(backup,7);
            backup.addView(softButton("立即备份",v->saveFile("backup","application/json","装修客户管家备份_"+System.currentTimeMillis()+".json")),lp(-1,-2));addCard(body,backup);
        }
        gap(body,5);body.addView(button("＋ 新增客户",true,v->showClientForm(null)),lp(-1,-2));
    }
    private void showMonthSignedClients(String origin){signedListReturn=origin;currentClientId=0;
        String periodLabel="mine".equals(origin)?reportingMonth.label():"本月";
        screen(periodLabel+"签约明细","signed_month",false);
        long[] bounds="mine".equals(origin)?reportingMonth.bounds():currentMonthBounds();
        Db.Stats stats=db.stats(bounds[0],bounds[1]);
        LinearLayout summary=card();summary.addView(txt(periodLabel+"签约客户 "+stats.monthSigned+" 人",19,INK,true));gap(summary,5);
        summary.addView(txt("合同金额 "+yuan(stats.monthAmount)+" · 预计提成 "+yuan(stats.monthExpected),14,MUTED,false));addCard(body,summary);
        int count=0;
        for(Db.Contract contract:db.contractsMonth(bounds[0],bounds[1])){
            Db.Client client=db.client(contract.clientId);if(client==null)continue;
            LinearLayout tile=card();tile.addView(txt(client.displayName()+" · "+day(contract.signedAt)+"  ›",17,INK,true));gap(tile,6);
            tile.addView(txt("合同 "+yuan(contract.amount)+" · 预计提成 "+yuan(contract.expected()),14,TEAL,true));
            tile.setOnClickListener(v->showClient(client.id));addCard(body,tile);count++;
        }
        if(count==0){LinearLayout empty=card();empty.addView(txt("所选月份没有签约记录",15,MUTED,false));addCard(body,empty);}
    }
    private void showMonthReceipts(){currentClientId=0;screen(reportingMonth.label()+"提成到账","received_month",false);
        long[] b=reportingMonth.bounds();int n=0;
        for(Db.Receipt receipt:db.receiptsMonth(b[0],b[1])){
            Db.Contract contract=db.contract(receipt.contractId);if(contract==null)continue;
            Db.Client client=db.client(contract.clientId);if(client==null)continue;
            LinearLayout card=card();card.addView(txt(client.displayName()+"  ·  "+yuan(receipt.amount),18,TEAL,true));gap(card,6);
            card.addView(txt("到账 "+day(receipt.receivedAt)+" · 合同签约 "+day(contract.signedAt),14,MUTED,false));gap(card,5);
            if(!receipt.note.isEmpty())card.addView(txt(receipt.note,14,INK,false));
            card.setOnClickListener(v->showReceiptForm(contract,receipt));addCard(body,card);n++;
        }
        if(n==0){LinearLayout card=card();card.addView(txt("所选月份暂无提成到账记录。历史到账未填写日期的不纳入月份统计。",15,MUTED,false));addCard(body,card);}
    }
    private void showClients(String search,String stage,String intent){showClients(search,stage,intent,null);}
    private void showClients(String search,String stage,String intent,String source){
        showClients(search,stage,intent,source,60);
    }
    private void showClients(String search,String stage,String intent,String source,int requestedLimit){
        currentClientId=0;
        boolean same=java.util.Objects.equals(search,savedClientSearch)&&java.util.Objects.equals(stage,savedClientStage)
            &&java.util.Objects.equals(intent,savedClientIntent)&&java.util.Objects.equals(source,savedClientSource);
        if(!same){savedClientScrollY=0;clientListLimit=60;}
        else clientListLimit=Math.max(clientListLimit,requestedLimit);
        savedClientSearch=search==null?"":search;savedClientStage=stage;savedClientIntent=intent;savedClientSource=source;
        screen("客户管理","clients",true);
        LinearLayout q=horizontal();EditText input=new EditText(this);input.setSingleLine(true);input.setText(search==null?"":search);
        input.setHint("姓名、电话、微信、小区");input.setTextSize(15*FONT_SCALES[fontIndex]);input.setTextColor(INK);input.setHintTextColor(MUTED);input.setBackground(shape(WHITE,12,LINE));pad(input,12,7,10,7);
        q.addView(input,new LinearLayout.LayoutParams(0,dp(50),1));TextView go=softButton("搜索",v->showClients(input.getText().toString(),stage,intent,source));LinearLayout.LayoutParams g=lp(-2,50);g.leftMargin=dp(8);q.addView(go,g);body.addView(q,lp(-1,-2));gap(body,10);
        LinearLayout f=horizontal();TextView byStage=softButton(stage==null?"全部状态 ▾":stage+" ▾",v->choose("业务进展",concat("全部状态",Db.STAGES),stage==null?"全部状态":stage,chosen->showClients(input.getText().toString(),"全部状态".equals(chosen)?null:chosen,intent,source)));
        TextView byIntent=softButton(intent==null?"全部意向 ▾":intent+" ▾",v->choose("意向程度",concat("全部意向",Db.INTENTS),intent==null?"全部意向":intent,chosen->showClients(input.getText().toString(),stage,"全部意向".equals(chosen)?null:chosen,source)));
        if(fontIndex>=2){body.addView(byStage,lp(-1,-2));gap(body,8);body.addView(byIntent,lp(-1,-2));}
        else{f.addView(byStage,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.leftMargin=dp(8);f.addView(byIntent,p);body.addView(f,lp(-1,-2));}
        gap(body,8);
        TextView bySource=softButton(source==null?"全部来源 ▾":source+" ▾",v->choose("客户来源",concat("全部来源",Db.SOURCES),source==null?"全部来源":source,
            chosen->showClients(input.getText().toString(),stage,intent,"全部来源".equals(chosen)?null:chosen)));
        body.addView(bySource,lp(-1,-2));gap(body,6);
        int total=db.clientsCount(search,stage,intent,source);
        List<Db.Client> clients=db.clientsPage(search,stage,intent,source,clientListLimit,0);
        section("客户列表 · "+total+"人");
        for(Db.Client c:clients){LinearLayout tile=card();LinearLayout row=horizontal();row.addView(avatarView(c.gender,50),lp(50,50));
            LinearLayout detail=vertical();detail.addView(txt(c.displayName(),16,INK,true));gap(detail,3);
            detail.addView(txt((c.community.isEmpty()?"未填小区":c.community)+(c.area.isEmpty()?"":" · "+c.area+"㎡"),12,MUTED,false));
            LinearLayout.LayoutParams xlp=new LinearLayout.LayoutParams(0,-2,1);xlp.leftMargin=dp(10);row.addView(detail,xlp);
            if(!c.phone.isEmpty()){UiIcon phone=icon("phone",TEAL,25);phone.setOnClickListener(v->startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode(c.phone)))));row.addView(phone,lp(44,44));}
            tile.addView(row,lp(-1,-2));gap(tile,9);tags(tile,c.stage,c.intent);tile.setOnClickListener(v->{savedClientScrollY=pageScroll==null?0:pageScroll.getScrollY();showClient(c.id);});addCard(body,tile);}
        if(clients.isEmpty()){
            boolean noClients=db.countClients()==0;
            LinearLayout empty=card();empty.addView(iconRow("users",noClients?"还没有客户":"没有符合条件的客户",TEAL,15));gap(empty,8);
            empty.addView(txt(noClients?"点击下方新增客户，建立第一份客户档案。":"可以调整姓名、电话或筛选条件重新查找。",14,MUTED,false));
            if(!noClients){gap(empty,9);empty.addView(softButton("清除筛选",v->showClients("",null,null,null)),lp(-1,-2));}
            addCard(body,empty);
        }
        if(total>clients.size()){
            TextView more=softButton("加载更多（已显示 "+clients.size()+" / "+total+"）",v->{
                int position=pageScroll==null?0:pageScroll.getScrollY();restoreClientPosition=true;savedClientScrollY=position;
                showClients(savedClientSearch,savedClientStage,savedClientIntent,savedClientSource,clientListLimit+60);
            });addCard(body,more);
        }
        body.addView(button("＋ 新增客户",true,v->showClientForm(null)));
        if(restoreClientPosition){restoreClientPosition=false;int y=savedClientScrollY;if(pageScroll!=null)pageScroll.post(()->pageScroll.scrollTo(0,y));}
    }
    private static String[] concat(String first,String[] rest){String[] out=new String[rest.length+1];out[0]=first;System.arraycopy(rest,0,out,1,rest.length);return out;}
    private interface ChooseListener{void selected(String value);}
    private void choose(String title,String[] options,String current,ChooseListener cb){int selected=0;for(int i=0;i<options.length;i++)if(options[i].equals(current)){selected=i;break;}
        new AlertDialog.Builder(this).setTitle(title).setSingleChoiceItems(options,selected,(dialog,index)->{dialog.dismiss();cb.selected(options[index]);}).setNegativeButton("取消",null).show();}
    private TextView selectField(LinearLayout container,String label,String[] opts,String[] chosen){LinearLayout row=vertical();row.addView(txt(label,15,INK,true));gap(row,5);
        TextView v=txt(chosen[0]+"  ▾",16,INK,false);pad(v,13,11,13,11);v.setMinHeight(dp(49));v.setBackground(shape(WHITE,12,LINE));
        v.setOnClickListener(view->choose(label,opts,chosen[0],newValue->{chosen[0]=newValue;v.setText(newValue+"  ▾");}));row.addView(v,lp(-1,-2));
        LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(12);container.addView(row,p);return v;}
    private void genderChoices(LinearLayout parent,String[] selected){
        parent.addView(txt("客户性别（选择后自动使用Q版头像）",15,INK,true));gap(parent,8);
        LinearLayout area=horizontal();parent.addView(area,lp(-1,-2));
        Runnable[] build=new Runnable[1];build[0]=()->{area.removeAllViews();
            for(String value:Db.GENDERS){LinearLayout choice=vertical();choice.setGravity(Gravity.CENTER);pad(choice,7,9,7,9);
                choice.setBackground(shape(value.equals(selected[0])?Color.rgb(224,249,245):WHITE,14,value.equals(selected[0])?TEAL:LINE));
                choice.addView(avatarView(value,58),lp(58,58));gap(choice,4);TextView label=txt(value,13,value.equals(selected[0])?TEAL:INK,true);
                label.setGravity(Gravity.CENTER);choice.addView(label,lp(-1,-2));choice.setOnClickListener(v->{selected[0]=value;build[0].run();});
                LinearLayout.LayoutParams cell=new LinearLayout.LayoutParams(0,-2,1);cell.rightMargin=dp(7);area.addView(choice,cell);
            }
        };build[0].run();gap(parent,13);
    }
    private String sourceIcon(String source){switch(source){case "电话":return "phone";case "微信":return "chat";case "跑小区":return "walk";case "门店":return "store";case "熟人介绍":return "users";default:return "other";}}
    private LinearLayout sourceChoiceIcon(String source,boolean selected){
        LinearLayout chip=horizontal();chip.setGravity(Gravity.CENTER);pad(chip,4,9,4,9);
        chip.setBackground(shape(selected?Color.rgb(219,247,242):WHITE,11,selected?Color.rgb(69,188,165):LINE));
        chip.addView(icon(sourceIcon(source),selected?TEAL:MUTED,17),lp(17,17));
        TextView name=txt(source,12,selected?TEAL:INK,selected);LinearLayout.LayoutParams q=lp(-2,-2);q.leftMargin=dp(4);chip.addView(name,q);
        chip.setMinimumHeight(dp(45));return chip;
    }
    private void showSourceChoices(LinearLayout parent,String[] chosen){
        parent.addView(txt("客户来源",15,INK,true));gap(parent,8);
        LinearLayout grid=vertical();parent.addView(grid,lp(-1,-2));
        Runnable build=()->{grid.removeAllViews();for(int i=0,cols=fontIndex>=2?2:3;i<Db.SOURCES.length;i+=cols){LinearLayout row=horizontal();
            for(int j=i;j<Math.min(i+cols,Db.SOURCES.length);j++){String option=Db.SOURCES[j];LinearLayout chip=sourceChoiceIcon(option,option.equals(chosen[0]));
                chip.setOnClickListener(v->{chosen[0]=option;grid.removeAllViews();showSourceChoicesContent(grid,chosen);});
                LinearLayout.LayoutParams param=new LinearLayout.LayoutParams(0,-2,1);param.rightMargin=j%cols==cols-1?0:dp(6);row.addView(chip,param);}
            LinearLayout.LayoutParams rp=lp(-1,-2);rp.bottomMargin=dp(6);grid.addView(row,rp);}};
        build.run();gap(parent,9);
    }
    private void showSourceChoicesContent(LinearLayout grid,String[] chosen){for(int i=0,cols=fontIndex>=2?2:3;i<Db.SOURCES.length;i+=cols){LinearLayout row=horizontal();
        for(int j=i;j<Math.min(i+cols,Db.SOURCES.length);j++){String option=Db.SOURCES[j];LinearLayout chip=sourceChoiceIcon(option,option.equals(chosen[0]));
            chip.setOnClickListener(v->{chosen[0]=option;grid.removeAllViews();showSourceChoicesContent(grid,chosen);});
            LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(0,-2,1);qp.rightMargin=j%cols==cols-1?0:dp(6);row.addView(chip,qp);}
        LinearLayout.LayoutParams rowLp=lp(-1,-2);rowLp.bottomMargin=dp(6);grid.addView(row,rowLp);}}
    private String inputIcon(String label){
        if(label.contains("姓名"))return "user";
        if(label.contains("手机")||label.contains("电话"))return "phone";
        if(label.contains("微信"))return "chat";
        if(label.contains("小区")||label.contains("楼栋")||label.contains("面积"))return "house";
        if(label.contains("日期"))return "calendar";
        if(label.contains("提成")||label.contains("金额")||label.contains("预算"))return "coin";
        if(label.contains("备注")||label.contains("需求")||label.contains("事项"))return "clipboard";
        return "edit";
    }
    private EditText field(LinearLayout parent,String label,String val,boolean multiple,boolean numeric){
        LinearLayout l=vertical();
        if(label.length()<=10)l.addView(iconRow(inputIcon(label),label,INK,15),lp(-1,-2));
        else l.addView(txt(label,15,INK,true));
        gap(l,5);
        EditText e=new EditText(this);e.setText(val==null?"":val);e.setTextColor(INK);e.setHintTextColor(MUTED);e.setTextSize(16*FONT_SCALES[fontIndex]);
        e.setBackground(shape(WHITE,12,LINE));pad(e,13,10,13,10);e.setMinHeight(dp(50));
        if(multiple){e.setSingleLine(false);e.setMinLines(2);e.setGravity(Gravity.TOP);}else e.setSingleLine(true);
        if(numeric)e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        l.addView(e,lp(-1,-2));LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(12);parent.addView(l,p);return e;}
    private double number(EditText ed){String text=ed.getText().toString().trim().replace(",","");return text.isEmpty()?0:Double.parseDouble(text);}
    private void showClientForm(Db.Client data){boolean editing=data!=null;Db.Client c=editing?data:new Db.Client();currentClientId=c.id;
        screen(editing?"编辑基本资料":"新增客户","client_form",false);
        LinearLayout banner=card();banner.setBackground(shape(Color.rgb(226,248,244),15,0));
        banner.addView(iconRow("plus","快速录入",TEAL,18));gap(banner,5);
        banner.addView(txt("姓名或手机号至少填一项即可保存，其他资料以后补充。",14,INK,false));addCard(body,banner);
        EditText name=field(body,"客户姓名或称呼",c.name,false,false);
        EditText phone=field(body,"手机号码",c.phone,false,false);phone.setInputType(InputType.TYPE_CLASS_PHONE);
        EditText wechat=field(body,"微信号",c.wechat,false,false);
        final String[] source={c.source},reno={c.renovationType},gender={c.gender};
        genderChoices(body,gender);showSourceChoices(body,source);
        final long[] acquiredAt={c.acquiredAt>0?c.acquiredAt:System.currentTimeMillis()};
        TextView acquired=softButton("获客日期："+day(acquiredAt[0])+" ▾",null);
        acquired.setOnClickListener(v->dateOnly(acquiredAt[0],date->{acquiredAt[0]=date;acquired.setText("获客日期："+day(date)+" ▾");}));
        body.addView(acquired,lp(-1,-2));gap(body,12);
        EditText community=field(body,"小区名称",c.community,false,false);
        TextView toggle=softButton(editing?"收起详细资料 ▴":"填写更多装修资料（选填） ▾",null);
        body.addView(toggle,lp(-1,-2));gap(body,12);
        LinearLayout extras=vertical();body.addView(extras,lp(-1,-2));extras.setVisibility(editing?View.VISIBLE:View.GONE);
        toggle.setOnClickListener(v->{boolean show=extras.getVisibility()!=View.VISIBLE;extras.setVisibility(show?View.VISIBLE:View.GONE);
            toggle.setText(show?"收起详细资料 ▴":"填写更多装修资料（选填） ▾");});
        EditText building=field(extras,"楼栋和房号",c.building,false,false);
        EditText area=field(extras,"房屋面积（㎡）",c.area,false,true);
        EditText budget=field(extras,"装修预算",c.budget,false,false);
        selectField(extras,"装修类型",Db.RENOVATIONS,reno);
        EditText needs=field(extras,"装修需求",c.needs,true,false);
        EditText notes=field(extras,"备注（介绍人、客户顾虑等）",c.notes,true,false);
        body.addView(button("保存客户",true,v->{
            c.name=name.getText().toString().trim();c.phone=phone.getText().toString().trim();c.wechat=wechat.getText().toString().trim();
            if(c.name.isEmpty()&&c.phone.isEmpty()){toast("请至少填写客户姓名或手机号");return;}
            c.acquiredAt=acquiredAt[0];c.gender=gender[0];c.source=source[0];c.community=community.getText().toString();c.building=building.getText().toString();c.area=area.getText().toString();
            c.budget=budget.getText().toString();c.renovationType=reno[0];c.needs=needs.getText().toString();c.notes=notes.getText().toString();
            long duplicate=db.duplicatePhone(c.phone,c.id);
            if(duplicate>0){new AlertDialog.Builder(this).setTitle("发现相同手机号").setMessage("该号码已经登记。可以打开已有客户，或继续保存另一条客户档案。")
                .setPositiveButton("打开原档案",(dialog,which)->showClient(duplicate))
                .setNegativeButton("取消",null)
                .setNeutralButton("仍然保存",(dialog,which)->saveClientAndOpen(c)).show();}
            else saveClientAndOpen(c);
        }),lp(-1,-2));
        gap(body,20);
    }
    private void saveClientAndOpen(Db.Client c){try{long id=db.saveClient(c);toast("客户已保存");showClient(id);}catch(Exception ex){error("保存客户失败",ex);}}
    private interface DateListener {void selected(long millis);}
    private void dateOnly(long initial,DateListener listener){Calendar c=Calendar.getInstance();if(initial>0)c.setTimeInMillis(initial);
        new DatePickerDialog(this,(picker,year,month,day)->{Calendar chosen=Calendar.getInstance();chosen.set(year,month,day,12,0,0);chosen.set(Calendar.MILLISECOND,0);listener.selected(chosen.getTimeInMillis());},
            c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}
    private void dateTime(long initial,DateListener listener){Calendar c=Calendar.getInstance();if(initial>0)c.setTimeInMillis(initial);
        new DatePickerDialog(this,(picker,year,month,day)->{
            new TimePickerDialog(this,(t,hour,minute)->{Calendar d=Calendar.getInstance();d.set(year,month,day,hour,minute,0);d.set(Calendar.MILLISECOND,0);listener.selected(d.getTimeInMillis());},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show();
        },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}
    private void changeStage(Db.Client c){choose("更新业务进展",Db.STAGES,c.stage,next->{
        if(next.equals(c.stage))return;
        if("已签约".equals(next) && db.getContracts(c.id).isEmpty()){showContractForm(c,true);return;}
        c.stage=next;try{db.saveClient(c);toast("业务进展已更新");showClient(c.id);}catch(Exception e){error("更新业务进展失败",e);}
    });}
    private void changeIntent(Db.Client c){choose("更新客户意向",Db.INTENTS,c.intent,next->{
        if(next.equals(c.intent))return;
        c.intent=next;try{db.saveClient(c);toast("客户意向已更新");showClient(c.id);}catch(Exception e){error("更新客户意向失败",e);}
    });}
    private void showContractForm(Db.Client c,boolean newSigning){showContractForm(c,(Db.Contract)null);}
    private void showContractForm(Db.Client c,Db.Contract existing){currentClientId=c.id;screen(existing==null?"新增签约合同":"修改签约合同","contract_form",false);
        LinearLayout banner=card();banner.setBackground(shape(Color.rgb(224,248,242),14,0));
        banner.addView(txt(c.displayName(),19,INK,true));gap(banner,7);
        banner.addView(txt("每份合同单独保存，签约日期可以补录。提成到账另行登记。",14,MUTED,false));addCard(body,banner);
        final long[] signedAt={existing==null?System.currentTimeMillis():existing.signedAt};
        TextView signed=softButton("签约日期："+day(signedAt[0])+" ▾",null);
        signed.setOnClickListener(v->dateOnly(signedAt[0],date->{signedAt[0]=date;signed.setText("签约日期："+day(date)+" ▾");}));
        body.addView(signed,lp(-1,-2));gap(body,12);
        EditText amount=field(body,"合同金额（元）",existing==null?"":String.valueOf(existing.amount),false,true);
        body.addView(txt("提成方式",16,INK,true));gap(body,8);
        final String[] mode={existing!=null&&"fixed".equals(existing.commissionType)?"fixed":"percent"};
        TextView percent=softButton("按合同百分比",null),fixedMode=softButton("老板约定固定金额",null);
        if(fontIndex>=2){body.addView(percent,lp(-1,-2));gap(body,7);body.addView(fixedMode,lp(-1,-2));}
        else{LinearLayout row=horizontal();row.addView(percent,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.leftMargin=dp(8);row.addView(fixedMode,p);body.addView(row,lp(-1,-2));}
        gap(body,10);
        LinearLayout percentFields=vertical(),fixedFields=vertical();
        EditText rate=field(percentFields,"提成比例（%）",existing!=null?String.valueOf(existing.commissionRate):"",false,true);
        EditText fixed=field(fixedFields,"固定提成金额（元）",existing!=null?String.valueOf(existing.fixedCommission):"",false,true);
        body.addView(percentFields,lp(-1,-2));body.addView(fixedFields,lp(-1,-2));
        EditText note=field(body,"合同备注（选填）",existing==null?"":existing.note,true,false);
        TextView preview=txt("预计提成：¥0",18,TEAL,true);body.addView(preview);gap(body,14);
        Runnable refresh=()->{
            boolean useFixed="fixed".equals(mode[0]);percentFields.setVisibility(useFixed?View.GONE:View.VISIBLE);fixedFields.setVisibility(useFixed?View.VISIBLE:View.GONE);
            percent.setBackground(shape(useFixed?Color.rgb(234,243,253):TEAL,12,0));percent.setTextColor(useFixed?BLUE:WHITE);
            fixedMode.setBackground(shape(useFixed?TEAL:Color.rgb(234,243,253),12,0));fixedMode.setTextColor(useFixed?WHITE:BLUE);
            try{preview.setText("预计提成："+yuan(CommissionRule.expected(mode[0],number(amount),number(rate),number(fixed))));}
            catch(Exception error){preview.setText("请输入正确金额");}
        };
        percent.setOnClickListener(v->{mode[0]="percent";refresh.run();});fixedMode.setOnClickListener(v->{mode[0]="fixed";refresh.run();});
        TextWatcher watch=new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int after){}public void onTextChanged(CharSequence s,int st,int before,int count){refresh.run();}public void afterTextChanged(Editable e){}};
        amount.addTextChangedListener(watch);rate.addTextChangedListener(watch);fixed.addTextChangedListener(watch);refresh.run();
        body.addView(button(existing==null?"保存签约合同":"保存合同修改",true,v->{
            try{double a=number(amount),r=number(rate),f=number(fixed);
                if(!Double.isFinite(a)||!Double.isFinite(r)||!Double.isFinite(f)||a<0||r<0||r>100||f<0){toast("合同金额或提成填写不正确");return;}
                if("fixed".equals(mode[0])&&fixed.getText().toString().trim().isEmpty()){toast("请输入固定提成金额");return;}
                if("percent".equals(mode[0])&&rate.getText().toString().trim().isEmpty()){toast("请输入提成比例");return;}
                Db.Contract record=existing==null?new Db.Contract():existing;
                record.clientId=c.id;record.signedAt=signedAt[0];record.amount=a;record.commissionRate=r;record.fixedCommission=f;record.commissionType=mode[0];record.note=note.getText().toString();
                db.saveContract(record);if(existing==null&&!"已签约".equals(c.stage)){c.stage="已签约";db.saveClient(c);}
                toast("合同已保存");showClient(c.id);
            }catch(Exception err){error("保存合同失败",err);}
        }),lp(-1,-2));
        if(existing!=null){gap(body,15);TextView delete=softButton("删除这份合同（同时删除所属到账记录）",v->{
            new AlertDialog.Builder(this).setTitle("确认删除合同？")
                .setMessage("这份合同及其到账记录将永久删除，请先确认是否已经备份。")
                .setNegativeButton("取消",null).setPositiveButton("确认删除",(d,w)->{db.deleteContract(existing.id);
                    if(db.getContracts(c.id).isEmpty()&&"已签约".equals(c.stage))toast("最后一份合同已删除，业务状态已调整为已联系");
                    showClient(c.id);}).show();
        });delete.setTextColor(RED);body.addView(delete,lp(-1,-2));}
    }
    private void showReceiptForm(Db.Contract contract,Db.Receipt editing){currentClientId=contract.clientId;screen(editing==null?"登记提成到账":"修改到账记录","receipt_form",false);
        Db.Client c=db.client(contract.clientId);if(c==null)return;
        LinearLayout banner=card();banner.addView(txt(c.displayName()+" · 合同"+day(contract.signedAt),18,INK,true));gap(banner,8);
        banner.addView(txt("约定提成 "+yuan(contract.expected())+" · 已收 "+yuan(db.receivedForContract(contract.id)),14,TEAL,true));addCard(body,banner);
        final long[] paidAt={editing==null?System.currentTimeMillis():editing.receivedAt};
        TextView date=softButton("到账日期："+(paidAt[0]==0?"历史日期待补":day(paidAt[0]))+" ▾",null);
        date.setOnClickListener(v->dateOnly(paidAt[0],next->{paidAt[0]=next;date.setText("到账日期："+day(next)+" ▾");}));
        body.addView(date,lp(-1,-2));gap(body,10);
        EditText amount=field(body,"本笔到账金额（元）",editing==null?"":String.valueOf(editing.amount),false,true);
        EditText note=field(body,"到账备注（选填）",editing==null?"":editing.note,true,false);
        body.addView(button(editing==null?"保存本笔到账":"保存到账修改",true,v->{
            try{double a=number(amount);if(!Double.isFinite(a)||a<=0){toast("请输入大于0的到账金额");return;}
                Db.Receipt receipt=editing==null?new Db.Receipt():editing;receipt.contractId=contract.id;receipt.receivedAt=paidAt[0];receipt.amount=a;receipt.note=note.getText().toString();
                db.addReceipt(receipt);toast("到账记录已保存");showClient(contract.clientId);
            }catch(Exception e){error("保存到账失败",e);}
        }),lp(-1,-2));
        if(editing!=null){gap(body,12);TextView del=softButton("删除这笔到账",v->new AlertDialog.Builder(this).setTitle("确定删除这笔到账？")
            .setNegativeButton("取消",null).setPositiveButton("删除",(d,w)->{db.deleteReceipt(editing.id);showClient(contract.clientId);}).show());del.setTextColor(RED);body.addView(del,lp(-1,-2));}
    }
    private void showReceiveDialog(Db.Client c){List<Db.Contract> all=db.getContracts(c.id);
        if(all.isEmpty()){toast("请先登记签约合同");return;}
        if(all.size()==1){showReceiptForm(all.get(0),null);return;}
        String[] labels=new String[all.size()];for(int i=0;i<all.size();i++)labels[i]=day(all.get(i).signedAt)+" · "+yuan(all.get(i).amount);
        new AlertDialog.Builder(this).setTitle("选择本次到账所属合同").setItems(labels,(d,n)->showReceiptForm(all.get(n),null)).setNegativeButton("取消",null).show();
    }
    private void showClient(long id){Db.Client c=db.client(id);if(c==null){showClients("",null,null);return;}currentClientId=id;screen("客户详情","client",false);
        LinearLayout header=card();LinearLayout top=horizontal();
        top.addView(avatarView(c.gender,58),lp(58,58));
        LinearLayout name=vertical();name.addView(txt(c.displayName(),22,INK,true));gap(name,8);tags(name,c.stage,c.intent);
        LinearLayout.LayoutParams nlp=new LinearLayout.LayoutParams(0,-2,1);nlp.leftMargin=dp(12);top.addView(name,nlp);header.addView(top,lp(-1,-2));
        gap(header,14);
        LinearLayout shortcut=horizontal();TextView stage=softButton("更新业务进展 ▾",v->changeStage(c));TextView intent=softButton("更新客户意向 ▾",v->changeIntent(c));
        if(fontIndex>=2){header.addView(stage,lp(-1,-2));gap(header,8);header.addView(intent,lp(-1,-2));}
        else{shortcut.addView(stage,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams pl=new LinearLayout.LayoutParams(0,-2,1);pl.leftMargin=dp(8);shortcut.addView(intent,pl);header.addView(shortcut,lp(-1,-2));}
        addCard(body,header);
        LinearLayout actions=horizontal();if(!c.phone.isEmpty()){TextView call=button("☎ 拨打电话",true,v->{Intent i=new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode(c.phone)));startActivity(i);});
            actions.addView(call,new LinearLayout.LayoutParams(0,-2,1));}
        if(!c.wechat.isEmpty()){TextView copy=softButton("复制微信号",v->{ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(cm!=null){cm.setPrimaryClip(ClipData.newPlainText("微信号",c.wechat));toast("微信号已复制");}else toast("复制失败，请手动记录微信号");});
            LinearLayout.LayoutParams lp2=new LinearLayout.LayoutParams(0,-2,1);lp2.leftMargin=dp(8);actions.addView(copy,lp2);}
        if(actions.getChildCount()>0){body.addView(actions,lp(-1,-2));gap(body,12);}
        LinearLayout detail=card();detail.addView(iconRow("clipboard","客户档案",TEAL,18));separator(detail);
        info(detail,"手机号",c.phone);info(detail,"微信号",c.wechat);info(detail,"小区",c.community);info(detail,"面积",c.area.isEmpty()?"":c.area+"㎡");
        info(detail,"装修预算",c.budget);info(detail,"装修类型",c.renovationType);info(detail,"客户来源",c.source);
        info(detail,"获客日期",day(c.acquiredAt));
        if(!c.building.isEmpty())info(detail,"楼栋房号",c.building);
        if(!c.needs.isEmpty())info(detail,"装修需求",c.needs);if(!c.notes.isEmpty())info(detail,"备注",c.notes);
        addCard(body,detail);
        body.addView(softButton("编辑客户基本资料",v->showClientForm(c)),lp(-1,-2));gap(body,11);
        LinearLayout signing=card();signing.addView(iconRow("coin","签约合同与提成",TEAL,18));separator(signing);
        List<Db.Contract> contracts=db.getContracts(c.id);
        if(contracts.isEmpty()){
            signing.addView(txt("目前没有签约合同。签约后再登记合同、约定提成及到账。",14,MUTED,false));gap(signing,9);
        }else{
            for(Db.Contract contract:contracts){
                double paid=db.receivedForContract(contract.id);
                LinearLayout entry=vertical();entry.addView(txt("签约 "+day(contract.signedAt)+" · 合同金额 "+yuan(contract.amount),16,INK,true));gap(entry,5);
                entry.addView(txt("预计提成 "+yuan(contract.expected())+" · 已到账 "+yuan(paid),14,TEAL,true));gap(entry,6);
                entry.addView(softButton("修改这份合同",v->showContractForm(c,contract)),lp(-1,-2));gap(entry,6);
                entry.addView(softButton("＋ 登记本合同提成到账",v->showReceiptForm(contract,null)),lp(-1,-2));gap(entry,8);
                List<Db.Receipt> receipts=db.receipts(contract.id);
                if(!receipts.isEmpty())entry.addView(txt("到账历史（点击可修改日期或金额）",13,MUTED,true));
                for(Db.Receipt receipt:receipts){TextView one=txt((receipt.receivedAt<=0?"历史日期待补":day(receipt.receivedAt))+" · "+yuan(receipt.amount)+"  ›",14,INK,false);
                    pad(one,4,10,4,10);one.setOnClickListener(v->showReceiptForm(contract,receipt));entry.addView(one,lp(-1,-2));}
                signing.addView(entry,lp(-1,-2));separator(signing);
            }
        }
        signing.addView(button("＋ 新增签约合同",true,v->showContractForm(c,true)),lp(-1,-2));addCard(body,signing);
        section("跟进记录（"+db.follows(id).size()+"）");
        for(Db.Follow f:db.follows(id)){LinearLayout x=card();x.addView(iconRow("calendar",date(f.happenedAt),TEAL,14));gap(x,8);x.addView(txt(f.content,16,INK,false));gap(x,7);
            x.addView(txt("点击修改这条记录  ›",13,BLUE,true));x.setOnClickListener(v->showFollowForm(id,f));addCard(body,x);}
        body.addView(button("＋ 添加跟进记录",true,v->showFollowForm(id)),lp(-1,-2));gap(body,16);
        section("跟进提醒");
        for(Db.Task t:db.tasks("全部",id)){LinearLayout x=card();LinearLayout r=horizontal();r.addView(txt(date(t.dueAt),14,INK,true),new LinearLayout.LayoutParams(0,-2,1));
            r.addView(pill("done".equals(t.status)?"已完成":(t.overdue()?"已逾期":"待跟进"),"done".equals(t.status)?TEAL:(t.overdue()?RED:BLUE)));x.addView(r);gap(x,6);
            x.addView(txt(t.content,15,MUTED,false));gap(x,8);x.addView(txt("点击查看和修改提醒  ›",13,BLUE,true));
            x.setOnClickListener(v->showTaskDetail(t.id));addCard(body,x);}
        body.addView(button("＋ 设置下次联系提醒",false,v->showTaskForm(id)),lp(-1,-2));gap(body,20);
        TextView delete=txt("删除这位客户及其全部记录",14,RED,false);delete.setGravity(Gravity.CENTER);pad(delete,10,12,10,12);
        delete.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("确认删除客户？")
            .setMessage("将永久删除该客户的资料、跟进历史和提醒。此操作不可撤销，建议先备份。")
            .setNegativeButton("取消",null).setPositiveButton("确认删除",(d,w)->{
                for(Db.Task t:db.tasks("全部",id))ReminderScheduler.cancel(this,t.id);
                db.deleteClient(id);toast("客户已删除");showClients("",null,null);
            }).show());body.addView(delete,lp(-1,-2));
    }
    private void completeTask(Db.Task t,long openClientId){db.completeTask(t.id);ReminderScheduler.cancel(this,t.id);toast("跟进任务已完成");if(openClientId>0)showClient(openClientId);else showTasks("待处理");}
    private void requestNotifications(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQUEST_NOTICE);}
    private void showFollowForm(long clientId){showFollowForm(clientId,null);}
    private void showFollowForm(long clientId,Db.Follow editing){Db.Client c=db.client(clientId);if(c==null)return;currentClientId=clientId;
        screen(editing==null?"添加跟进记录":"修改跟进记录","follow_form",false);
        section(c.displayName()+" · 沟通记录");
        final long[] happenedAt={editing==null?System.currentTimeMillis():editing.happenedAt};
        TextView happened=softButton("补录沟通日期："+date(happenedAt[0])+" ▾",null);
        happened.setOnClickListener(v->dateTime(happenedAt[0],d->{happenedAt[0]=d;happened.setText("补录沟通日期："+date(d)+" ▾");}));
        body.addView(happened,lp(-1,-2));gap(body,12);
        EditText content=field(body,"沟通内容",editing==null?"":editing.content,true,false);
        final long[] due={0};
        if(editing==null){TextView pick=softButton("＋ 设置下次跟进时间（选填）",null);
            pick.setOnClickListener(v->dateTime(due[0],d->{due[0]=d;pick.setText("下次联系："+date(d));}));body.addView(pick,lp(-1,-2));gap(body,9);}
        EditText note=editing==null?field(body,"下次跟进事项（选填）","",true,false):null;
        body.addView(button(editing==null?"保存跟进记录":"保存修改",true,v->{
            String value=content.getText().toString().trim();if(value.isEmpty()){toast("请填写沟通内容");return;}
            if(due[0]>0&&due[0]<=System.currentTimeMillis()){toast("提醒时间应晚于现在");return;}
            try{if(editing==null)db.addFollow(clientId,happenedAt[0],value);else db.updateFollow(editing.id,happenedAt[0],value);
                if(due[0]>0){long taskId=db.addTask(clientId,due[0],note.getText().toString().trim());ReminderScheduler.schedule(this,db.task(taskId));requestNotifications();}
                toast("跟进记录已保存");showClient(clientId);
            }catch(Exception err){error("保存跟进记录失败",err);}
        }),lp(-1,-2));
        if(editing!=null){gap(body,12);TextView del=softButton("删除这条跟进记录",v->new AlertDialog.Builder(this).setTitle("确认删除这条跟进记录？")
            .setNegativeButton("取消",null).setPositiveButton("删除",(d,w)->{db.deleteFollow(editing.id);showClient(clientId);}).show());del.setTextColor(RED);body.addView(del,lp(-1,-2));}
    }
    private void showTaskForm(long clientId){showTaskForm(clientId,null,false);}
    private void showTaskForm(long clientId,boolean fromList){showTaskForm(clientId,null,fromList);}
    private void showTaskForm(long clientId,Db.Task editing,boolean fromList){
        Db.Client c=db.client(clientId);if(c==null)return;currentClientId=clientId;
        editingTaskId=editing==null?0:editing.id;taskFormFromList=fromList;
        screen(editing==null?"添加跟进提醒":"修改跟进提醒","task_form",false);
        LinearLayout welcome=card();welcome.addView(iconRow("user","提醒客户："+c.displayName(),TEAL,17));gap(welcome,8);
        welcome.addView(txt("填写提醒事项、选择时间，点击保存即可。",14,MUTED,false));addCard(body,welcome);
        EditText content=field(body,"提醒事项（例如：询问装修报价）",editing==null?"":editing.content,true,false);
        long initial=editing==null?0:editing.dueAt;final long[] due={initial};
        TextView pick=softButton(initial>0?"提醒时间："+date(initial):"＋ 选择提醒日期和时间",null);
        pick.setOnClickListener(v->dateTime(due[0],value->{due[0]=value;pick.setText("提醒时间："+date(value));}));body.addView(pick,lp(-1,-2));gap(body,12);
        body.addView(txt("到期通过手机通知提醒；实际送达时间可能受到系统省电设置影响。",13,MUTED,false));gap(body,14);
        body.addView(button(editing==null?"保存提醒":"保存修改",true,v->{
            if(due[0]<=System.currentTimeMillis()){toast("请选择未来的提醒日期和时间");return;}
            try{
                String note=content.getText().toString().trim();
                long taskId;
                if(editing!=null){db.updateTask(editing.id,due[0],note);ReminderScheduler.cancel(this,editing.id);if("done".equals(editing.status))db.reopenTask(editing.id);taskId=editing.id;}
                else taskId=db.addTask(clientId,due[0],note);
                ReminderScheduler.schedule(this,db.task(taskId));requestNotifications();toast("提醒已保存");
                if(editing!=null)showTaskDetail(taskId);else if(fromList)showTasks("待处理");else showClient(clientId);
            }catch(Exception e){error("保存提醒失败",e);}
        }),lp(-1,-2));
    }
    private void showPickReminderClient(){currentClientId=0;screen("选择提醒客户","reminder_picker",false);
        LinearLayout hint=card();hint.addView(txt("先选择客户，再填写提醒事项和时间。",16,INK,true));addCard(body,hint);
        EditText search=new EditText(this);search.setTextColor(INK);search.setTextSize(16*FONT_SCALES[fontIndex]);
        search.setSingleLine(true);search.setHint("输入客户姓名、电话或小区搜索");search.setBackground(shape(WHITE,12,LINE));pad(search,13,9,13,9);
        body.addView(search,lp(-1,-2));gap(body,12);
        LinearLayout results=vertical();body.addView(results,lp(-1,-2));
        Runnable refresh=()->{
            results.removeAllViews();
            int total=db.clientsCount(search.getText().toString(),null,null,null);
            List<Db.Client> clients=db.clientsPage(search.getText().toString(),null,null,null,80,0);
            int limit=clients.size();
            for(int i=0;i<limit;i++){
                Db.Client client=clients.get(i);LinearLayout item=card();LinearLayout top=horizontal();
                top.addView(avatarView(client.gender,43),lp(43,43));TextView label=txt(client.displayName()+"  ›",17,INK,true);
                LinearLayout.LayoutParams lineLp=new LinearLayout.LayoutParams(0,-2,1);lineLp.leftMargin=dp(10);top.addView(label,lineLp);
                item.addView(top,lp(-1,-2));gap(item,5);
                item.addView(txt((client.community.isEmpty()?"未填写小区":client.community)+(client.phone.isEmpty()?"":" · "+client.phone),13,MUTED,false));
                item.setOnClickListener(v->showTaskForm(client.id,true));addCard(results,item);
            }
            if(clients.isEmpty()){
                LinearLayout empty=card();empty.addView(txt("没有匹配的客户，请先新增客户。",15,MUTED,false));gap(empty,10);
                empty.addView(button("＋ 新增客户",true,v->showClientForm(null)),lp(-1,-2));addCard(results,empty);
            }else if(total>limit){results.addView(txt("还有更多客户，请输入姓名或电话缩小范围",14,MUTED,false));}
        };
        search.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){refresh.run();}
            @Override public void afterTextChanged(Editable e){}
        });
        refresh.run();
    }
    private void showTaskDetail(long taskId){Db.Task t=db.task(taskId);if(t==null){showTasks(lastTaskMode);return;}
        currentClientId=t.clientId;screen("提醒详情","task_detail",false);
        LinearLayout summary=card();LinearLayout row=horizontal();row.addView(avatarView(t.gender,50),lp(50,50));
        TextView title=txt(t.clientName,20,INK,true);LinearLayout.LayoutParams nameLp=new LinearLayout.LayoutParams(0,-2,1);nameLp.leftMargin=dp(10);row.addView(title,nameLp);
        row.addView(pill("done".equals(t.status)?"已完成":(t.overdue()?"已逾期":"待跟进"),"done".equals(t.status)?TEAL:(t.overdue()?RED:BLUE)));
        summary.addView(row,lp(-1,-2));separator(summary);
        info(summary,"所在小区",t.community);info(summary,"提醒事项",t.content.isEmpty()?"联系客户":t.content);
        info(summary,"提醒时间",date(t.dueAt));addCard(body,summary);
        if("pending".equals(t.status)){
            body.addView(button("✓ 标记已完成",true,v->{db.completeTask(t.id);ReminderScheduler.cancel(this,t.id);toast("提醒已完成");showTasks(lastTaskMode);}),lp(-1,-2));gap(body,10);
            body.addView(softButton("修改提醒时间或事项",v->showTaskForm(t.clientId,t,true)),lp(-1,-2));gap(body,10);
        }else{
            body.addView(button("恢复待办",false,v->{db.reopenTask(t.id);ReminderScheduler.schedule(this,db.task(t.id));showTaskDetail(t.id);}),lp(-1,-2));gap(body,10);
            body.addView(softButton("修改提醒",v->showTaskForm(t.clientId,t,true)),lp(-1,-2));gap(body,10);
        }
        TextView del=softButton("删除提醒",v->new AlertDialog.Builder(this).setTitle("确认删除提醒？")
            .setNegativeButton("取消",null).setPositiveButton("删除",(d,w)->{ReminderScheduler.cancel(this,t.id);db.deleteTask(t.id);showTasks(lastTaskMode);}).show());
        del.setTextColor(RED);body.addView(del,lp(-1,-2));gap(body,10);
        body.addView(softButton("查看客户档案",v->showClient(t.clientId)),lp(-1,-2));gap(body,10);
        body.addView(softButton("＋ 再添加提醒",v->showTaskForm(t.clientId,true)),lp(-1,-2));
    }
    private void reminderFilters(String mode){
        HorizontalScrollView scroller=new HorizontalScrollView(this);scroller.setHorizontalScrollBarEnabled(false);LinearLayout bar=horizontal();
        String[] labels={"逾期及今日","待处理","已完成","全部"};for(String item:labels){
            String actual="逾期及今日".equals(item)?"今天":item;
            TextView chip=softButton(item,v->showTasks(actual));if(actual.equals(mode)){chip.setBackground(shape(TEAL,18,0));chip.setTextColor(WHITE);}
            LinearLayout.LayoutParams w=lp(-2,-2);w.rightMargin=dp(7);bar.addView(chip,w);
        }scroller.addView(bar);body.addView(scroller,lp(-1,-2));
    }
    private void showTasks(String mode){
        if(!mode.equals(lastTaskMode)){taskListLimit=60;savedTaskScrollY=0;}
        lastTaskMode=mode;currentClientId=0;screen("跟进提醒","tasks",true);
        LinearLayout toolbar=fontIndex>=2?vertical():horizontal();TextView subtitle=txt("客户跟进提醒",17,INK,true);
        if(fontIndex>=2){toolbar.addView(subtitle,lp(-1,-2));gap(toolbar,8);}
        else toolbar.addView(subtitle,new LinearLayout.LayoutParams(0,-2,1));
        TextView add=button("＋ 添加提醒",true,v->showPickReminderClient());
        toolbar.addView(add,lp(fontIndex>=2?-1:-2,-2));body.addView(toolbar,lp(-1,-2));gap(body,11);
        reminderFilters(mode);gap(body,13);
        Calendar tomorrow=Calendar.getInstance();tomorrow.set(Calendar.HOUR_OF_DAY,0);tomorrow.set(Calendar.MINUTE,0);
        tomorrow.set(Calendar.SECOND,0);tomorrow.set(Calendar.MILLISECOND,0);tomorrow.add(Calendar.DAY_OF_MONTH,1);
        long before=tomorrow.getTimeInMillis();
        int total=db.tasksCount(mode,0,before);
        body.addView(txt(("今天".equals(mode)?"逾期及今日":mode)+" · "+total+"条",14,MUTED,true));gap(body,8);
        int offset=0;
        while(offset<Math.min(total,taskListLimit)){
            for(Db.Task task:db.tasksPage(mode,0,before,Math.min(60,taskListLimit-offset),offset))addCard(body,reminderTile(task));
            offset+=60;
        }
        if(total==0){LinearLayout empty=card();empty.addView(iconRow("calendar","暂无符合条件的提醒",TEAL,15));gap(empty,8);
            empty.addView(txt("点击“添加提醒”，选择客户并设置事项和时间。",14,MUTED,false));addCard(body,empty);}
        if(total>taskListLimit){
            TextView more=softButton("加载更多提醒（已显示 "+Math.min(total,taskListLimit)+" / "+total+"）",v->{
                savedTaskScrollY=pageScroll==null?0:pageScroll.getScrollY();restoreTaskPosition=true;
                taskListLimit+=60;showTasks(mode);
            });addCard(body,more);
        }
        if(restoreTaskPosition){restoreTaskPosition=false;int y=savedTaskScrollY;if(pageScroll!=null)pageScroll.post(()->pageScroll.scrollTo(0,y));}
    }
    private void selectReportingMonth(){
        LinearLayout selectors=horizontal();pad(selectors,12,12,12,12);
        NumberPicker year=new NumberPicker(this);year.setMinValue(2000);year.setMaxValue(2100);
        year.setValue(reportingMonth.year);year.setWrapSelectorWheel(false);
        NumberPicker month=new NumberPicker(this);month.setMinValue(1);month.setMaxValue(12);
        month.setValue(reportingMonth.month);month.setWrapSelectorWheel(true);
        selectors.addView(year,new LinearLayout.LayoutParams(0,dp(170),1));
        selectors.addView(month,new LinearLayout.LayoutParams(0,dp(170),1));
        new AlertDialog.Builder(this).setTitle("选择统计年份和月份")
            .setView(selectors).setNegativeButton("取消",null)
            .setPositiveButton("确定",(dialog,which)->{
                reportingMonth=new MonthPeriod(year.getValue(), month.getValue());showStats();
            }).show();
    }
    private void shiftReportingMonth(int offset){reportingMonth=reportingMonth.plusMonths(offset);showStats();}
    private void showStats(){currentClientId=0;screen("统计与备份","mine",true);
        long[] bounds=reportingMonth.bounds();Db.Stats s=db.stats(bounds[0],bounds[1]);
        section("业绩统计");
        LinearLayout chooser=card();
        TextView label=txt("选择统计月份",13,MUTED,true);chooser.addView(label);gap(chooser,4);
        TextView chosen=txt(reportingMonth.label()+"  ▾",21,BLUE,true);
        chosen.setGravity(Gravity.CENTER);pad(chosen,8,7,8,7);
        chosen.setBackground(shape(Color.rgb(234,243,253),12,0));
        chosen.setOnClickListener(v->selectReportingMonth());chooser.addView(chosen,lp(-1,-2));gap(chooser,6);
        LinearLayout nav=horizontal();
        TextView previous=softButton("‹ 上个月",v->shiftReportingMonth(-1));
        TextView next=softButton("下个月 ›",v->shiftReportingMonth(1));
        LinearLayout.LayoutParams one=new LinearLayout.LayoutParams(0,-2,1);one.rightMargin=dp(8);
        nav.addView(previous,one);nav.addView(next,new LinearLayout.LayoutParams(0,-2,1));
        chooser.addView(nav);addCard(body,chooser);
        metricGrid(new String[]{"签约客户","签约总金额","预计提成","已收提成"},
            new String[]{""+s.monthSigned,yuan(s.monthAmount),yuan(s.monthExpected),yuan(s.monthReceived)},
            new int[]{BLUE,TEAL,Color.rgb(145,87,15),Color.rgb(117,67,173)},
            new View.OnClickListener[]{v->showMonthSignedClients("mine"),v->showMonthSignedClients("mine"),
                v->showMonthSignedClients("mine"),v->showMonthReceipts()});
        LinearLayout trend=card();trend.addView(txt("近6个月签约业绩趋势",17,INK,true));gap(trend,7);
        double[] months=new double[6];String[] labels=new String[6];for(int i=0;i<6;i++){
            MonthPeriod m=reportingMonth.plusMonths(i-5);long[] range=m.bounds();months[i]=db.stats(range[0],range[1]).monthAmount;labels[i]=m.month+"月";}
        TrendChartView bars=new TrendChartView(this,months,labels,FONT_SCALES[fontIndex]);
        trend.addView(bars,lp(-1,fontIndex>=2?230:195));
        if(fontIndex>=2){
            for(int i=0;i<months.length;i++)trend.addView(txt(labels[i]+"签约："+yuan(months[i]),13,INK,false));
        }
        addCard(body,trend);
        TextView note=txt("签约金额和预计提成按合同签约月份统计；已收提成按到账日期统计。旧版无日期的累计提成须补录日期后才能计入某个月。",13,MUTED,false);
        body.addView(note,lp(-1,-2));gap(body,12);
        body.addView(softButton("查看客户来源统计（按所选月份）",v->showSourceStatistics()),lp(-1,-2));gap(body,10);
        section("数据管理");
        LinearLayout menu=card();
        menu.addView(menuItem("cloud","完整备份","将全部客户与跟进记录备份到本地",v->saveFile("backup","application/json","装修客户管家备份_"+System.currentTimeMillis()+".json")));
        separator(menu);menu.addView(menuItem("database","恢复数据","从备份文件恢复客户资料",v->restoreFile()));
        separator(menu);menu.addView(menuItem("excel","导出 Excel","导出客户、跟进及业绩表格",v->saveFile("xlsx","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","装修客户报表_"+System.currentTimeMillis()+".xlsx")));
        separator(menu);menu.addView(menuItem("excel","导入Excel客户","从现有表格导入基础客户，重复手机号跳过",v->openExcelImport()));
        separator(menu);menu.addView(menuItem("mobile","换手机迁移","先备份，再将文件传到新手机并恢复",v->showSettings()));
        addCard(body,menu);
        body.addView(button("字体大小与更多设置",false,v->showSettings()),lp(-1,-2));
    }
    private void showSourceStatistics(){currentClientId=0;screen("客户来源统计","source_stats",false);long[] b=reportingMonth.bounds();
        section(reportingMonth.label()+" · 获客与签约");List<Db.SourceStats> stats=db.sourceStats(b[0],b[1]);int[] amounts=new int[stats.size()];
        for(int i=0;i<stats.size();i++)amounts[i]=stats.get(i).customers;sourceMiniChart(amounts);
        for(int i=0;i<stats.size();i++){Db.SourceStats item=stats.get(i);int color=SourcePalette.color(i);LinearLayout tile=card();LinearLayout row=horizontal();
            LinearLayout symbol=vertical();symbol.setGravity(Gravity.CENTER);symbol.setBackground(shape(tint(color),13,0));symbol.addView(icon(sourceIcon(item.source),color,25),lp(25,25));row.addView(symbol,lp(44,44));
            LinearLayout detail=vertical();detail.addView(txt(item.source,16,INK,true));gap(detail,2);detail.addView(txt("新增客户 "+item.customers+" · 签约客户 "+item.signed,13,color,true));
            LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(0,-2,1);mp.leftMargin=dp(11);row.addView(detail,mp);tile.addView(row,lp(-1,-2));addCard(body,tile);}
        body.addView(txt("新增按获客日期统计，签约按合同签约日期统计。",12,MUTED,false));
    }
    private LinearLayout menuItem(String iconName,String title,String sub,View.OnClickListener click){LinearLayout r=horizontal();pad(r,0,9,0,9);
        LinearLayout circle=vertical();circle.setGravity(Gravity.CENTER);circle.setBackground(shape(Color.rgb(228,242,255),13,0));circle.addView(icon(iconName,BLUE,24),lp(24,24));r.addView(circle,lp(44,44));
        LinearLayout words=vertical();words.addView(txt(title,16,INK,true));gap(words,3);words.addView(txt(sub,12,MUTED,false));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.leftMargin=dp(12);r.addView(words,p);r.addView(icon("arrow",MUTED,17),lp(17,17));r.setOnClickListener(click);return r;}
    private void showSettings(){currentClientId=0;screen("设置与数据管理","settings",false);
        section("字体大小 · 全软件统一生效");
        LinearLayout card=card();for(int i=0;i<FONT_LABELS.length;i++){
            final int idx=i;String mark=i==fontIndex?"●  ":"○  ";TextView t=txt(mark+FONT_LABELS[i],i==fontIndex?19:17,i==fontIndex?TEAL:INK,i==fontIndex);
            t.setMinHeight(dp(53));t.setOnClickListener(v->{fontIndex=idx;getPreferences(0).edit().putInt("font_size",idx).apply();showSettings();});card.addView(t,lp(-1,-2));if(i<FONT_LABELS.length-1)separator(card);
        }addCard(body,card);
        section("客户数据");
        LinearLayout data=card();data.addView(button("完整备份（JSON）",true,v->saveFile("backup","application/json","装修客户管家备份_"+System.currentTimeMillis()+".json")),lp(-1,-2));gap(data,10);
        data.addView(button("恢复备份数据",false,v->restoreFile()),lp(-1,-2));gap(data,10);
        data.addView(button("导出Excel（.xlsx）",false,v->saveFile("xlsx","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","装修客户报表_"+System.currentTimeMillis()+".xlsx")),lp(-1,-2));gap(data,10);
        data.addView(button("导入Excel客户资料",false,v->openExcelImport()),lp(-1,-2));gap(data,12);
        data.addView(txt("换手机：旧手机生成完整备份文件 → 将文件传到新手机 → 新手机安装应用并选择“恢复备份数据”。恢复会替换新手机中已有数据，请先备份。",14,MUTED,false));
        addCard(body,data);
        LinearLayout info=card();info.addView(txt("隐私与提醒",17,INK,true));gap(info,8);
        info.addView(txt("客户资料只存储在手机本地；应用不申请联网权限。导出的备份和Excel含个人信息，请妥善保管。",14,MUTED,false));gap(info,8);
        info.addView(txt("通知提醒需要系统通知权限，部分手机的省电设置可能延迟通知。",14,MUTED,false));gap(info,12);
        info.addView(softButton("检查并申请通知权限",v->requestNotifications()),lp(-1,-2));addCard(body,info);
    }
    private void saveFile(String op,String type,String suggestedName){fileOperation=op;Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType(type);intent.putExtra(Intent.EXTRA_TITLE,suggestedName);startActivityForResult(intent,REQUEST_FILE);}
    private void restoreFile(){fileOperation="restore";Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");startActivityForResult(intent,REQUEST_FILE);}
    private void openExcelImport(){fileOperation="import_xlsx";Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");startActivityForResult(intent,REQUEST_FILE);}

    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
        if(request!=REQUEST_FILE)return;
        String op=fileOperation;fileOperation="";
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        if(!"backup".equals(op)&&!"xlsx".equals(op)&&!"restore".equals(op)&&!"import_xlsx".equals(op)){
            new AlertDialog.Builder(this).setTitle("为保护数据，操作已取消")
                .setMessage("系统恢复页面后无法确定之前选择的是导出还是导入。请重新发起文件操作。")
                .setPositiveButton("确定",null).show();return;
        }
        Uri uri=data.getData();
        if("restore".equals(op)){
            try(InputStream in=getContentResolver().openInputStream(uri)){
                if(in==null)throw new Exception("备份文件无法打开");Transfer.BackupInfo info=Transfer.inspect(in);
                new AlertDialog.Builder(this).setTitle("检查备份内容")
                    .setMessage(info.summary()+"\n建议先给当前手机做完整备份。")
                    .setNegativeButton("取消",null).setPositiveButton("确认覆盖恢复",(dialog,which)->performFile(op,uri)).show();
            }catch(Exception e){error("备份文件无法识别，尚未覆盖任何数据",e);}
        }else if("import_xlsx".equals(op)){
            new AlertDialog.Builder(this).setTitle("导入Excel客户资料？")
                .setMessage("仅从第一张工作表导入客户基础资料；重复手机号会跳过，不会覆盖原客户或导入合同提成。")
                .setNegativeButton("取消",null).setPositiveButton("开始导入",(d,w)->performFile(op,uri)).show();
        }else performFile(op,uri);
    }
    private void performFile(String operation,Uri uri){
        if(!"restore".equals(operation)&&!"import_xlsx".equals(operation)&&!"xlsx".equals(operation)&&!"backup".equals(operation)){
            toast("无法识别的文件操作已取消");return;
        }
        try{
            if("restore".equals(operation)){
                try(InputStream in=getContentResolver().openInputStream(uri)){
                    if(in==null)throw new Exception("无法打开备份文件");Transfer.restore(this,db,in);
                }
                toast("恢复完成，客户和跟进记录已重新导入");showHome();
            }else if("import_xlsx".equals(operation)){
                String summary;try(InputStream in=getContentResolver().openInputStream(uri)){
                    if(in==null)throw new Exception("无法打开Excel文件");summary=Transfer.importExcel(db,in);
                }
                new AlertDialog.Builder(this).setTitle("导入结果").setMessage(summary).setPositiveButton("查看客户",(d,w)->showClients("",null,null)).show();
            }else{
                try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){
                    if(out==null)throw new Exception("无法创建导出文件");
                    if("xlsx".equals(operation))Transfer.exportExcel(db,out);
                    else if("backup".equals(operation))Transfer.backup(db,out);
                    else throw new IllegalStateException("不允许的输出类型");
                }
                if("backup".equals(operation))getPreferences(0).edit().putLong("last_backup",System.currentTimeMillis()).apply();
                new AlertDialog.Builder(this).setTitle("导出成功").setMessage("文件已保存到刚才选择的位置。请妥善保管客户资料。")
                    .setPositiveButton("确定",null).show();
            }
        }catch(Exception ex){error("文件处理失败，原有资料未主动清空",ex);}
    }
    private void error(String prefix,Exception e){new AlertDialog.Builder(this).setTitle(prefix).setMessage(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()).setPositiveButton("确定",null).show();}
    private void toast(String text){Toast.makeText(this,text,Toast.LENGTH_SHORT).show();}
}
