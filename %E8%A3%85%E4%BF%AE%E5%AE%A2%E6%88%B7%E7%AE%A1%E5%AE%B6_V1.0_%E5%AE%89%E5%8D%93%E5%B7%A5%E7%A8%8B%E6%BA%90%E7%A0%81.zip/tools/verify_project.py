#!/usr/bin/env python3
"""无需 Android SDK 的静态检查；不等于 APK 编译验收。"""
from pathlib import Path
import re,sqlite3,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
for path in sorted(root.glob('app/src/main/**/*.xml')):
    ET.parse(path)
    print('XML OK',path.relative_to(root))
source=(root/'app/src/main/java/com/decor/clientmanager/Db.java').read_text()
statements=re.findall(r'db\.execSQL\("(CREATE (?:TABLE|INDEX) .*?)"\);',source)
assert len(statements)==6,len(statements)
con=sqlite3.connect(':memory:')
con.execute('PRAGMA foreign_keys=ON')
for sql in statements: con.execute(sql)
con.execute('INSERT INTO clients (name,created_at,updated_at) VALUES (?,?,?)',('张先生',1,1))
con.execute('INSERT INTO followups (client_id,happened_at,content) VALUES (?,?,?)',(1,1,'测试跟进'))
con.execute('INSERT INTO reminders (client_id,due_at,content) VALUES (?,?,?)',(1,2,'测试提醒'))
assert con.execute('SELECT COUNT(*) FROM reminders').fetchone()[0]==1
con.execute('DELETE FROM clients WHERE id=1')
assert con.execute('SELECT COUNT(*) FROM reminders').fetchone()[0]==0
assert con.execute('SELECT COUNT(*) FROM followups').fetchone()[0]==0
print('SQLite: 建表、外键、删除联动 OK')
main=(root/'app/src/main/java/com/decor/clientmanager/MainActivity.java').read_text()
assert 'case "待判断":return BLUE;' in main
assert all(f'"{s}"' in main or f'"{s}"' in source for s in ('高意向','一般意向','低意向','待判断','已签约','暂不考虑'))
transfer=(root/'app/src/main/java/com/decor/clientmanager/Transfer.java').read_text()
assert 'xl/worksheets/sheet4.xml' in transfer
assert 'ZipOutputStream' in transfer and 'db.insertOrThrow' not in transfer  # d.insertOrThrow is transactional restore
assert 'd.beginTransaction()' in transfer and 'd.setTransactionSuccessful()' in transfer
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
assert 'android.permission.INTERNET' not in manifest
assert 'POST_NOTIFICATIONS' in manifest
workflow=(root/'.github/workflows/build-apk.yml').read_text()
assert 'assembleDebug' in workflow and 'upload-artifact' in workflow
print('状态配色、无联网权限、4个Excel工作表、事务恢复、构建流程：静态检查 OK')
