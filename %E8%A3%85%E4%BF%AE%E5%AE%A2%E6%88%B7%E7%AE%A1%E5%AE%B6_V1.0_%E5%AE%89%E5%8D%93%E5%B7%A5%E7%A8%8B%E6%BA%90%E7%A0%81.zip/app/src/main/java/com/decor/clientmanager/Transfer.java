package com.decor.clientmanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** 完整JSON备份/恢复和真正的 XLSX Excel 工作簿导出，无第三方依赖。 */
public final class Transfer {
    private Transfer(){}
    private static final String[] TABLES={"clients","followups","reminders"};
    private static final String[][] KEYS={
      {"id","name","phone","wechat","source","community","building","area","budget","renovation_type","needs","notes","stage","intent","signed_at","contract_amount","commission_rate","received_amount","created_at","updated_at"},
      {"id","client_id","happened_at","content"},
      {"id","client_id","due_at","content","status"}
    };
    private static String date(long ms) {if(ms<=0)return "";return new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.CHINA).format(new Date(ms));}
    private static JSONArray dump(SQLiteDatabase db,String table) throws JSONException {
        JSONArray arr=new JSONArray();
        try(Cursor c=db.query(table,null,null,null,null,null,"id ASC")){
            String[] names=c.getColumnNames();
            while(c.moveToNext()){
                JSONObject o=new JSONObject();
                for(int i=0;i<names.length;i++){
                    switch(c.getType(i)){
                        case Cursor.FIELD_TYPE_NULL: o.put(names[i],JSONObject.NULL);break;
                        case Cursor.FIELD_TYPE_INTEGER: o.put(names[i],c.getLong(i));break;
                        case Cursor.FIELD_TYPE_FLOAT: o.put(names[i],c.getDouble(i));break;
                        default:o.put(names[i],c.getString(i));
                    }
                }
                arr.put(o);
            }
        }
        return arr;
    }
    public static void backup(Db db,OutputStream out)throws Exception{
        JSONObject data=new JSONObject();data.put("format","DECORATION_CLIENTS_BACKUP");data.put("version",1);
        data.put("created_at",System.currentTimeMillis());
        SQLiteDatabase d=db.getReadableDatabase();
        for(String table:TABLES)data.put(table,dump(d,table));
        out.write(data.toString(2).getBytes(StandardCharsets.UTF_8));out.flush();
    }
    private static byte[] read(InputStream in)throws Exception{
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int n;
        // Avoid unexpectedly huge documents consuming the phone's memory.
        while((n=in.read(buffer))!=-1){out.write(buffer,0,n);if(out.size()>80*1024*1024)throw new Exception("备份文件超过80MB，请使用较小的有效备份文件");}
        return out.toByteArray();
    }
    public static void restore(Context ctx,Db db,InputStream in)throws Exception{
        JSONObject data=new JSONObject(new String(read(in),StandardCharsets.UTF_8));
        if(!"DECORATION_CLIENTS_BACKUP".equals(data.optString("format"))||data.optInt("version")!=1)
            throw new Exception("文件不是受支持的装修客户管家V1备份");
        JSONArray clients=data.getJSONArray("clients"),follows=data.getJSONArray("followups"),reminders=data.getJSONArray("reminders");
        JSONArray[] all={clients,follows,reminders};
        Set<Long> clientIds=new HashSet<>();
        for(int t=0;t<all.length;t++){
            Set<Long> ids=new HashSet<>();
            for(int i=0;i<all[t].length();i++){
                JSONObject obj=all[t].getJSONObject(i);long id=obj.getLong("id");
                if(id<=0||!ids.add(id))throw new Exception("备份中存在重复或无效ID");
                for(String key:KEYS[t])if(!obj.has(key)||obj.isNull(key))throw new Exception("备份缺少字段："+key);
                if(t==0){clientIds.add(id);if(obj.getString("name").trim().isEmpty() && obj.getString("phone").trim().isEmpty())throw new Exception("存在无姓名和电话的无效客户");}
                else if(!clientIds.contains(obj.getLong("client_id")))throw new Exception("跟进或提醒引用了不存在的客户");
                if(t==2 && !("pending".equals(obj.getString("status")) || "done".equals(obj.getString("status"))))throw new Exception("提醒状态无效");
            }
        }
        SQLiteDatabase d=db.getWritableDatabase();d.beginTransaction();
        try{
            d.delete("reminders",null,null);d.delete("followups",null,null);d.delete("clients",null,null);
            for(int t=0;t<all.length;t++){
                for(int i=0;i<all[t].length();i++){
                    JSONObject obj=all[t].getJSONObject(i);ContentValues cv=new ContentValues();
                    for(String key:KEYS[t]){
                        Object val=obj.get(key);
                        if(val instanceof Integer || val instanceof Long)cv.put(key,((Number)val).longValue());
                        else if(val instanceof Number)cv.put(key,((Number)val).doubleValue());
                        else cv.put(key,String.valueOf(val));
                    }
                    d.insertOrThrow(TABLES[t],null,cv);
                }
            }
            d.setTransactionSuccessful();
        } finally {d.endTransaction();}
        ReminderScheduler.rescheduleAll(ctx);
    }

    /** OOXML (.xlsx) all values stored as inline text to prevent spreadsheet formula injection. */
    public static void exportExcel(Db db,OutputStream output)throws Exception {
        ZipOutputStream zip=new ZipOutputStream(output,StandardCharsets.UTF_8);
        add(zip,"[Content_Types].xml","<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"+
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"+
            "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/worksheets/sheet2.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/worksheets/sheet3.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/worksheets/sheet4.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>");
        add(zip,"_rels/.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
        add(zip,"xl/workbook.xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"客户资料\" sheetId=\"1\" r:id=\"rId1\"/><sheet name=\"跟进记录\" sheetId=\"2\" r:id=\"rId2\"/><sheet name=\"跟进提醒\" sheetId=\"3\" r:id=\"rId3\"/><sheet name=\"签约业绩\" sheetId=\"4\" r:id=\"rId4\"/></sheets></workbook>");
        add(zip,"xl/_rels/workbook.xml.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet2.xml\"/><Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet3.xml\"/><Relationship Id=\"rId4\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet4.xml\"/></Relationships>");
        List<String[]> customers=new ArrayList<>();customers.add(new String[]{"编号","姓名/称呼","手机号","微信号","客户来源","小区","楼栋房号","房屋面积(㎡)","装修预算","装修类型","装修需求","备注","业务进度","意向程度","签约时间","合同金额(元)","提成比例(%)","预计提成(元)","已收提成(元)","登记时间"});
        for(Db.Client c:db.clients("",null,null))customers.add(new String[]{""+c.id,c.name,c.phone,c.wechat,c.source,c.community,c.building,c.area,c.budget,c.renovationType,c.needs,c.notes,c.stage,c.intent,date(c.signedAt),""+c.contractAmount,""+c.commissionRate,""+c.expected(),""+c.receivedAmount,date(c.createdAt)});
        add(zip,"xl/worksheets/sheet1.xml",sheet(customers,0,15,16,17,18));
        List<String[]> follows=new ArrayList<>();follows.add(new String[]{"客户编号","客户姓名","跟进时间","沟通内容"});
        try(Cursor c=db.getReadableDatabase().rawQuery("SELECT f.client_id,c.name,c.phone,f.happened_at,f.content FROM followups f JOIN clients c ON f.client_id=c.id ORDER BY f.happened_at DESC",null)) {
            while(c.moveToNext())follows.add(new String[]{""+c.getLong(0),c.getString(1).isEmpty()?c.getString(2):c.getString(1),date(c.getLong(3)),c.getString(4)});
        }
        add(zip,"xl/worksheets/sheet2.xml",sheet(follows,0));
        List<String[]> tasks=new ArrayList<>();tasks.add(new String[]{"客户编号","客户姓名","提醒日期","跟进事项","任务状态"});
        for(Db.Task t:db.tasks("全部",0)) tasks.add(new String[]{""+t.clientId,t.clientName,date(t.dueAt),t.content,"done".equals(t.status)?"已完成":(t.overdue()?"已逾期":"待跟进")});
        add(zip,"xl/worksheets/sheet3.xml",sheet(tasks,0));
        List<String[]> contracts=new ArrayList<>();contracts.add(new String[]{"客户编号","客户姓名","签约日期","合同金额(元)","提成比例(%)","预计提成(元)","已收提成(元)","尚未收到(元)"});
        for(Db.Client c:db.clients("",null,null))if("已签约".equals(c.stage)){
            contracts.add(new String[]{""+c.id,c.displayName(),date(c.signedAt),""+c.contractAmount,""+c.commissionRate,""+c.expected(),""+c.receivedAmount,""+Math.max(0,c.expected()-c.receivedAmount)});
        }
        add(zip,"xl/worksheets/sheet4.xml",sheet(contracts,0,3,4,5,6,7));
        zip.finish();zip.flush();
    }
    private static void add(ZipOutputStream z,String name,String content)throws Exception{
        z.putNextEntry(new ZipEntry(name));z.write(content.getBytes(StandardCharsets.UTF_8));z.closeEntry();
    }
    private static String xml(String text){
        if(text==null)return "";
        StringBuilder s=new StringBuilder();for(int i=0;i<text.length();i++){
            char ch=text.charAt(i);
            if(ch=='&')s.append("&amp;");else if(ch=='<')s.append("&lt;");else if(ch=='>')s.append("&gt;");
            else if(ch=='\"')s.append("&quot;");else if(ch=='\'')s.append("&apos;");
            else if(ch==9||ch==10||ch==13||ch>=32)s.append(ch);
        }return s.toString();
    }
    private static String sheet(List<String[]> rows,int... numericColumns){
        StringBuilder s=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");
        for(int r=0;r<rows.size();r++){
            s.append("<row r=\"").append(r+1).append("\">");
            String[] row=rows.get(r);for(int col=0;col<row.length;col++){
                int n=col+1;StringBuilder ref=new StringBuilder();while(n>0){n--;ref.insert(0,(char)('A'+(n%26)));n/=26;}
                boolean isNumber=false;
                if(r>0){for(int k:numericColumns)if(k==col){
                    try {double nval=Double.parseDouble(row[col]);isNumber=Double.isFinite(nval);}
                    catch(Exception ignored){}break;
                }}
                if(isNumber)s.append("<c r=\"").append(ref).append(r+1).append("\"><v>").append(xml(row[col])).append("</v></c>");
                else s.append("<c r=\"").append(ref).append(r+1).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(xml(row[col])).append("</t></is></c>");
            }s.append("</row>");
        }return s.append("</sheetData></worksheet>").toString();
    }
}
