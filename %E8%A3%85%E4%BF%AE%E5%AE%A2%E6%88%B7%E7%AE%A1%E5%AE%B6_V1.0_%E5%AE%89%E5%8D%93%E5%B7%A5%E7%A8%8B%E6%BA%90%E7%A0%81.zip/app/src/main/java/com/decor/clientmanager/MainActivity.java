package com.decor.clientmanager;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int BG=Color.rgb(247,251,253),WHITE=Color.WHITE,INK=Color.rgb(25,44,59),MUTED=Color.rgb(77,95,109);
    private static final int TEAL=Color.rgb(14,153,140),BLUE=Color.rgb(35,105,206),RED=Color.rgb(184,44,57),LINE=Color.rgb(223,235,239);
    private static final int REQUEST_FILE=200, REQUEST_NOTICE=300;
    private final String[] FONT_LABELS={"标准","大字体","超大字体","特大字体"};
    private final float[] FONT_SCALES={1.00f,1.15f,1.31f,1.52f};
    private Db db;
    private LinearLayout root,body;
    private String currentPage="home",fileOperation="";
    private long currentClientId=0;
    private int fontIndex=1;

    @Override public void onCreate(Bundle b){super.onCreate(b);db=new Db(this);fontIndex=Math.max(0,Math.min(3,getPreferences(0).getInt("font_size",1)));
        long target=getIntent().getLongExtra("open_client_id",0);
        if(target>0&&db.client(target)!=null)showClient(target);else showHome();}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);
        long target=intent.getLongExtra("open_client_id",0);if(target>0 && db.client(target)!=null)showClient(target);}
    @Override protected void onDestroy(){db.close();super.onDestroy();}
    @Override public void onBackPressed(){
        if("home".equals(currentPage)){super.onBackPressed();return;}
        if("client".equals(currentPage)){showClients("",null,null);return;}
        if(("client_form".equals(currentPage)||"follow_form".equals(currentPage)||"task_form".equals(currentPage))&&currentClientId>0){showClient(currentClientId);return;}
        showHome();
    }
    private int dp(float n){return (int)(getResources().getDisplayMetrics().density*n+0.5f);}
    private GradientDrawable shape(int fill,int radius,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private void pad(View v,int l,int t,int r,int b){v.setPadding(dp(l),dp(t),dp(r),dp(b));}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout.LayoutParams lp(int width,int height){return new LinearLayout.LayoutParams(width<0?width:dp(width),height<0?height:dp(height));}
    private void gap(LinearLayout l,int height){View v=new View(this);l.addView(v,lp(1,height));}
    private TextView txt(String value,float sp,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(TypedValue.COMPLEX_UNIT_SP,sp*FONT_SCALES[fontIndex]);t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);t.setIncludeFontPadding(true);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private TextView button(String title,boolean primary,View.OnClickListener action){TextView t=txt(title,15,primary?WHITE:TEAL,true);t.setGravity(Gravity.CENTER);t.setMinHeight(dp(50));
        t.setBackground(shape(primary?TEAL:Color.rgb(234,248,246),14,primary?0:Color.rgb(175,221,215)));pad(t,15,10,15,10);t.setOnClickListener(action);return t;}
    private TextView softButton(String title,View.OnClickListener action){TextView t=txt(title,14,BLUE,true);t.setGravity(Gravity.CENTER);t.setMinHeight(dp(43));
        t.setBackground(shape(Color.rgb(234,243,253),12,0));pad(t,13,8,13,8);t.setOnClickListener(action);return t;}
    private LinearLayout card(){LinearLayout l=vertical();l.setBackground(shape(WHITE,18,LINE));pad(l,15,15,15,15);return l;}
    private void addCard(LinearLayout parent,View card){LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(12);parent.addView(card,p);}
    private LinearLayout rowSpace(){LinearLayout r=horizontal();r.setGravity(Gravity.CENTER_VERTICAL);return r;}
    private void separator(LinearLayout l){View v=new View(this);v.setBackgroundColor(LINE);LinearLayout.LayoutParams p=lp(-1,1);p.topMargin=dp(10);p.bottomMargin=dp(10);l.addView(v,p);}
    private void screen(String title,String page,boolean showNav){currentPage=page;root=vertical();root.setBackgroundColor(BG);setContentView(root);
        LinearLayout top=horizontal();pad(top,18,17,18,14);top.setBackgroundColor(WHITE);
        if(!"home".equals(page)){TextView back=txt("‹",30,INK,false);pad(back,2,0,22,0);back.setOnClickListener(v->onBackPressed());top.addView(back,lp(-2,-2));}
        TextView heading=txt(title,21,INK,true);top.addView(heading,new LinearLayout.LayoutParams(0,-2,1));
        if("home".equals(page)){TextView settings=txt("⚙ 设置",14,TEAL,true);pad(settings,8,10,2,10);settings.setOnClickListener(v->showSettings());top.addView(settings);}
        root.addView(top,lp(-1,-2));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setClipToPadding(false);
        body=vertical();pad(body,16,15,16,22);scroll.addView(body,new ScrollView.LayoutParams(-1,-2));root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(showNav)navbar(page);
    }
    private void navbar(String selected){LinearLayout nav=horizontal();nav.setBackgroundColor(WHITE);pad(nav,5,7,5,7);
        String[] labels={"工作台","客户","提醒","业绩"};String[] icons={"⌂","♙","◷","▥"};String[] pages={"home","clients","tasks","stats"};
        for(int i=0;i<labels.length;i++){final String page=pages[i];LinearLayout cell=vertical();cell.setGravity(Gravity.CENTER);pad(cell,2,5,2,5);
            int color=selected.equals(page)?TEAL:MUTED;TextView ico=txt(icons[i],20,color,true),lab=txt(labels[i],12,color,selected.equals(page));ico.setGravity(Gravity.CENTER);lab.setGravity(Gravity.CENTER);
            cell.addView(ico,lp(-1,-2));cell.addView(lab,lp(-1,-2));cell.setOnClickListener(v->{switch(page){case "home":showHome();break;case "clients":showClients("",null,null);break;case "tasks":showTasks("待处理");break;default:showStats();}});
            nav.addView(cell,new LinearLayout.LayoutParams(0,-2,1));}
        root.addView(nav,lp(-1,-2));
    }
    private void section(String label){TextView t=txt(label,18,INK,true);LinearLayout.LayoutParams p=lp(-1,-2);p.topMargin=dp(8);p.bottomMargin=dp(12);body.addView(t,p);}
    private String date(long timestamp){return timestamp<=0?"未设置":new SimpleDateFormat("yyyy年M月d日 HH:mm",Locale.CHINA).format(new Date(timestamp));}
    private String day(long t){return t<=0?"未签约":new SimpleDateFormat("yyyy-MM-dd",Locale.CHINA).format(new Date(t));}
    private String yuan(double v){return new DecimalFormat("¥#,##0.##").format(v);}
    private int stageColor(String status){switch(status){case "新客户":return Color.rgb(3,129,159);case "已联系":return BLUE;case "有意向":return Color.rgb(19,149,118);case "已量房":return Color.rgb(118,75,182);case "已报价":return Color.rgb(177,103,22);case "已签约":return Color.rgb(16,124,57);default:return MUTED;}}
    private int intentColor(String intent){switch(intent){case "高意向":return Color.rgb(16,135,82);case "一般意向":return Color.rgb(176,107,18);case "待判断":return BLUE;default:return MUTED;}}
    private TextView pill(String title,int color){TextView t=txt(title,13,color,true);pad(t,12,6,12,6);t.setBackground(shape(tint(color),22,0));return t;}
    private int tint(int color){int r=Color.red(color),g=Color.green(color),b=Color.blue(color);return Color.rgb((r+255*7)/8,(g+255*7)/8,(b+255*7)/8);}
    private void tags(LinearLayout l,String stage,String intent){HorizontalScrollView h=new HorizontalScrollView(this);h.setHorizontalScrollBarEnabled(false);LinearLayout r=horizontal();r.addView(pill(stage,stageColor(stage)));View space=new View(this);r.addView(space,lp(8,1));r.addView(pill(intent,intentColor(intent)));h.addView(r);l.addView(h,lp(-1,-2));}
    private void info(LinearLayout l,String title,String value){LinearLayout r=horizontal();TextView a=txt(title,14,MUTED,false),b=txt(value==null||value.isEmpty()?"未填写":value,15,INK,false);
        r.addView(a,lp(94,-2));r.addView(b,new LinearLayout.LayoutParams(0,-2,1));l.addView(r,lp(-1,-2));gap(l,10);}
    private LinearLayout statistic(String name,String num,int color){LinearLayout c=card();c.setBackground(shape(tint(color),17,0));c.addView(txt(name,14,MUTED,false));gap(c,8);c.addView(txt(num,21,color,true));return c;}
    private void metricGrid(String[] names,String[] values,int[] colors){for(int i=0;i<names.length;i+=2){LinearLayout r=horizontal();
        for(int j=i;j<Math.min(i+2,names.length);j++){LinearLayout card=statistic(names[j],values[j],colors[j]);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.rightMargin=j%2==0?dp(8):0;r.addView(card,p);}
        LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(10);body.addView(r,p);}}
    private Calendar[] monthBounds(){Calendar start=Calendar.getInstance();start.set(Calendar.DAY_OF_MONTH,1);start.set(Calendar.HOUR_OF_DAY,0);start.set(Calendar.MINUTE,0);start.set(Calendar.SECOND,0);start.set(Calendar.MILLISECOND,0);
        Calendar end=(Calendar)start.clone();end.add(Calendar.MONTH,1);return new Calendar[]{start,end};}
    private void showHome(){screen("装修客户管家","home",true);Calendar[] bounds=monthBounds();Db.Stats s=db.stats(bounds[0].getTimeInMillis(),bounds[1].getTimeInMillis());
        LinearLayout banner=card();banner.setBackground(shape(Color.rgb(224,247,244),18,0));banner.addView(txt("今天要联系哪些客户？",19,TEAL,true));gap(banner,5);
        banner.addView(txt("打开跟进记录，了解上次沟通内容，再联系客户。",14,INK,false));addCard(body,banner);
        section("今日待跟进（含逾期） · "+db.todayCount()+"项");
        Calendar d=Calendar.getInstance();d.set(Calendar.HOUR_OF_DAY,0);d.set(Calendar.MINUTE,0);d.set(Calendar.SECOND,0);d.set(Calendar.MILLISECOND,0);d.add(Calendar.DAY_OF_MONTH,1);
        int count=0;for(Db.Task task:db.tasks("待处理",0)){
            if(task.dueAt>=d.getTimeInMillis())continue;
            LinearLayout c=card();LinearLayout r=horizontal();TextView name=txt(task.clientName,17,INK,true);r.addView(name,new LinearLayout.LayoutParams(0,-2,1));
            r.addView(pill(task.overdue()?"已逾期":"待跟进",task.overdue()?RED:BLUE));c.addView(r);gap(c,6);
            c.addView(txt(task.community+" · "+task.content,14,MUTED,false));gap(c,5);c.addView(txt(date(task.dueAt),13,task.overdue()?RED:MUTED,false));
            c.setOnClickListener(v->showClient(task.clientId));addCard(body,c);count++;if(count>=5)break;
        }
        if(count==0){LinearLayout empty=card();empty.addView(txt("今天暂无待跟进事项",15,MUTED,false));addCard(body,empty);}
        TextView all=softButton("查看全部跟进提醒",v->showTasks("待处理"));addCard(body,all);
        section("客户与业绩概览");metricGrid(new String[]{"客户总数","高意向客户","本月签约","预计提成"},
            new String[]{""+s.customers,""+s.highIntent,""+s.monthSigned,yuan(s.monthExpected)},new int[]{BLUE,TEAL,Color.rgb(123,82,191),Color.rgb(177,103,22)});
        gap(body,4);body.addView(button("＋ 新增客户",true,v->showClientForm(null)),lp(-1,-2));
    }
    private void showClients(String search,String stage,String intent){currentClientId=0;screen("客户管理","clients",true);
        LinearLayout q=horizontal();EditText input=new EditText(this);input.setSingleLine(true);input.setText(search==null?"":search);
        input.setHint("姓名、电话、微信、小区");input.setTextSize(15*FONT_SCALES[fontIndex]);input.setTextColor(INK);input.setHintTextColor(MUTED);input.setBackground(shape(WHITE,12,LINE));pad(input,12,7,10,7);
        q.addView(input,new LinearLayout.LayoutParams(0,dp(50),1));TextView go=softButton("搜索",v->showClients(input.getText().toString(),stage,intent));LinearLayout.LayoutParams g=lp(-2,50);g.leftMargin=dp(8);q.addView(go,g);body.addView(q,lp(-1,-2));gap(body,10);
        LinearLayout f=horizontal();TextView byStage=softButton(stage==null?"全部状态 ▾":stage+" ▾",v->choose("业务进展",concat("全部状态",Db.STAGES),stage==null?"全部状态":stage,chosen->showClients(input.getText().toString(),"全部状态".equals(chosen)?null:chosen,intent)));
        TextView byIntent=softButton(intent==null?"全部意向 ▾":intent+" ▾",v->choose("意向程度",concat("全部意向",Db.INTENTS),intent==null?"全部意向":intent,chosen->showClients(input.getText().toString(),stage,"全部意向".equals(chosen)?null:chosen)));
        f.addView(byStage,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.leftMargin=dp(8);f.addView(byIntent,p);body.addView(f,lp(-1,-2));gap(body,8);
        List<Db.Client> clients=db.clients(search,stage,intent);section("客户列表 · "+clients.size()+"人");
        for(Db.Client c:clients){LinearLayout x=card();x.addView(txt(c.displayName(),17,INK,true));gap(x,4);
            x.addView(txt((c.community.isEmpty()?"未填写小区":c.community)+" · "+(c.phone.isEmpty()?"无手机号":c.phone),14,MUTED,false));gap(x,9);tags(x,c.stage,c.intent);
            x.setOnClickListener(v->showClient(c.id));addCard(body,x);}
        if(clients.isEmpty()){LinearLayout empty=card();empty.addView(txt("没有匹配的客户，试试调整搜索条件。",15,MUTED,false));addCard(body,empty);}
        body.addView(button("＋ 新增客户",true,v->showClientForm(null)));
    }
    private static String[] concat(String first,String[] rest){String[] out=new String[rest.length+1];out[0]=first;System.arraycopy(rest,0,out,1,rest.length);return out;}
    private interface ChooseListener{void selected(String value);}
    private void choose(String title,String[] options,String current,ChooseListener cb){int selected=0;for(int i=0;i<options.length;i++)if(options[i].equals(current)){selected=i;break;}
        new AlertDialog.Builder(this).setTitle(title).setSingleChoiceItems(options,selected,(dialog,index)->{dialog.dismiss();cb.selected(options[index]);}).setNegativeButton("取消",null).show();}
    private TextView selectField(LinearLayout container,String label,String[] opts,String[] chosen){LinearLayout row=vertical();row.addView(txt(label,15,INK,true));gap(row,5);
        TextView v=txt(chosen[0]+"  ▾",16,INK,false);pad(v,13,11,13,11);v.setMinHeight(dp(49));v.setBackground(shape(WHITE,12,LINE));
        v.setOnClickListener(view->choose(label,opts,chosen[0],newValue->{chosen[0]=newValue;v.setText(newValue+"  ▾");}));row.addView(v,lp(-1,-2));
        LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(12);container.addView(row,p);return v;}
    private EditText field(LinearLayout parent,String label,String val,boolean multiple,boolean numeric){LinearLayout l=vertical();l.addView(txt(label,15,INK,true));gap(l,5);
        EditText e=new EditText(this);e.setText(val==null?"":val);e.setTextColor(INK);e.setHintTextColor(MUTED);e.setTextSize(16*FONT_SCALES[fontIndex]);
        e.setBackground(shape(WHITE,12,LINE));pad(e,13,10,13,10);e.setMinHeight(dp(50));
        if(multiple){e.setSingleLine(false);e.setMinLines(2);e.setGravity(Gravity.TOP);}else e.setSingleLine(true);
        if(numeric)e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        l.addView(e,lp(-1,-2));LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(12);parent.addView(l,p);return e;}
    private double number(EditText ed){String text=ed.getText().toString().trim().replace(",","");return text.isEmpty()?0:Double.parseDouble(text);}
    private void showClientForm(Db.Client data){boolean editing=data!=null;Db.Client c=editing?data:new Db.Client();currentClientId=c.id;
        screen(editing?"编辑客户":"新增客户","client_form",false);
        LinearLayout banner=card();banner.setBackground(shape(Color.rgb(225,247,244),15,0));banner.addView(txt("快速录入",18,TEAL,true));gap(banner,6);
        banner.addView(txt("姓名或手机号至少填写一项即可保存，其余资料可后续补充。",14,INK,false));addCard(body,banner);
        EditText name=field(body,"客户姓名或称呼",c.name,false,false);
        EditText phone=field(body,"手机号码",c.phone,false,false);phone.setInputType(InputType.TYPE_CLASS_PHONE);
        EditText wechat=field(body,"微信号",c.wechat,false,false);
        final String[] source={c.source},stage={c.stage},intent={c.intent},reno={c.renovationType};
        selectField(body,"客户来源",Db.SOURCES,source);
        EditText community=field(body,"小区名称",c.community,false,false);
        TextView toggle=softButton(editing?"收起详细资料 / 展开":"填写更多资料（选填） ▾",null);
        body.addView(toggle,lp(-1,-2));gap(body,10);
        LinearLayout extras=vertical();body.addView(extras,lp(-1,-2));extras.setVisibility(editing?View.VISIBLE:View.GONE);
        toggle.setOnClickListener(v->{boolean show=extras.getVisibility()!=View.VISIBLE;extras.setVisibility(show?View.VISIBLE:View.GONE);
            toggle.setText(show?"收起详细资料 ▴":"填写更多资料（选填） ▾");});
        EditText building=field(extras,"楼栋和房号",c.building,false,false);
        EditText area=field(extras,"房屋面积（㎡）",c.area,false,true);
        EditText budget=field(extras,"装修预算",c.budget,false,false);
        selectField(extras,"装修类型",Db.RENOVATIONS,reno);
        EditText needs=field(extras,"装修需求",c.needs,true,false);
        EditText notes=field(extras,"备注（介绍人、客户顾虑等）",c.notes,true,false);
        selectField(extras,"业务进展",Db.STAGES,stage);
        selectField(extras,"客户意向",Db.INTENTS,intent);
        final long[] signedAt={c.signedAt};TextView signed=softButton("签约日期："+day(signedAt[0])+"（点击设置）",null);
        signed.setOnClickListener(v->dateOnly(signedAt[0],next->{signedAt[0]=next;signed.setText("签约日期："+day(next));}));extras.addView(signed,lp(-1,-2));gap(extras,12);
        EditText amount=field(extras,"合同金额（元）",c.contractAmount>0?""+c.contractAmount:"",false,true);
        EditText rate=field(extras,"提成比例（%）",c.commissionRate>0?""+c.commissionRate:"",false,true);
        EditText received=field(extras,"已收到提成（元）",c.receivedAmount>0?""+c.receivedAmount:"",false,true);
        body.addView(button("保存客户",true,v->{
            c.name=name.getText().toString().trim();c.phone=phone.getText().toString().trim();c.wechat=wechat.getText().toString().trim();
            if(c.name.isEmpty()&&c.phone.isEmpty()){toast("请至少填写客户姓名或手机号");return;}
            c.source=source[0];c.community=community.getText().toString();c.building=building.getText().toString();c.area=area.getText().toString();
            c.budget=budget.getText().toString();c.renovationType=reno[0];c.needs=needs.getText().toString();c.notes=notes.getText().toString();
            c.stage=stage[0];c.intent=intent[0];c.signedAt=signedAt[0];
            try{c.contractAmount=number(amount);c.commissionRate=number(rate);c.receivedAmount=number(received);}catch(NumberFormatException ex){toast("金额或提成比例格式不正确");return;}
            if(c.contractAmount<0||c.commissionRate<0||c.receivedAmount<0||c.commissionRate>100){toast("金额不能为负数，提成比例不能超过100%");return;}
            long duplicate=db.duplicatePhone(c.phone,c.id);
            if(duplicate>0){new AlertDialog.Builder(this).setTitle("发现相同手机号").setMessage("该号码已经登记。可以打开已有客户，或继续保存另一条客户档案。")
                .setPositiveButton("打开原档案",(dialog,which)->showClient(duplicate))
                .setNegativeButton("取消",null)
                .setNeutralButton("仍然保存",(dialog,which)->saveClientAndOpen(c)).show();}
            else saveClientAndOpen(c);
        }),lp(-1,-2));
        gap(body,20);
    }
    private void saveClientAndOpen(Db.Client c){try{long id=db.saveClient(c);toast("客户已保存");showClient(id);}catch(Exception ex){error("保存客户失败",ex);}}
    private interface DateListener {void selected(long millis);}
    private void dateOnly(long initial,DateListener listener){Calendar c=Calendar.getInstance();if(initial>0)c.setTimeInMillis(initial);
        new DatePickerDialog(this,(picker,year,month,day)->{Calendar chosen=Calendar.getInstance();chosen.set(year,month,day,12,0,0);chosen.set(Calendar.MILLISECOND,0);listener.selected(chosen.getTimeInMillis());},
            c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}
    private void dateTime(long initial,DateListener listener){Calendar c=Calendar.getInstance();if(initial>0)c.setTimeInMillis(initial);
        new DatePickerDialog(this,(picker,year,month,day)->{
            new TimePickerDialog(this,(t,hour,minute)->{Calendar d=Calendar.getInstance();d.set(year,month,day,hour,minute,0);d.set(Calendar.MILLISECOND,0);listener.selected(d.getTimeInMillis());},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show();
        },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}
    private void showClient(long id){Db.Client c=db.client(id);if(c==null){showClients("",null,null);return;}currentClientId=id;screen("客户详情","client",false);
        LinearLayout header=card();header.addView(txt(c.displayName(),23,INK,true));gap(header,9);tags(header,c.stage,c.intent);addCard(body,header);
        LinearLayout actions=horizontal();if(!c.phone.isEmpty()){TextView call=button("拨打电话",true,v->{Intent i=new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode(c.phone)));startActivity(i);});
            LinearLayout.LayoutParams a=new LinearLayout.LayoutParams(0,-2,1);actions.addView(call,a);}
        if(!c.wechat.isEmpty()){TextView copy=softButton("复制微信号",v->{ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(cm!=null){cm.setPrimaryClip(ClipData.newPlainText("微信号",c.wechat));toast("微信号已复制");}else toast("复制失败，请手动记录微信号");});
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.leftMargin=dp(8);actions.addView(copy,p);}
        if(actions.getChildCount()>0){body.addView(actions,lp(-1,-2));gap(body,12);}
        LinearLayout info=card();info.addView(txt("基本资料",18,INK,true));separator(info);
        info(info,"联系电话",c.phone);info(info,"微信号",c.wechat);info(info,"客户来源",c.source);info(info,"小区",c.community);info(info,"楼栋房号",c.building);
        info(info,"面积",c.area.isEmpty()?"":c.area+"㎡");info(info,"装修预算",c.budget);info(info,"装修类型",c.renovationType);info(info,"装修需求",c.needs);info(info,"备注",c.notes);
        if("已签约".equals(c.stage)){separator(info);info(info,"签约日期",day(c.signedAt));info(info,"合同金额",yuan(c.contractAmount));info(info,"提成比例",c.commissionRate+"%");info(info,"预计提成",yuan(c.expected()));info(info,"已收提成",yuan(c.receivedAmount));}
        addCard(body,info);
        body.addView(button("编辑客户资料",false,v->showClientForm(c)),lp(-1,-2));gap(body,12);
        section("跟进记录");
        for(Db.Follow f:db.follows(id)){LinearLayout x=card();x.addView(txt(date(f.happenedAt),13,TEAL,true));gap(x,8);x.addView(txt(f.content,16,INK,false));addCard(body,x);}
        body.addView(button("＋ 添加跟进记录",true,v->showFollowForm(id)),lp(-1,-2));gap(body,16);
        section("跟进提醒");
        for(Db.Task t:db.tasks("全部",id)){LinearLayout x=card();LinearLayout r=horizontal();r.addView(txt(date(t.dueAt),14,INK,true),new LinearLayout.LayoutParams(0,-2,1));
            r.addView(pill("done".equals(t.status)?"已完成":(t.overdue()?"已逾期":"待跟进"),"done".equals(t.status)?TEAL:(t.overdue()?RED:BLUE)));x.addView(r);gap(x,6);
            x.addView(txt(t.content,15,MUTED,false));if("pending".equals(t.status)){gap(x,9);x.addView(softButton("标记已完成",v->completeTask(t,id)),lp(-1,-2));}addCard(body,x);}
        body.addView(button("＋ 设置下次联系提醒",false,v->showTaskForm(id)),lp(-1,-2));gap(body,20);
        TextView delete=txt("删除这位客户及其全部记录",14,RED,false);delete.setGravity(Gravity.CENTER);pad(delete,10,12,10,12);
        delete.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("确认删除客户？")
            .setMessage("将永久删除该客户的资料、跟进历史和提醒。此操作不可撤销，建议先备份。")
            .setNegativeButton("取消",null).setPositiveButton("确认删除",(d,w)->{
                for(Db.Task t:db.tasks("全部",id))ReminderScheduler.cancel(this,t.id);
                db.deleteClient(id);toast("客户已删除");showClients("",null,null);
            }).show());body.addView(delete,lp(-1,-2));
    }
    private void completeTask(Db.Task t,long openClientId){db.completeTask(t.id);ReminderScheduler.cancel(this,t.id);toast("跟进任务已完成");if(openClientId>0)showClient(openClientId);else showTasks("待处理");}
    private void requestNotifications(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQUEST_NOTICE);}
    private void showFollowForm(long clientId){Db.Client c=db.client(clientId);if(c==null)return;currentClientId=clientId;screen("添加跟进记录","follow_form",false);
        section(c.displayName()+" · 本次沟通");EditText content=field(body,"沟通内容", "",true,false);
        final long[] due={0};TextView pick=softButton("＋ 设置下次跟进时间（选填）",null);
        pick.setOnClickListener(v->dateTime(due[0],value->{due[0]=value;pick.setText("下次联系："+date(value));}));body.addView(pick,lp(-1,-2));gap(body,14);
        EditText note=field(body,"下次跟进事项（设置时间后选填）","",true,false);
        body.addView(button("保存跟进记录",true,v->{String text=content.getText().toString().trim();if(text.isEmpty()){toast("请填写本次沟通内容");return;}
            if(due[0]>0 && due[0]<=System.currentTimeMillis()){toast("下次联系时间应晚于现在");return;}
            try{db.addFollow(clientId,text);if(due[0]>0){long id=db.addTask(clientId,due[0],note.getText().toString().trim());ReminderScheduler.schedule(this,db.task(id));requestNotifications();}
                toast("跟进记录已保存");showClient(clientId);
            }catch(Exception e){error("保存跟进失败",e);}
        }),lp(-1,-2));
    }
    private void showTaskForm(long clientId){Db.Client c=db.client(clientId);if(c==null)return;currentClientId=clientId;screen("设置跟进提醒","task_form",false);
        section("联系客户："+c.displayName());EditText content=field(body,"跟进事项（例如确认报价）","",true,false);
        final long[] due={0};TextView pick=softButton("选择提醒日期与时间",null);
        pick.setOnClickListener(v->dateTime(due[0],value->{due[0]=value;pick.setText("提醒时间："+date(value));}));body.addView(pick,lp(-1,-2));gap(body,12);
        body.addView(txt("提醒会通过安卓系统通知发送；受手机后台策略影响，通知可能稍有延迟。",14,MUTED,false));gap(body,14);
        body.addView(button("保存提醒",true,v->{if(due[0]<=System.currentTimeMillis()){toast("请选择未来的提醒日期和时间");return;}
            try{long id=db.addTask(clientId,due[0],content.getText().toString().trim());ReminderScheduler.schedule(this,db.task(id));requestNotifications();toast("跟进提醒已保存");showClient(clientId);}
            catch(Exception e){error("保存提醒失败",e);}
        }),lp(-1,-2));
    }
    private void showTasks(String mode){currentClientId=0;screen("跟进提醒","tasks",true);
        LinearLayout r=horizontal();for(String option:new String[]{"待处理","已完成","全部"}){
            TextView b=softButton(option,v->showTasks(option));if(option.equals(mode))b.setBackground(shape(Color.rgb(218,247,243),12,0));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.rightMargin=dp(6);r.addView(b,p);}
        body.addView(r,lp(-1,-2));gap(body,14);
        List<Db.Task> tasks=db.tasks(mode,0);section("跟进任务 · "+tasks.size()+"项");
        for(Db.Task t:tasks){LinearLayout card=card();LinearLayout line=horizontal();line.addView(txt(t.clientName,17,INK,true),new LinearLayout.LayoutParams(0,-2,1));
            line.addView(pill("done".equals(t.status)?"已完成":(t.overdue()?"已逾期":"待跟进"),"done".equals(t.status)?TEAL:(t.overdue()?RED:BLUE)));card.addView(line);gap(card,7);
            card.addView(txt(t.content.isEmpty()?"联系客户":t.content,15,INK,false));gap(card,5);card.addView(txt(date(t.dueAt),14,t.overdue()?RED:MUTED,false));
            LinearLayout buttons=horizontal();TextView detail=softButton("查看客户",v->showClient(t.clientId));buttons.addView(detail,new LinearLayout.LayoutParams(0,-2,1));
            if("pending".equals(t.status)){TextView done=softButton("标记完成",v->completeTask(t,0));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.leftMargin=dp(8);buttons.addView(done,p);}
            gap(card,10);card.addView(buttons,lp(-1,-2));addCard(body,card);
        }
        if(tasks.isEmpty()){LinearLayout empty=card();empty.addView(txt("当前没有这类跟进任务。",15,MUTED,false));addCard(body,empty);}
    }
    private void showStats(){currentClientId=0;screen("业绩统计","stats",true);Calendar[] bounds=monthBounds();Db.Stats s=db.stats(bounds[0].getTimeInMillis(),bounds[1].getTimeInMillis());
        section(new SimpleDateFormat("yyyy年M月",Locale.CHINA).format(new Date())+" · 本月业绩");
        metricGrid(new String[]{"本月签约客户","签约总金额","预计提成","已收提成","尚未收到提成","高意向客户"},
            new String[]{""+s.monthSigned,yuan(s.monthAmount),yuan(s.monthExpected),yuan(s.monthReceived),yuan(Math.max(0,s.monthExpected-s.monthReceived)),""+s.highIntent},
            new int[]{BLUE,TEAL,Color.rgb(178,102,28),Color.rgb(117,78,178),RED,TEAL});
        LinearLayout note=card();note.addView(txt("统计说明",17,INK,true));gap(note,7);
        note.addView(txt("本月按客户档案中的签约日期统计；预计提成＝合同金额×提成比例，已收提成由本人填写。",14,MUTED,false));addCard(body,note);
        body.addView(button("数据备份与Excel导出",false,v->showSettings()));
    }
    private void showSettings(){currentClientId=0;screen("设置与数据管理","settings",false);
        section("字体大小 · 全软件统一生效");
        LinearLayout card=card();for(int i=0;i<FONT_LABELS.length;i++){
            final int idx=i;String mark=i==fontIndex?"●  ":"○  ";TextView t=txt(mark+FONT_LABELS[i],i==fontIndex?19:17,i==fontIndex?TEAL:INK,i==fontIndex);
            t.setMinHeight(dp(53));t.setOnClickListener(v->{fontIndex=idx;getPreferences(0).edit().putInt("font_size",idx).apply();showSettings();});card.addView(t,lp(-1,-2));if(i<FONT_LABELS.length-1)separator(card);
        }addCard(body,card);
        section("客户数据");
        LinearLayout data=card();data.addView(button("完整备份（JSON）",true,v->saveFile("backup","application/json","装修客户管家备份_"+System.currentTimeMillis()+".json")),lp(-1,-2));gap(data,10);
        data.addView(button("恢复备份数据",false,v->restoreFile()),lp(-1,-2));gap(data,10);
        data.addView(button("导出Excel（.xlsx）",false,v->saveFile("xlsx","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","装修客户报表_"+System.currentTimeMillis()+".xlsx")),lp(-1,-2));gap(data,12);
        data.addView(txt("换手机：旧手机生成完整备份文件 → 将文件传到新手机 → 新手机安装应用并选择“恢复备份数据”。恢复会替换新手机中已有数据，请先备份。",14,MUTED,false));
        addCard(body,data);
        LinearLayout info=card();info.addView(txt("隐私与提醒",17,INK,true));gap(info,8);
        info.addView(txt("客户资料只存储在手机本地；应用不申请联网权限。导出的备份和Excel含个人信息，请妥善保管。",14,MUTED,false));gap(info,8);
        info.addView(txt("通知提醒需要系统通知权限，部分手机的省电设置可能延迟通知。",14,MUTED,false));gap(info,12);
        info.addView(softButton("检查并申请通知权限",v->requestNotifications()),lp(-1,-2));addCard(body,info);
    }
    private void saveFile(String op,String type,String suggestedName){fileOperation=op;Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType(type);intent.putExtra(Intent.EXTRA_TITLE,suggestedName);startActivityForResult(intent,REQUEST_FILE);}
    private void restoreFile(){fileOperation="restore";Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");startActivityForResult(intent,REQUEST_FILE);}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
        if(request!=REQUEST_FILE||result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();String op=fileOperation;fileOperation="";
        if("restore".equals(op)){
            new AlertDialog.Builder(this).setTitle("确认恢复数据？")
                .setMessage("恢复会替换本手机的全部客户资料、跟进记录及提醒。建议先完成一次完整备份。")
                .setNegativeButton("取消",null).setPositiveButton("确认恢复",(dialog,which)->performFile(op,uri)).show();
        }else performFile(op,uri);
    }
    private void performFile(String operation,Uri uri){
        try{
            if("restore".equals(operation)){
                try(InputStream in=getContentResolver().openInputStream(uri)){
                    if(in==null)throw new Exception("无法打开备份文件");Transfer.restore(this,db,in);
                }
                toast("恢复完成，客户和跟进记录已重新导入");showHome();
            }else{
                try(OutputStream out=getContentResolver().openOutputStream(uri,"w")){
                    if(out==null)throw new Exception("无法创建导出文件");if("xlsx".equals(operation))Transfer.exportExcel(db,out);else Transfer.backup(db,out);
                }
                new AlertDialog.Builder(this).setTitle("导出成功").setMessage("文件已保存到刚才选择的位置。请妥善保管客户资料。")
                    .setPositiveButton("确定",null).show();
            }
        }catch(Exception ex){error("文件处理失败，原有资料未主动清空",ex);}
    }
    private void error(String prefix,Exception e){new AlertDialog.Builder(this).setTitle(prefix).setMessage(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()).setPositiveButton("确定",null).show();}
    private void toast(String text){Toast.makeText(this,text,Toast.LENGTH_SHORT).show();}
}
