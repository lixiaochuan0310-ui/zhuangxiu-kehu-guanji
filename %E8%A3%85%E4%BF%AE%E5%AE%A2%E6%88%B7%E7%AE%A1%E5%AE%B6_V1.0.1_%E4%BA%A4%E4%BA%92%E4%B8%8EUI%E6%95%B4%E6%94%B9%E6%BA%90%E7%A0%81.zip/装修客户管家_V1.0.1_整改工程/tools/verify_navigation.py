"""Navigation/interaction regression contracts; source-level checks, NOT Android runtime tests."""
from pathlib import Path
p=Path(__file__).resolve().parents[1]
s=(p/'app/src/main/java/com/decor/clientmanager/MainActivity.java').read_text()
d=(p/'app/src/main/java/com/decor/clientmanager/Db.java').read_text()
checks={
'workbench metrics support clicking': 'private void metricGrid(String[] names,String[] values,int[] colors,View.OnClickListener[] actions)' in s,
'home customers card opens customers': 'v->showClients("",null,null)' in s,
'home high intent card is filtered': 'v->showClients("",null,"高意向")' in s,
'home signed this month card opens month list': 'showMonthSignedClients("home")' in s,
'home income card opens financial screen': 'v->showStats()' in s,
'reminder list includes add button': 'button("＋ 添加提醒"' in s,
'reminder picker allows filtering customers': 'showPickReminderClient()' in s and 'addTextChangedListener' in s,
'reminder tiles click into detail': 'card.setOnClickListener(v->showTaskDetail(t.id))' in s,
'reminder detail has add reminder': 'private void showTaskDetail(long taskId)' in s and '"＋ 再添加提醒"' in s,
'reminder editor can update existing reminder': 'db.updateTask(' in s and 'void updateTask(' in d,
'reminder flow can create reminders': 'db.addTask(' in s,
'new future reminder appears in pending list': 'else if(fromList)showTasks("待处理")' in s,
'filters fit large text': 'private void reminderFilters(' in s,
'no network permission needed': 'android.permission.INTERNET' not in (p/'app/src/main/AndroidManifest.xml').read_text(),
}
for label,okay in checks.items():
 print(('PASS' if okay else 'FAIL')+': '+label)
assert all(checks.values()),'Navigation contracts incomplete'
