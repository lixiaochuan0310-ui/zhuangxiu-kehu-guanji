package com.decor.clientmanager;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int BG=Color.rgb(247,251,253),WHITE=Color.WHITE,INK=Color.rgb(25,44,59),MUTED=Color.rgb(77,95,109);
    private static final int TEAL=Color.rgb(14,153,140),BLUE=Color.rgb(35,105,206),RED=Color.rgb(184,44,57),LINE=Color.rgb(223,235,239);
    private static final int REQUEST_FILE=200, REQUEST_NOTICE=300;
    private final String[] FONT_LABELS={"标准","大字体","超大字体","特大字体"};
    private final float[] FONT_SCALES={1.00f,1.15f,1.31f,1.52f};
    private Db db;
    private LinearLayout root,body;
    private String currentPage="home",fileOperation="";
    private long currentClientId=0;
    private String lastTaskMode="今天", signedListReturn="home";
    private boolean taskFormFromList=false;
    private long editingTaskId=0;
    private int fontIndex=1;

    @Override public void onCreate(Bundle b){super.onCreate(b);db=new Db(this);fontIndex=Math.max(0,Math.min(3,getPreferences(0).getInt("font_size",1)));
        long target=getIntent().getLongExtra("open_client_id",0);
        if(target>0&&db.client(target)!=null)showClient(target);else showHome();}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);
        long target=intent.getLongExtra("open_client_id",0);if(target>0 && db.client(target)!=null)showClient(target);}
    @Override protected void onDestroy(){db.close();super.onDestroy();}
    @Override public void onBackPressed(){
        if("home".equals(currentPage)){super.onBackPressed();return;}
        if("client".equals(currentPage)){showClients("",null,null);return;}
        if("task_detail".equals(currentPage)||"reminder_picker".equals(currentPage)){showTasks(lastTaskMode);return;}
        if("signed_month".equals(currentPage)){if("mine".equals(signedListReturn))showStats();else showHome();return;}
        if("task_form".equals(currentPage)&&editingTaskId>0){showTaskDetail(editingTaskId);return;}
        if("task_form".equals(currentPage)&&taskFormFromList){showTasks(lastTaskMode);return;}
        if(("client_form".equals(currentPage)||"contract_form".equals(currentPage)||"follow_form".equals(currentPage)||"task_form".equals(currentPage))&&currentClientId>0){showClient(currentClientId);return;}
        showHome();
    }
    private int dp(float n){return (int)(getResources().getDisplayMetrics().density*n+0.5f);}
    private GradientDrawable shape(int fill,int radius,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private void pad(View v,int l,int t,int r,int b){v.setPadding(dp(l),dp(t),dp(r),dp(b));}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout.LayoutParams lp(int width,int height){return new LinearLayout.LayoutParams(width<0?width:dp(width),height<0?height:dp(height));}
    private void gap(LinearLayout l,int height){View v=new View(this);l.addView(v,lp(1,height));}
    private TextView txt(String value,float sp,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(TypedValue.COMPLEX_UNIT_SP,sp*FONT_SCALES[fontIndex]);t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);t.setIncludeFontPadding(true);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private TextView button(String title,boolean primary,View.OnClickListener action){TextView t=txt(title,15,primary?WHITE:TEAL,true);t.setGravity(Gravity.CENTER);t.setMinHeight(dp(50));
        t.setBackground(shape(primary?TEAL:Color.rgb(234,248,246),14,primary?0:Color.rgb(175,221,215)));pad(t,15,10,15,10);t.setOnClickListener(action);return t;}
    private TextView softButton(String title,View.OnClickListener action){TextView t=txt(title,14,BLUE,true);t.setGravity(Gravity.CENTER);t.setMinHeight(dp(43));
        t.setBackground(shape(Color.rgb(234,243,253),12,0));pad(t,13,8,13,8);t.setOnClickListener(action);return t;}
    private LinearLayout card(){LinearLayout l=vertical();l.setBackground(shape(WHITE,18,LINE));pad(l,15,15,15,15);return l;}
    private void addCard(LinearLayout parent,View card){LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(12);parent.addView(card,p);}
    private LinearLayout rowSpace(){LinearLayout r=horizontal();r.setGravity(Gravity.CENTER_VERTICAL);return r;}
    private void separator(LinearLayout l){View v=new View(this);v.setBackgroundColor(LINE);LinearLayout.LayoutParams p=lp(-1,1);p.topMargin=dp(10);p.bottomMargin=dp(10);l.addView(v,p);}
    private void screen(String title,String page,boolean showNav){currentPage=page;root=vertical();root.setBackgroundColor(BG);setContentView(root);
        LinearLayout top=horizontal();pad(top,18,17,18,14);top.setBackground("home".equals(page)?new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.rgb(2,136,123),Color.rgb(37,174,158)}):shape(WHITE,0,0));
        if(!"home".equals(page)){TextView back=txt("‹",30,INK,false);pad(back,2,0,22,0);back.setOnClickListener(v->onBackPressed());top.addView(back,lp(-2,-2));}
        TextView heading=txt(title,21,"home".equals(page)?WHITE:INK,true);top.addView(heading,new LinearLayout.LayoutParams(0,-2,1));
        if("home".equals(page)){TextView settings=txt("设置",14,WHITE,true);pad(settings,8,10,2,10);settings.setOnClickListener(v->showSettings());top.addView(settings);}
        root.addView(top,lp(-1,-2));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setClipToPadding(false);
        body=vertical();pad(body,16,15,16,22);scroll.addView(body,new ScrollView.LayoutParams(-1,-2));root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(showNav)navbar(page);
    }
    private void navbar(String selected){LinearLayout nav=horizontal();nav.setBackgroundColor(WHITE);pad(nav,5,7,5,7);
        String[] labels={"工作台","客户","提醒","我的"};String[] icons={"home","users","bell","user"};String[] pages={"home","clients","tasks","mine"};
        for(int i=0;i<labels.length;i++){final String page=pages[i];LinearLayout cell=vertical();cell.setGravity(Gravity.CENTER);pad(cell,2,5,2,5);
            int color=selected.equals(page)?TEAL:MUTED;UiIcon ico=icon(icons[i],color,23);TextView lab=txt(labels[i],12,color,selected.equals(page));lab.setGravity(Gravity.CENTER);
            cell.addView(ico,lp(25,25));gap(cell,3);cell.addView(lab,lp(-1,-2));cell.setOnClickListener(v->{switch(page){case "home":showHome();break;case "clients":showClients("",null,null);break;case "tasks":showTasks("待处理");break;default:showStats();}});
            nav.addView(cell,new LinearLayout.LayoutParams(0,-2,1));}
        root.addView(nav,lp(-1,-2));
    }
    private void section(String label){TextView t=txt(label,18,INK,true);LinearLayout.LayoutParams p=lp(-1,-2);p.topMargin=dp(8);p.bottomMargin=dp(12);body.addView(t,p);}
    private String date(long timestamp){return timestamp<=0?"未设置":new SimpleDateFormat("yyyy年M月d日 HH:mm",Locale.CHINA).format(new Date(timestamp));}
    private String day(long t){return t<=0?"未签约":new SimpleDateFormat("yyyy-MM-dd",Locale.CHINA).format(new Date(t));}
    private String yuan(double v){return new DecimalFormat("¥#,##0.##").format(v);}
    private int stageColor(String status){switch(status){case "新客户":return Color.rgb(3,129,159);case "已联系":return BLUE;case "有意向":return Color.rgb(19,149,118);case "已量房":return Color.rgb(118,75,182);case "已报价":return Color.rgb(177,103,22);case "已签约":return Color.rgb(16,124,57);default:return MUTED;}}
    private int intentColor(String intent){switch(intent){case "高意向":return Color.rgb(16,135,82);case "一般意向":return Color.rgb(176,107,18);case "待判断":return BLUE;default:return MUTED;}}
    private TextView pill(String title,int color){TextView t=txt(title,13,color,true);pad(t,12,6,12,6);t.setBackground(shape(tint(color),22,0));return t;}
    private int tint(int color){int r=Color.red(color),g=Color.green(color),b=Color.blue(color);return Color.rgb((r+255*7)/8,(g+255*7)/8,(b+255*7)/8);}
    private void tags(LinearLayout l,String stage,String intent){HorizontalScrollView h=new HorizontalScrollView(this);h.setHorizontalScrollBarEnabled(false);LinearLayout r=horizontal();r.addView(pill(stage,stageColor(stage)));View space=new View(this);r.addView(space,lp(8,1));r.addView(pill(intent,intentColor(intent)));h.addView(r);l.addView(h,lp(-1,-2));}
    private void info(LinearLayout l,String title,String value){LinearLayout r=horizontal();TextView a=txt(title,14,MUTED,false),b=txt(value==null||value.isEmpty()?"未填写":value,15,INK,false);
        r.addView(a,lp(94,-2));r.addView(b,new LinearLayout.LayoutParams(0,-2,1));l.addView(r,lp(-1,-2));gap(l,10);}
    private UiIcon icon(String name,int color,int size){UiIcon i=new UiIcon(this,name,color);i.setMinimumWidth(dp(size));i.setMinimumHeight(dp(size));return i;}
    private LinearLayout iconRow(String name,String value,int color,float size){LinearLayout row=horizontal();row.addView(icon(name,color,22),lp(22,22));
        TextView t=txt(value,size,color,false);LinearLayout.LayoutParams p=lp(-2,-2);p.leftMargin=dp(9);row.addView(t,p);return row;}
    private LinearLayout statistic(String name,String num,int color){
        LinearLayout c=card();c.setMinimumHeight(dp(100));c.setBackground(shape(tint(color),15,0));
        String symbol="chart";if(name.contains("客户"))symbol="users";if(name.contains("意向"))symbol="star";
        if(name.contains("签约"))symbol="check";if(name.contains("提成"))symbol="coin";if(name.contains("金额"))symbol="database";
        LinearLayout heading=horizontal();heading.addView(icon(symbol,color,23),lp(23,23));TextView label=txt(name,13,INK,true);
        LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,-2,1);q.leftMargin=dp(7);heading.addView(label,q);c.addView(heading,lp(-1,-2));gap(c,9);
        c.addView(txt(num,23,color,true),lp(-1,-2));return c;
    }
    private void metricGrid(String[] names,String[] values,int[] colors){metricGrid(names,values,colors,null);}
    private void metricGrid(String[] names,String[] values,int[] colors,View.OnClickListener[] actions){
        for(int i=0;i<names.length;i+=2){LinearLayout r=horizontal();r.setGravity(Gravity.TOP);
            for(int j=i;j<Math.min(i+2,names.length);j++){
                LinearLayout tile=statistic(names[j],values[j],colors[j]);
                if(actions!=null && j<actions.length && actions[j]!=null){
                    tile.setOnClickListener(actions[j]);tile.setClickable(true);tile.setFocusable(true);
                    tile.setContentDescription(names[j]+" "+values[j]+"，点击查看详情");
                    TextView arrow=txt("点击查看  ›",12,colors[j],true);gap(tile,7);tile.addView(arrow,lp(-1,-2));
                }
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.rightMargin=j%2==0?dp(8):0;r.addView(tile,p);
            }
            LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(9);body.addView(r,p);
        }
    }
    private Calendar[] monthBounds(){Calendar start=Calendar.getInstance();start.set(Calendar.DAY_OF_MONTH,1);start.set(Calendar.HOUR_OF_DAY,0);start.set(Calendar.MINUTE,0);start.set(Calendar.SECOND,0);start.set(Calendar.MILLISECOND,0);
        Calendar end=(Calendar)start.clone();end.add(Calendar.MONTH,1);return new Calendar[]{start,end};}
    private void showHome(){screen("装修客户管家","home",true);Calendar[] bounds=monthBounds();
        Db.Stats s=db.stats(bounds[0].getTimeInMillis(),bounds[1].getTimeInMillis());
        LinearLayout hello=card();LinearLayout line=horizontal();
        LinearLayout avatar=vertical();avatar.setGravity(Gravity.CENTER);avatar.setBackground(shape(Color.rgb(221,247,243),24,0));avatar.addView(icon("user",TEAL,25),lp(25,25));line.addView(avatar,lp(42,42));
        LinearLayout greet=vertical();String welcome=Calendar.getInstance().get(Calendar.HOUR_OF_DAY)<12?"早上好！":Calendar.getInstance().get(Calendar.HOUR_OF_DAY)<18?"下午好！":"晚上好！";
        greet.addView(txt(welcome,17,INK,true));greet.addView(txt("新的一天，记得跟进客户",12,MUTED,false));
        LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(0,-2,1);gp.leftMargin=dp(8);line.addView(greet,gp);
        LinearLayout today=vertical();today.setGravity(Gravity.CENTER);today.setBackground(shape(Color.rgb(234,247,253),12,0));pad(today,9,8,9,8);
        String displayDay=new SimpleDateFormat("M月d日",Locale.CHINA).format(new Date());today.addView(txt("今日",12,BLUE,true));today.addView(txt(displayDay,13,INK,true));line.addView(today,lp(-2,-2));
        hello.addView(line,lp(-1,-2));addCard(body,hello);
        LinearLayout followTitle=horizontal();followTitle.addView(icon("calendar",TEAL,21),lp(21,21));
        TextView t=txt("今日待跟进（"+db.todayCount()+"）",17,INK,true);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-2,1);tp.leftMargin=dp(6);followTitle.addView(t,tp);
        TextView more=txt("查看全部  ›",13,BLUE,true);more.setOnClickListener(v->showTasks("今天"));followTitle.addView(more,lp(-2,-2));
        body.addView(followTitle,lp(-1,-2));gap(body,10);
        Calendar tomorrow=Calendar.getInstance();tomorrow.set(Calendar.HOUR_OF_DAY,0);tomorrow.set(Calendar.MINUTE,0);tomorrow.set(Calendar.SECOND,0);tomorrow.set(Calendar.MILLISECOND,0);tomorrow.add(Calendar.DAY_OF_MONTH,1);
        int count=0;
        for(Db.Task task:db.tasks("待处理",0)){
            if(task.dueAt>=tomorrow.getTimeInMillis())continue;
            LinearLayout tile=card();LinearLayout row=horizontal();
            LinearLayout avatar2=vertical();avatar2.setGravity(Gravity.CENTER);avatar2.setBackground(shape(Color.rgb(223,248,244),23,0));avatar2.addView(icon("user",TEAL,23),lp(23,23));row.addView(avatar2,lp(43,43));
            LinearLayout detail=vertical();detail.addView(txt(task.clientName,17,INK,true));gap(detail,3);
            detail.addView(txt(task.community==null||task.community.isEmpty()?"未填写小区":task.community,13,MUTED,false));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-2,1);cp.leftMargin=dp(9);row.addView(detail,cp);
            row.addView(pill(task.overdue()?"已逾期":"待跟进",task.overdue()?RED:BLUE));tile.addView(row,lp(-1,-2));gap(tile,9);
            tile.addView(txt(task.content==null||task.content.trim().isEmpty()?"联系客户":task.content.trim(),15,INK,false));gap(tile,5);
            tile.addView(txt("提醒时间："+date(task.dueAt)+"  ›",13,task.overdue()?RED:MUTED,false));
            tile.setOnClickListener(v->showTaskDetail(task.id));tile.setClickable(true);tile.setFocusable(true);
            addCard(body,tile);count++;if(count>=3)break;
        }
        if(count==0){LinearLayout none=card();none.addView(txt("今天暂无待跟进客户",15,MUTED,false));addCard(body,none);}
        body.addView(softButton("＋ 添加跟进提醒",v->showPickReminderClient()),lp(-1,-2));gap(body,14);
        metricGrid(new String[]{"客户总数","高意向客户","本月签约","预计提成"},
            new String[]{""+s.customers,""+s.highIntent,""+s.monthSigned,yuan(s.monthExpected)},
            new int[]{Color.rgb(46,123,224),Color.rgb(26,161,117),Color.rgb(134,83,200),Color.rgb(212,130,38)},
            new View.OnClickListener[]{
                v->showClients("",null,null),
                v->showClients("",null,"高意向"),
                v->showMonthSignedClients("home"),
                v->showStats()
            });
        gap(body,12);
        body.addView(button("＋ 新增客户",true,v->showClientForm(null)),lp(-1,-2));
    }
    private void showMonthSignedClients(String origin){signedListReturn=origin;currentClientId=0;screen("本月签约客户","signed_month",false);
        Calendar[] bounds=monthBounds();Db.Stats stats=db.stats(bounds[0].getTimeInMillis(),bounds[1].getTimeInMillis());
        LinearLayout summary=card();summary.addView(txt("本月签约 "+stats.monthSigned+" 位客户",19,INK,true));gap(summary,5);
        summary.addView(txt("合同总金额 "+yuan(stats.monthAmount)+"  ·  预计提成 "+yuan(stats.monthExpected),14,MUTED,false));addCard(body,summary);
        int count=0;
        for(Db.Client client:db.clients("","已签约",null)){
            if(client.signedAt<bounds[0].getTimeInMillis()||client.signedAt>=bounds[1].getTimeInMillis())continue;
            LinearLayout card=card();card.addView(txt(client.displayName()+"  ›",18,INK,true));gap(card,7);
            card.addView(txt((client.community.isEmpty()?"未填写小区":client.community)+" · "+day(client.signedAt),14,MUTED,false));gap(card,7);
            card.addView(txt("合同金额 "+yuan(client.contractAmount)+" · 预计提成 "+yuan(client.expected()),14,TEAL,true));
            card.setOnClickListener(v->showClient(client.id));addCard(body,card);count++;
        }
        if(count==0){LinearLayout empty=card();empty.addView(txt("这个月还没有签约客户",15,MUTED,false));addCard(body,empty);}
    }
    private void showClients(String search,String stage,String intent){currentClientId=0;screen("客户管理","clients",true);
        LinearLayout q=horizontal();EditText input=new EditText(this);input.setSingleLine(true);input.setText(search==null?"":search);
        input.setHint("姓名、电话、微信、小区");input.setTextSize(15*FONT_SCALES[fontIndex]);input.setTextColor(INK);input.setHintTextColor(MUTED);input.setBackground(shape(WHITE,12,LINE));pad(input,12,7,10,7);
        q.addView(input,new LinearLayout.LayoutParams(0,dp(50),1));TextView go=softButton("搜索",v->showClients(input.getText().toString(),stage,intent));LinearLayout.LayoutParams g=lp(-2,50);g.leftMargin=dp(8);q.addView(go,g);body.addView(q,lp(-1,-2));gap(body,10);
        LinearLayout f=horizontal();TextView byStage=softButton(stage==null?"全部状态 ▾":stage+" ▾",v->choose("业务进展",concat("全部状态",Db.STAGES),stage==null?"全部状态":stage,chosen->showClients(input.getText().toString(),"全部状态".equals(chosen)?null:chosen,intent)));
        TextView byIntent=softButton(intent==null?"全部意向 ▾":intent+" ▾",v->choose("意向程度",concat("全部意向",Db.INTENTS),intent==null?"全部意向":intent,chosen->showClients(input.getText().toString(),stage,"全部意向".equals(chosen)?null:chosen)));
        f.addView(byStage,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.leftMargin=dp(8);f.addView(byIntent,p);body.addView(f,lp(-1,-2));gap(body,8);
        List<Db.Client> clients=db.clients(search,stage,intent);section("客户列表 · "+clients.size()+"人");
        for(Db.Client c:clients){LinearLayout x=card();x.addView(txt(c.displayName(),17,INK,true));gap(x,4);
            x.addView(txt((c.community.isEmpty()?"未填写小区":c.community)+" · "+(c.phone.isEmpty()?"无手机号":c.phone),14,MUTED,false));gap(x,9);tags(x,c.stage,c.intent);
            x.setOnClickListener(v->showClient(c.id));addCard(body,x);}
        if(clients.isEmpty()){LinearLayout empty=card();empty.addView(txt("没有匹配的客户，试试调整搜索条件。",15,MUTED,false));addCard(body,empty);}
        body.addView(button("＋ 新增客户",true,v->showClientForm(null)));
    }
    private static String[] concat(String first,String[] rest){String[] out=new String[rest.length+1];out[0]=first;System.arraycopy(rest,0,out,1,rest.length);return out;}
    private interface ChooseListener{void selected(String value);}
    private void choose(String title,String[] options,String current,ChooseListener cb){int selected=0;for(int i=0;i<options.length;i++)if(options[i].equals(current)){selected=i;break;}
        new AlertDialog.Builder(this).setTitle(title).setSingleChoiceItems(options,selected,(dialog,index)->{dialog.dismiss();cb.selected(options[index]);}).setNegativeButton("取消",null).show();}
    private TextView selectField(LinearLayout container,String label,String[] opts,String[] chosen){LinearLayout row=vertical();row.addView(txt(label,15,INK,true));gap(row,5);
        TextView v=txt(chosen[0]+"  ▾",16,INK,false);pad(v,13,11,13,11);v.setMinHeight(dp(49));v.setBackground(shape(WHITE,12,LINE));
        v.setOnClickListener(view->choose(label,opts,chosen[0],newValue->{chosen[0]=newValue;v.setText(newValue+"  ▾");}));row.addView(v,lp(-1,-2));
        LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(12);container.addView(row,p);return v;}
    private String sourceIcon(String source){switch(source){case "电话":return "phone";case "微信":return "chat";case "跑小区":return "walk";case "门店":return "store";case "熟人介绍":return "users";default:return "other";}}
    private LinearLayout sourceChoiceIcon(String source,boolean selected){
        LinearLayout chip=horizontal();chip.setGravity(Gravity.CENTER);pad(chip,4,9,4,9);
        chip.setBackground(shape(selected?Color.rgb(219,247,242):WHITE,11,selected?Color.rgb(69,188,165):LINE));
        chip.addView(icon(sourceIcon(source),selected?TEAL:MUTED,17),lp(17,17));
        TextView name=txt(source,12,selected?TEAL:INK,selected);LinearLayout.LayoutParams q=lp(-2,-2);q.leftMargin=dp(4);chip.addView(name,q);
        chip.setMinimumHeight(dp(45));return chip;
    }
    private void showSourceChoices(LinearLayout parent,String[] chosen){
        parent.addView(txt("客户来源",15,INK,true));gap(parent,8);
        LinearLayout grid=vertical();parent.addView(grid,lp(-1,-2));
        Runnable build=()->{grid.removeAllViews();for(int i=0,cols=fontIndex>=2?2:3;i<Db.SOURCES.length;i+=cols){LinearLayout row=horizontal();
            for(int j=i;j<Math.min(i+cols,Db.SOURCES.length);j++){String option=Db.SOURCES[j];LinearLayout chip=sourceChoiceIcon(option,option.equals(chosen[0]));
                chip.setOnClickListener(v->{chosen[0]=option;grid.removeAllViews();showSourceChoicesContent(grid,chosen);});
                LinearLayout.LayoutParams param=new LinearLayout.LayoutParams(0,-2,1);param.rightMargin=j%cols==cols-1?0:dp(6);row.addView(chip,param);}
            LinearLayout.LayoutParams rp=lp(-1,-2);rp.bottomMargin=dp(6);grid.addView(row,rp);}};
        build.run();gap(parent,9);
    }
    private void showSourceChoicesContent(LinearLayout grid,String[] chosen){for(int i=0,cols=fontIndex>=2?2:3;i<Db.SOURCES.length;i+=cols){LinearLayout row=horizontal();
        for(int j=i;j<Math.min(i+cols,Db.SOURCES.length);j++){String option=Db.SOURCES[j];LinearLayout chip=sourceChoiceIcon(option,option.equals(chosen[0]));
            chip.setOnClickListener(v->{chosen[0]=option;grid.removeAllViews();showSourceChoicesContent(grid,chosen);});
            LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(0,-2,1);qp.rightMargin=j%cols==cols-1?0:dp(6);row.addView(chip,qp);}
        LinearLayout.LayoutParams rowLp=lp(-1,-2);rowLp.bottomMargin=dp(6);grid.addView(row,rowLp);}}
    private EditText field(LinearLayout parent,String label,String val,boolean multiple,boolean numeric){LinearLayout l=vertical();l.addView(txt(label,15,INK,true));gap(l,5);
        EditText e=new EditText(this);e.setText(val==null?"":val);e.setTextColor(INK);e.setHintTextColor(MUTED);e.setTextSize(16*FONT_SCALES[fontIndex]);
        e.setBackground(shape(WHITE,12,LINE));pad(e,13,10,13,10);e.setMinHeight(dp(50));
        if(multiple){e.setSingleLine(false);e.setMinLines(2);e.setGravity(Gravity.TOP);}else e.setSingleLine(true);
        if(numeric)e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        l.addView(e,lp(-1,-2));LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(12);parent.addView(l,p);return e;}
    private double number(EditText ed){String text=ed.getText().toString().trim().replace(",","");return text.isEmpty()?0:Double.parseDouble(text);}
    private void showClientForm(Db.Client data){boolean editing=data!=null;Db.Client c=editing?data:new Db.Client();currentClientId=c.id;
        screen(editing?"编辑基本资料":"新增客户","client_form",false);
        LinearLayout banner=card();banner.setBackground(shape(Color.rgb(226,248,244),15,0));
        banner.addView(iconRow("plus","快速录入",TEAL,18));gap(banner,5);
        banner.addView(txt("姓名或手机号至少填一项即可保存，其他资料以后补充。",14,INK,false));addCard(body,banner);
        EditText name=field(body,"客户姓名或称呼",c.name,false,false);
        EditText phone=field(body,"手机号码",c.phone,false,false);phone.setInputType(InputType.TYPE_CLASS_PHONE);
        EditText wechat=field(body,"微信号",c.wechat,false,false);
        final String[] source={c.source},reno={c.renovationType};
        showSourceChoices(body,source);
        EditText community=field(body,"小区名称",c.community,false,false);
        TextView toggle=softButton(editing?"收起详细资料 ▴":"填写更多装修资料（选填） ▾",null);
        body.addView(toggle,lp(-1,-2));gap(body,12);
        LinearLayout extras=vertical();body.addView(extras,lp(-1,-2));extras.setVisibility(editing?View.VISIBLE:View.GONE);
        toggle.setOnClickListener(v->{boolean show=extras.getVisibility()!=View.VISIBLE;extras.setVisibility(show?View.VISIBLE:View.GONE);
            toggle.setText(show?"收起详细资料 ▴":"填写更多装修资料（选填） ▾");});
        EditText building=field(extras,"楼栋和房号",c.building,false,false);
        EditText area=field(extras,"房屋面积（㎡）",c.area,false,true);
        EditText budget=field(extras,"装修预算",c.budget,false,false);
        selectField(extras,"装修类型",Db.RENOVATIONS,reno);
        EditText needs=field(extras,"装修需求",c.needs,true,false);
        EditText notes=field(extras,"备注（介绍人、客户顾虑等）",c.notes,true,false);
        body.addView(button("保存客户",true,v->{
            c.name=name.getText().toString().trim();c.phone=phone.getText().toString().trim();c.wechat=wechat.getText().toString().trim();
            if(c.name.isEmpty()&&c.phone.isEmpty()){toast("请至少填写客户姓名或手机号");return;}
            c.source=source[0];c.community=community.getText().toString();c.building=building.getText().toString();c.area=area.getText().toString();
            c.budget=budget.getText().toString();c.renovationType=reno[0];c.needs=needs.getText().toString();c.notes=notes.getText().toString();
            long duplicate=db.duplicatePhone(c.phone,c.id);
            if(duplicate>0){new AlertDialog.Builder(this).setTitle("发现相同手机号").setMessage("该号码已经登记。可以打开已有客户，或继续保存另一条客户档案。")
                .setPositiveButton("打开原档案",(dialog,which)->showClient(duplicate))
                .setNegativeButton("取消",null)
                .setNeutralButton("仍然保存",(dialog,which)->saveClientAndOpen(c)).show();}
            else saveClientAndOpen(c);
        }),lp(-1,-2));
        gap(body,20);
    }
    private void saveClientAndOpen(Db.Client c){try{long id=db.saveClient(c);toast("客户已保存");showClient(id);}catch(Exception ex){error("保存客户失败",ex);}}
    private interface DateListener {void selected(long millis);}
    private void dateOnly(long initial,DateListener listener){Calendar c=Calendar.getInstance();if(initial>0)c.setTimeInMillis(initial);
        new DatePickerDialog(this,(picker,year,month,day)->{Calendar chosen=Calendar.getInstance();chosen.set(year,month,day,12,0,0);chosen.set(Calendar.MILLISECOND,0);listener.selected(chosen.getTimeInMillis());},
            c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}
    private void dateTime(long initial,DateListener listener){Calendar c=Calendar.getInstance();if(initial>0)c.setTimeInMillis(initial);
        new DatePickerDialog(this,(picker,year,month,day)->{
            new TimePickerDialog(this,(t,hour,minute)->{Calendar d=Calendar.getInstance();d.set(year,month,day,hour,minute,0);d.set(Calendar.MILLISECOND,0);listener.selected(d.getTimeInMillis());},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show();
        },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}
    private void changeStage(Db.Client c){choose("更新业务进展",Db.STAGES,c.stage,next->{
        if(next.equals(c.stage))return;
        if("已签约".equals(next)){showContractForm(c,true);return;}
        c.stage=next;try{db.saveClient(c);toast("业务进展已更新");showClient(c.id);}catch(Exception e){error("更新业务进展失败",e);}
    });}
    private void changeIntent(Db.Client c){choose("更新客户意向",Db.INTENTS,c.intent,next->{
        if(next.equals(c.intent))return;
        c.intent=next;try{db.saveClient(c);toast("客户意向已更新");showClient(c.id);}catch(Exception e){error("更新客户意向失败",e);}
    });}
    private void showContractForm(Db.Client c,boolean newSigning){currentClientId=c.id;screen("签约与提成","contract_form",false);
        LinearLayout banner=card();banner.setBackground(shape(Color.rgb(224,248,242),14,0));banner.addView(txt(c.displayName(),19,INK,true));gap(banner,6);
        banner.addView(txt(newSigning?"确认签约时再填写合同和提成，无需首次建档时填写。":"修改合同与提成信息，不影响客户基本资料。",14,MUTED,false));addCard(body,banner);
        final long[] signedAt={c.signedAt>0?c.signedAt:System.currentTimeMillis()};
        TextView signed=softButton("签约日期："+day(signedAt[0])+" ▾",null);
        signed.setOnClickListener(v->dateOnly(signedAt[0],date->{signedAt[0]=date;signed.setText("签约日期："+day(date)+" ▾");}));
        body.addView(signed,lp(-1,-2));gap(body,15);
        EditText amount=field(body,"合同金额（元）",c.contractAmount>0?""+c.contractAmount:"",false,true);
        EditText rate=field(body,"提成比例（%）",c.commissionRate>0?""+c.commissionRate:"",false,true);
        EditText received=field(body,"已收到提成（元）",c.receivedAmount>0?""+c.receivedAmount:"",false,true);
        body.addView(button(newSigning?"确认签约并保存":"保存合同与提成",true,v->{
            double a,r,got;try{a=number(amount);r=number(rate);got=number(received);}catch(NumberFormatException e){toast("请输入正确的金额和比例");return;}
            if(a<0||r<0||r>100||got<0){toast("金额不能为负，提成比例须为0～100%");return;}
            c.signedAt=signedAt[0];c.contractAmount=a;c.commissionRate=r;c.receivedAmount=got;c.stage="已签约";
            try{db.saveClient(c);toast("签约信息已保存");showClient(c.id);}catch(Exception ex){error("保存签约信息失败",ex);}
        }),lp(-1,-2));
    }
    private void showReceiveDialog(Db.Client c){EditText money=new EditText(this);money.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        money.setTextSize(18*FONT_SCALES[fontIndex]);money.setHint("输入本次收到的提成金额");
        new AlertDialog.Builder(this).setTitle("登记提成到账").setMessage("当前已收："+yuan(c.receivedAmount)+"。请输入本次新增到账金额。")
            .setView(money).setNegativeButton("取消",null).setPositiveButton("确认增加",(d,w)->{
                double newMoney;try{newMoney=number(money);}catch(NumberFormatException ex){toast("金额格式不正确");return;}
                if(newMoney<=0){toast("到账金额必须大于0");return;}
                c.receivedAmount+=newMoney;try{db.saveClient(c);showClient(c.id);}catch(Exception ex){error("登记到账失败",ex);}
            }).show();
    }
    private void showClient(long id){Db.Client c=db.client(id);if(c==null){showClients("",null,null);return;}currentClientId=id;screen("客户详情","client",false);
        LinearLayout header=card();LinearLayout top=horizontal();
        LinearLayout avatar=vertical();avatar.setGravity(Gravity.CENTER);avatar.setBackground(shape(Color.rgb(231,241,255),28,0));avatar.addView(icon("user",BLUE,32),lp(32,32));top.addView(avatar,lp(54,54));
        LinearLayout name=vertical();name.addView(txt(c.displayName(),22,INK,true));gap(name,8);tags(name,c.stage,c.intent);
        LinearLayout.LayoutParams nlp=new LinearLayout.LayoutParams(0,-2,1);nlp.leftMargin=dp(12);top.addView(name,nlp);header.addView(top,lp(-1,-2));
        gap(header,14);
        LinearLayout shortcut=horizontal();TextView stage=softButton("更新业务进展 ▾",v->changeStage(c));TextView intent=softButton("更新客户意向 ▾",v->changeIntent(c));
        if(fontIndex>=2){header.addView(stage,lp(-1,-2));gap(header,8);header.addView(intent,lp(-1,-2));}
        else{shortcut.addView(stage,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams pl=new LinearLayout.LayoutParams(0,-2,1);pl.leftMargin=dp(8);shortcut.addView(intent,pl);header.addView(shortcut,lp(-1,-2));}
        addCard(body,header);
        LinearLayout actions=horizontal();if(!c.phone.isEmpty()){TextView call=button("☎ 拨打电话",true,v->{Intent i=new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode(c.phone)));startActivity(i);});
            actions.addView(call,new LinearLayout.LayoutParams(0,-2,1));}
        if(!c.wechat.isEmpty()){TextView copy=softButton("复制微信号",v->{ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(cm!=null){cm.setPrimaryClip(ClipData.newPlainText("微信号",c.wechat));toast("微信号已复制");}else toast("复制失败，请手动记录微信号");});
            LinearLayout.LayoutParams lp2=new LinearLayout.LayoutParams(0,-2,1);lp2.leftMargin=dp(8);actions.addView(copy,lp2);}
        if(actions.getChildCount()>0){body.addView(actions,lp(-1,-2));gap(body,12);}
        LinearLayout detail=card();detail.addView(iconRow("clipboard","客户档案",TEAL,18));separator(detail);
        info(detail,"手机号",c.phone);info(detail,"微信号",c.wechat);info(detail,"小区",c.community);info(detail,"面积",c.area.isEmpty()?"":c.area+"㎡");
        info(detail,"装修预算",c.budget);info(detail,"装修类型",c.renovationType);info(detail,"客户来源",c.source);
        if(!c.building.isEmpty())info(detail,"楼栋房号",c.building);
        if(!c.needs.isEmpty())info(detail,"装修需求",c.needs);if(!c.notes.isEmpty())info(detail,"备注",c.notes);
        addCard(body,detail);
        body.addView(softButton("编辑客户基本资料",v->showClientForm(c)),lp(-1,-2));gap(body,11);
        LinearLayout signing=card();signing.addView(iconRow("coin","签约与提成",TEAL,18));separator(signing);
        if("已签约".equals(c.stage)){
            info(signing,"签约日期",day(c.signedAt));info(signing,"合同金额",yuan(c.contractAmount));info(signing,"提成比例",c.commissionRate+"%");
            info(signing,"预计提成",yuan(c.expected()));info(signing,"已收提成",yuan(c.receivedAmount));
            LinearLayout acts=horizontal();TextView update=softButton("修改合同/提成",v->showContractForm(c,false));TextView paid=button("登记提成到账",true,v->showReceiveDialog(c));
            if(fontIndex>=2){signing.addView(update,lp(-1,-2));gap(signing,8);signing.addView(paid,lp(-1,-2));}
            else{acts.addView(update,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams a=new LinearLayout.LayoutParams(0,-2,1);a.leftMargin=dp(8);acts.addView(paid,a);signing.addView(acts,lp(-1,-2));}
        }else{signing.addView(txt("客户尚未签约，签约后再登记合同和提成。",14,MUTED,false));gap(signing,10);
            signing.addView(button("登记签约与提成",true,v->showContractForm(c,true)),lp(-1,-2));}
        addCard(body,signing);
        section("跟进记录（"+db.follows(id).size()+"）");
        for(Db.Follow f:db.follows(id)){LinearLayout x=card();x.addView(iconRow("calendar",date(f.happenedAt),TEAL,14));gap(x,8);x.addView(txt(f.content,16,INK,false));addCard(body,x);}
        body.addView(button("＋ 添加跟进记录",true,v->showFollowForm(id)),lp(-1,-2));gap(body,16);
        section("跟进提醒");
        for(Db.Task t:db.tasks("全部",id)){LinearLayout x=card();LinearLayout r=horizontal();r.addView(txt(date(t.dueAt),14,INK,true),new LinearLayout.LayoutParams(0,-2,1));
            r.addView(pill("done".equals(t.status)?"已完成":(t.overdue()?"已逾期":"待跟进"),"done".equals(t.status)?TEAL:(t.overdue()?RED:BLUE)));x.addView(r);gap(x,6);
            x.addView(txt(t.content,15,MUTED,false));if("pending".equals(t.status)){gap(x,9);x.addView(softButton("标记已完成",v->completeTask(t,id)),lp(-1,-2));}addCard(body,x);}
        body.addView(button("＋ 设置下次联系提醒",false,v->showTaskForm(id)),lp(-1,-2));gap(body,20);
        TextView delete=txt("删除这位客户及其全部记录",14,RED,false);delete.setGravity(Gravity.CENTER);pad(delete,10,12,10,12);
        delete.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("确认删除客户？")
            .setMessage("将永久删除该客户的资料、跟进历史和提醒。此操作不可撤销，建议先备份。")
            .setNegativeButton("取消",null).setPositiveButton("确认删除",(d,w)->{
                for(Db.Task t:db.tasks("全部",id))ReminderScheduler.cancel(this,t.id);
                db.deleteClient(id);toast("客户已删除");showClients("",null,null);
            }).show());body.addView(delete,lp(-1,-2));
    }
    private void completeTask(Db.Task t,long openClientId){db.completeTask(t.id);ReminderScheduler.cancel(this,t.id);toast("跟进任务已完成");if(openClientId>0)showClient(openClientId);else showTasks("待处理");}
    private void requestNotifications(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQUEST_NOTICE);}
    private void showFollowForm(long clientId){Db.Client c=db.client(clientId);if(c==null)return;currentClientId=clientId;screen("添加跟进记录","follow_form",false);
        section(c.displayName()+" · 本次沟通");EditText content=field(body,"沟通内容", "",true,false);
        final long[] due={0};TextView pick=softButton("＋ 设置下次跟进时间（选填）",null);
        pick.setOnClickListener(v->dateTime(due[0],value->{due[0]=value;pick.setText("下次联系："+date(value));}));body.addView(pick,lp(-1,-2));gap(body,14);
        EditText note=field(body,"下次跟进事项（设置时间后选填）","",true,false);
        body.addView(button("保存跟进记录",true,v->{String text=content.getText().toString().trim();if(text.isEmpty()){toast("请填写本次沟通内容");return;}
            if(due[0]>0 && due[0]<=System.currentTimeMillis()){toast("下次联系时间应晚于现在");return;}
            try{db.addFollow(clientId,text);if(due[0]>0){long id=db.addTask(clientId,due[0],note.getText().toString().trim());ReminderScheduler.schedule(this,db.task(id));requestNotifications();}
                toast("跟进记录已保存");showClient(clientId);
            }catch(Exception e){error("保存跟进失败",e);}
        }),lp(-1,-2));
    }
    private void showTaskForm(long clientId){showTaskForm(clientId,null,false);}
    private void showTaskForm(long clientId,boolean fromList){showTaskForm(clientId,null,fromList);}
    private void showTaskForm(long clientId,Db.Task editing,boolean fromList){
        Db.Client c=db.client(clientId);if(c==null)return;currentClientId=clientId;
        editingTaskId=editing==null?0:editing.id;taskFormFromList=fromList;
        screen(editing==null?"添加跟进提醒":"修改跟进提醒","task_form",false);
        LinearLayout welcome=card();welcome.addView(iconRow("user","提醒客户："+c.displayName(),TEAL,17));gap(welcome,8);
        welcome.addView(txt("填写提醒事项、选择时间，点击保存即可。",14,MUTED,false));addCard(body,welcome);
        EditText content=field(body,"提醒事项（例如：询问装修报价）",editing==null?"":editing.content,true,false);
        long initial=editing==null?0:editing.dueAt;final long[] due={initial};
        TextView pick=softButton(initial>0?"提醒时间："+date(initial):"＋ 选择提醒日期和时间",null);
        pick.setOnClickListener(v->dateTime(due[0],value->{due[0]=value;pick.setText("提醒时间："+date(value));}));body.addView(pick,lp(-1,-2));gap(body,12);
        body.addView(txt("到期通过手机通知提醒；实际送达时间可能受到系统省电设置影响。",13,MUTED,false));gap(body,14);
        body.addView(button(editing==null?"保存提醒":"保存修改",true,v->{
            if(due[0]<=System.currentTimeMillis()){toast("请选择未来的提醒日期和时间");return;}
            try{
                String note=content.getText().toString().trim();
                long taskId;
                if(editing!=null){db.updateTask(editing.id,due[0],note);ReminderScheduler.cancel(this,editing.id);taskId=editing.id;}
                else taskId=db.addTask(clientId,due[0],note);
                ReminderScheduler.schedule(this,db.task(taskId));requestNotifications();toast("提醒已保存");
                if(editing!=null)showTaskDetail(taskId);else if(fromList)showTasks("待处理");else showClient(clientId);
            }catch(Exception e){error("保存提醒失败",e);}
        }),lp(-1,-2));
    }
    private void showPickReminderClient(){currentClientId=0;screen("选择提醒客户","reminder_picker",false);
        LinearLayout hint=card();hint.addView(txt("先选择客户，再填写提醒事项和时间。",16,INK,true));addCard(body,hint);
        EditText search=new EditText(this);search.setTextColor(INK);search.setTextSize(16*FONT_SCALES[fontIndex]);
        search.setSingleLine(true);search.setHint("输入客户姓名、电话或小区搜索");search.setBackground(shape(WHITE,12,LINE));pad(search,13,9,13,9);
        body.addView(search,lp(-1,-2));gap(body,12);
        LinearLayout results=vertical();body.addView(results,lp(-1,-2));
        Runnable refresh=()->{
            results.removeAllViews();List<Db.Client> clients=db.clients(search.getText().toString(),null,null);
            int limit=Math.min(80,clients.size());
            for(int i=0;i<limit;i++){
                Db.Client client=clients.get(i);LinearLayout item=card();LinearLayout top=horizontal();
                top.addView(icon("user",TEAL,23),lp(23,23));TextView label=txt(client.displayName()+"  ›",17,INK,true);
                LinearLayout.LayoutParams lineLp=new LinearLayout.LayoutParams(0,-2,1);lineLp.leftMargin=dp(10);top.addView(label,lineLp);
                item.addView(top,lp(-1,-2));gap(item,5);
                item.addView(txt((client.community.isEmpty()?"未填写小区":client.community)+(client.phone.isEmpty()?"":" · "+client.phone),13,MUTED,false));
                item.setOnClickListener(v->showTaskForm(client.id,true));addCard(results,item);
            }
            if(clients.isEmpty()){
                LinearLayout empty=card();empty.addView(txt("没有匹配的客户，请先新增客户。",15,MUTED,false));gap(empty,10);
                empty.addView(button("＋ 新增客户",true,v->showClientForm(null)),lp(-1,-2));addCard(results,empty);
            }else if(clients.size()>limit){results.addView(txt("还有更多客户，请输入姓名或电话缩小范围",14,MUTED,false));}
        };
        search.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){refresh.run();}
            @Override public void afterTextChanged(Editable e){}
        });
        refresh.run();
    }
    private void showTaskDetail(long taskId){Db.Task t=db.task(taskId);if(t==null){showTasks(lastTaskMode);return;}
        currentClientId=t.clientId;screen("提醒详情","task_detail",false);
        LinearLayout summary=card();LinearLayout row=horizontal();row.addView(icon("bell",TEAL,24),lp(24,24));
        TextView title=txt(t.clientName,20,INK,true);LinearLayout.LayoutParams nameLp=new LinearLayout.LayoutParams(0,-2,1);nameLp.leftMargin=dp(10);row.addView(title,nameLp);
        row.addView(pill("done".equals(t.status)?"已完成":(t.overdue()?"已逾期":"待跟进"),"done".equals(t.status)?TEAL:(t.overdue()?RED:BLUE)));
        summary.addView(row,lp(-1,-2));separator(summary);
        info(summary,"所在小区",t.community);info(summary,"提醒事项",t.content.isEmpty()?"联系客户":t.content);
        info(summary,"提醒时间",date(t.dueAt));addCard(body,summary);
        if("pending".equals(t.status)){
            body.addView(button("✓ 标记已完成",true,v->{db.completeTask(t.id);ReminderScheduler.cancel(this,t.id);toast("提醒已完成");showTasks(lastTaskMode);}),lp(-1,-2));gap(body,10);
            body.addView(softButton("修改提醒时间或事项",v->showTaskForm(t.clientId,t,true)),lp(-1,-2));gap(body,10);
        }
        body.addView(softButton("查看客户档案",v->showClient(t.clientId)),lp(-1,-2));gap(body,10);
        body.addView(softButton("＋ 再添加提醒",v->showTaskForm(t.clientId,true)),lp(-1,-2));
    }
    private void reminderFilters(String mode){
        String[][] options={{"今天","待处理"},{"已完成","全部"}};
        for(String[] rowItems:options){LinearLayout row=horizontal();
            for(String option:rowItems){TextView chip=softButton(option,v->showTasks(option));
                if(option.equals(mode))chip.setBackground(shape(Color.rgb(218,247,243),12,0));
                LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(0,-2,1);params.rightMargin=dp(6);row.addView(chip,params);
            }
            LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(7);body.addView(row,p);
        }
    }
    private void showTasks(String mode){lastTaskMode=mode;currentClientId=0;screen("跟进提醒","tasks",true);
        body.addView(button("＋ 添加提醒",true,v->showPickReminderClient()),lp(-1,-2));gap(body,12);
        reminderFilters(mode);
        gap(body,11);
        List<Db.Task> tasks=db.tasks("今天".equals(mode)?"待处理":mode,0);
        Calendar tomorrow=Calendar.getInstance();tomorrow.set(Calendar.HOUR_OF_DAY,0);tomorrow.set(Calendar.MINUTE,0);tomorrow.set(Calendar.SECOND,0);tomorrow.set(Calendar.MILLISECOND,0);tomorrow.add(Calendar.DAY_OF_MONTH,1);
        long cutoff=tomorrow.getTimeInMillis();int visible=0;
        for(Db.Task t:tasks){if("今天".equals(mode)&&t.dueAt>=cutoff)continue;visible++;
            LinearLayout card=card();LinearLayout line=horizontal();line.addView(icon("calendar",TEAL,22),lp(22,22));
            TextView name=txt(t.clientName,17,INK,true);LinearLayout.LayoutParams nm=new LinearLayout.LayoutParams(0,-2,1);nm.leftMargin=dp(8);line.addView(name,nm);
            line.addView(pill("done".equals(t.status)?"已完成":(t.overdue()?"已逾期":"待跟进"),"done".equals(t.status)?TEAL:(t.overdue()?RED:BLUE)));
            card.addView(line,lp(-1,-2));gap(card,10);
            card.addView(txt(t.content.isEmpty()?"联系客户":t.content,16,INK,false));gap(card,7);
            card.addView(txt((t.community==null||t.community.isEmpty()?"未填写小区":t.community)+" · "+date(t.dueAt),13,t.overdue()?RED:MUTED,false));gap(card,9);
            card.addView(txt("点击查看提醒详情  ›",13,BLUE,true));
            card.setOnClickListener(v->showTaskDetail(t.id));card.setClickable(true);card.setFocusable(true);
            addCard(body,card);
        }
        if(visible==0){LinearLayout empty=card();empty.addView(txt("暂时没有提醒，点击上方“添加提醒”即可新建。",15,MUTED,false));addCard(body,empty);}
    }
    private void showStats(){currentClientId=0;screen("统计与备份","mine",true);Calendar[] bounds=monthBounds();Db.Stats s=db.stats(bounds[0].getTimeInMillis(),bounds[1].getTimeInMillis());
        section("业绩统计（本月）");
        metricGrid(new String[]{"本月签约客户","签约总金额","预计提成","已收提成"},
            new String[]{""+s.monthSigned,yuan(s.monthAmount),yuan(s.monthExpected),yuan(s.monthReceived)},
            new int[]{BLUE,TEAL,Color.rgb(197,127,25),Color.rgb(128,82,190)},
            new View.OnClickListener[]{v->showMonthSignedClients("mine"),v->showMonthSignedClients("mine"),
                v->showMonthSignedClients("mine"),v->showMonthSignedClients("mine")});
        section("数据管理");
        LinearLayout menu=card();
        menu.addView(menuItem("cloud","完整备份","将全部客户与跟进记录备份到本地",v->saveFile("backup","application/json","装修客户管家备份_"+System.currentTimeMillis()+".json")));
        separator(menu);menu.addView(menuItem("database","恢复数据","从备份文件恢复客户资料",v->restoreFile()));
        separator(menu);menu.addView(menuItem("excel","导出 Excel","导出客户、跟进及业绩表格",v->saveFile("xlsx","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","装修客户报表_"+System.currentTimeMillis()+".xlsx")));
        separator(menu);menu.addView(menuItem("mobile","换手机迁移","先备份，再将文件传到新手机并恢复",v->showSettings()));
        addCard(body,menu);
        body.addView(button("字体大小与更多设置",false,v->showSettings()),lp(-1,-2));
    }
    private LinearLayout menuItem(String iconName,String title,String sub,View.OnClickListener click){LinearLayout r=horizontal();pad(r,0,9,0,9);
        LinearLayout circle=vertical();circle.setGravity(Gravity.CENTER);circle.setBackground(shape(Color.rgb(228,242,255),13,0));circle.addView(icon(iconName,BLUE,24),lp(24,24));r.addView(circle,lp(44,44));
        LinearLayout words=vertical();words.addView(txt(title,16,INK,true));gap(words,3);words.addView(txt(sub,12,MUTED,false));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.leftMargin=dp(12);r.addView(words,p);r.addView(icon("arrow",MUTED,17),lp(17,17));r.setOnClickListener(click);return r;}
    private void showSettings(){currentClientId=0;screen("设置与数据管理","settings",false);
        section("字体大小 · 全软件统一生效");
        LinearLayout card=card();for(int i=0;i<FONT_LABELS.length;i++){
            final int idx=i;String mark=i==fontIndex?"●  ":"○  ";TextView t=txt(mark+FONT_LABELS[i],i==fontIndex?19:17,i==fontIndex?TEAL:INK,i==fontIndex);
            t.setMinHeight(dp(53));t.setOnClickListener(v->{fontIndex=idx;getPreferences(0).edit().putInt("font_size",idx).apply();showSettings();});card.addView(t,lp(-1,-2));if(i<FONT_LABELS.length-1)separator(card);
        }addCard(body,card);
        section("客户数据");
        LinearLayout data=card();data.addView(button("完整备份（JSON）",true,v->saveFile("backup","application/json","装修客户管家备份_"+System.currentTimeMillis()+".json")),lp(-1,-2));gap(data,10);
        data.addView(button("恢复备份数据",false,v->restoreFile()),lp(-1,-2));gap(data,10);
        data.addView(button("导出Excel（.xlsx）",false,v->saveFile("xlsx","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","装修客户报表_"+System.currentTimeMillis()+".xlsx")),lp(-1,-2));gap(data,12);
        data.addView(txt("换手机：旧手机生成完整备份文件 → 将文件传到新手机 → 新手机安装应用并选择“恢复备份数据”。恢复会替换新手机中已有数据，请先备份。",14,MUTED,false));
        addCard(body,data);
        LinearLayout info=card();info.addView(txt("隐私与提醒",17,INK,true));gap(info,8);
        info.addView(txt("客户资料只存储在手机本地；应用不申请联网权限。导出的备份和Excel含个人信息，请妥善保管。",14,MUTED,false));gap(info,8);
        info.addView(txt("通知提醒需要系统通知权限，部分手机的省电设置可能延迟通知。",14,MUTED,false));gap(info,12);
        info.addView(softButton("检查并申请通知权限",v->requestNotifications()),lp(-1,-2));addCard(body,info);
    }
    private void saveFile(String op,String type,String suggestedName){fileOperation=op;Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType(type);intent.putExtra(Intent.EXTRA_TITLE,suggestedName);startActivityForResult(intent,REQUEST_FILE);}
    private void restoreFile(){fileOperation="restore";Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");startActivityForResult(intent,REQUEST_FILE);}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
        if(request!=REQUEST_FILE||result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();String op=fileOperation;fileOperation="";
        if("restore".equals(op)){
            new AlertDialog.Builder(this).setTitle("确认恢复数据？")
                .setMessage("恢复会替换本手机的全部客户资料、跟进记录及提醒。建议先完成一次完整备份。")
                .setNegativeButton("取消",null).setPositiveButton("确认恢复",(dialog,which)->performFile(op,uri)).show();
        }else performFile(op,uri);
    }
    private void performFile(String operation,Uri uri){
        try{
            if("restore".equals(operation)){
                try(InputStream in=getContentResolver().openInputStream(uri)){
                    if(in==null)throw new Exception("无法打开备份文件");Transfer.restore(this,db,in);
                }
                toast("恢复完成，客户和跟进记录已重新导入");showHome();
            }else{
                try(OutputStream out=getContentResolver().openOutputStream(uri,"w")){
                    if(out==null)throw new Exception("无法创建导出文件");if("xlsx".equals(operation))Transfer.exportExcel(db,out);else Transfer.backup(db,out);
                }
                new AlertDialog.Builder(this).setTitle("导出成功").setMessage("文件已保存到刚才选择的位置。请妥善保管客户资料。")
                    .setPositiveButton("确定",null).show();
            }
        }catch(Exception ex){error("文件处理失败，原有资料未主动清空",ex);}
    }
    private void error(String prefix,Exception e){new AlertDialog.Builder(this).setTitle(prefix).setMessage(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()).setPositiveButton("确定",null).show();}
    private void toast(String text){Toast.makeText(this,text,Toast.LENGTH_SHORT).show();}
}
