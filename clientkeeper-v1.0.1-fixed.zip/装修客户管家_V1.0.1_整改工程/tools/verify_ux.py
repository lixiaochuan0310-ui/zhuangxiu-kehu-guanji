"""UI流程静态契约：需在APK真机验证，不能代替编译与交互测试。"""
from pathlib import Path
p=Path(__file__).resolve().parents[1]
s=(p/'app/src/main/java/com/decor/clientmanager/MainActivity.java').read_text()
icons=(p/'app/src/main/java/com/decor/clientmanager/UiIcon.java')
assert icons.is_file(), '需有可绘制的图标类，不能仅使用文字按钮'
for phrase in ('showContractForm(', 'changeStage(', 'changeIntent(', '客户来源', 'showSourceChoices(', '更新业务进展', '更新客户意向', '登记签约与提成', '本月签约'):
    assert phrase in s, f'缺少 {phrase}'
form=s[s.index('private void showClientForm('):s.index('private void saveClientAndOpen(')]
assert '合同金额' not in form and '提成比例' not in form and '已收到提成' not in form, '新增/编辑基本资料中不得出现签约财务字段'
assert 'selectField(extras,"业务进展"' not in form, '基本资料里不能藏进展选项'
assert 'selectField(extras,"客户意向"' not in form, '基本资料里不能藏意向选项'
assert 'sourceChoiceIcon' in s, '需要客户来源图标'
assert 'chip.setMinHeight(dp(45));' not in s and 'chip.setMinimumHeight(dp(45));' in s, 'LinearLayout 必须调用 setMinimumHeight，不能调用不存在的 setMinHeight'
assert 'showHome()' in s and '今日待跟进' in s
assert '"工作台","客户","提醒","我的"' in s
assert 'UiIcon' in s
assert 'cols=fontIndex>=2?2:3' in s, '大字体时客户来源需要两列，避免挤压'
assert 'if(fontIndex>=2){header.addView(stage' in s, '大字体时客户快捷操作改为垂直排列'
assert 'case "待判断":return BLUE;' in s
print('PASS: 来源图标/状态快捷操作/合同独立入口/首页导航/配色静态契约')
