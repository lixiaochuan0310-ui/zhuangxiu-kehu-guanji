"""Regression: stale backup appears first on reminder tab; source metrics drill into matching month/client records."""
from pathlib import Path
import sqlite3, re
base=Path(__file__).resolve().parents[1]
main=(base/'app/src/main/java/com/decor/clientmanager/MainActivity.java').read_text(encoding='utf-8')
db=(base/'app/src/main/java/com/decor/clientmanager/Db.java').read_text(encoding='utf-8')
home=main.split('private void showHome()',1)[1].split('private void showBackupNoticeIfNeeded()',1)[0]
tasks=main.split('private void showTasks(String mode)',1)[1].split('private void selectReportingMonth()',1)[0]
source=main.split('private void showSourceStatistics()',1)[1].split('private LinearLayout menuItem(',1)[0]
assert '最近7天没有备份客户资料' not in home, 'backup reminder must not appear in home'
assert 'showBackupNoticeIfNeeded()' in tasks, 'tasks page missing backup notice'
assert tasks.index('showBackupNoticeIfNeeded()') < tasks.index('＋ 添加提醒'), 'backup notice must be above task controls'
assert 'tile.setOnClickListener(v->{sourceNewLimit=60;sourceSignedLimit=60;showSourceClientDetails(item.source);}' in source, 'each source row must be actionable'
assert 'showSourceClientDetails(' in main and 'source_clients' in main, 'source-specific customer details missing'
assert 'clientsAcquiredFromSourceMonth(' in db and 'clientsSignedFromSourceMonth(' in db, 'source lists must respect acquired/signed month'
assert '"client".equals(currentPage)' in main and 'sourceDrilldownOpen' in main, 'back navigation must restore the source list'
# Test the intended SQL selections against real SQLite, including an old customer signing this month and duplicate contracts.
schema=re.search(r'static final String CLIENT_TABLE="([^"]+)";',db).group(1)
schema_contract=re.search(r'static final String CONTRACT_TABLE="([^"]+)";',db).group(1)
c=sqlite3.connect(':memory:')
c.execute(schema);c.execute(schema_contract)
for id,source,acquired in [(1,'门店',150),(2,'门店',160),(3,'门店',50),(4,'电话',170)]:
 c.execute('INSERT INTO clients(id,name,source,created_at,updated_at,acquired_at) VALUES (?,?,?,?,?,?)',(id,'客户'+str(id),source,acquired,acquired,acquired))
for cid,ts in [(1,130),(1,180),(3,175),(4,185)]:
 c.execute('INSERT INTO contracts(client_id,signed_at,amount,commission_type) VALUES (?,?,?,?)',(cid,ts,100,'percent'))
# Selected month has 100<=timestamp<200
new=[x[0] for x in c.execute('SELECT id FROM clients WHERE source=? AND acquired_at>=? AND acquired_at<? ORDER BY acquired_at DESC,id DESC LIMIT ?',('门店',100,200,60))]
signed=[x[0] for x in c.execute('SELECT clients.id FROM clients JOIN contracts ON clients.id=contracts.client_id WHERE clients.source=? AND contracts.signed_at>=? AND contracts.signed_at<? GROUP BY clients.id ORDER BY MAX(contracts.signed_at) DESC,clients.id DESC LIMIT ?',('门店',100,200,60))]
assert new==[2,1],new
assert signed==[1,3],signed
print('PASS source-scoped monthly drilldown and backup notification placement contract')
