#!/usr/bin/env python3
"""真实 SQLite 数据逻辑回归＋XML、编译配置静态审计；不代替 Android APK 编译。"""
from pathlib import Path
import re, sqlite3, xml.etree.ElementTree as ET
P=Path(__file__).resolve().parents[1]
code=(P/'app/src/main/java/com/decor/clientmanager/Db.java').read_text()
main=(P/'app/src/main/java/com/decor/clientmanager/MainActivity.java').read_text()
transfer=(P/'app/src/main/java/com/decor/clientmanager/Transfer.java').read_text()
for file in (P/'app/src/main').rglob('*.xml'):ET.parse(file)
assert 'android.permission.INTERNET' not in (P/'app/src/main/AndroidManifest.xml').read_text()

def sql_constant(key):
 m=re.search(r'static final String '+key+r'="([^"]+)";',code);assert m,key;return m.group(1)

def create_v3():
 db=sqlite3.connect(':memory:');db.execute('PRAGMA foreign_keys=ON');
 for name in ('CLIENT_TABLE','CONTRACT_TABLE','RECEIPT_TABLE'):db.execute(sql_constant(name))
 for stmt in re.findall(r'd\.execSQL\("(CREATE (?:TABLE|INDEX) [^\"]+)"\)',code.split("@Override public void onUpgrade")[0]):
  # contracts & receipts are created from named SQL constants, not duplicate CREATEs.
  db.execute(stmt)
 return db

db=create_v3();db.execute('INSERT INTO clients(name,created_at,updated_at,acquired_at) VALUES (?,?,?,?)',('客户A',1,1,100))
for contract in [(1,1000,100000,'percent',3,0),(1,2000,80000,'fixed',0,2000)]:
 db.execute('INSERT INTO contracts(client_id,signed_at,amount,commission_type,commission_rate,fixed_commission) VALUES(?,?,?,?,?,?)',contract)
db.execute("INSERT INTO receipts(contract_id,received_at,amount) VALUES (1,3000,1000)")
db.execute("INSERT INTO receipts(contract_id,received_at,amount) VALUES (2,5000,2000)")
# Contract and receipt remain after changing business stage; distinct clients are not double-counted.
db.execute("UPDATE clients SET stage='暂不考虑' WHERE id=1")
assert db.execute('SELECT COUNT(*) FROM contracts').fetchone()[0]==2
assert db.execute('SELECT COUNT(DISTINCT client_id),SUM(amount),SUM(CASE WHEN commission_type=\'fixed\' THEN fixed_commission ELSE amount*commission_rate/100 END) FROM contracts WHERE signed_at>=? AND signed_at<?',(0,4000)).fetchone()==(1,180000,5000)
assert db.execute('SELECT SUM(amount) FROM receipts WHERE received_at>=? AND received_at<?',(3000,4000)).fetchone()[0]==1000
assert db.execute('SELECT SUM(amount) FROM receipts WHERE received_at>=? AND received_at<?',(4000,7000)).fetchone()[0]==2000
db.execute("INSERT INTO followups(client_id,happened_at,content) VALUES (1,1000,'历史沟通')")
db.execute("INSERT INTO reminders(client_id,due_at,content) VALUES (1,9000,'明日提醒')")
# Deleting customer cascades to all dependent records, never leaves orphaned invoices.
db.execute('DELETE FROM clients WHERE id=1')
for table in ('contracts','receipts','followups','reminders'):assert db.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0]==0,table
# Simulate migration against the exact v2 schema fixture shipped inside this project.
legacy=sqlite3.connect(':memory:');legacy.execute('PRAGMA foreign_keys=ON')
legacy.executescript((P/'tools/legacy_v2.sql').read_text())
legacy.execute("INSERT INTO clients(name,created_at,updated_at,stage,signed_at,contract_amount,commission_rate,received_amount) VALUES('老客户',1,1,'已签约',500,120000,3,1200)")
legacy.execute("INSERT INTO followups(client_id,happened_at,content) VALUES(1,100,'跟进保留')")
legacy.execute("INSERT INTO reminders(client_id,due_at,content) VALUES(1,100,'提醒保留')")
legacy.execute("ALTER TABLE clients ADD COLUMN acquired_at INTEGER NOT NULL DEFAULT 0")
legacy.execute("UPDATE clients SET acquired_at=created_at")
legacy.execute(sql_constant('CONTRACT_TABLE'));legacy.execute(sql_constant('RECEIPT_TABLE'))
for sql in re.findall(r'd\.execSQL\("(INSERT INTO (?:contracts|receipts)\([^\"]+)"\)',code):legacy.execute(sql)
assert legacy.execute('SELECT COUNT(*) FROM contracts').fetchone()[0]==1
assert legacy.execute('SELECT COUNT(*),SUM(amount),MIN(received_at) FROM receipts').fetchone()==(1,1200,0)
assert legacy.execute('SELECT content FROM followups').fetchone()[0]=='跟进保留'
assert legacy.execute('SELECT content FROM reminders').fetchone()[0]=='提醒保留'
assert legacy.execute('SELECT acquired_at FROM clients').fetchone()[0]==1
legacy.execute("ALTER TABLE clients ADD COLUMN gender TEXT NOT NULL DEFAULT '未选择'")
assert legacy.execute('SELECT gender FROM clients').fetchone()[0]=='未选择'
# Also verify a v1 schema with no commission_type/fixed_commission columns survives 1->2->3.
v1schema=(P/'tools/legacy_v2.sql').read_text().replace(", commission_type TEXT NOT NULL DEFAULT 'percent', fixed_commission REAL NOT NULL DEFAULT 0", "")
assert 'commission_type' not in v1schema, 'v1 schema fixture unexpectedly contains V2 columns'
v1=sqlite3.connect(':memory:');v1.execute('PRAGMA foreign_keys=ON');v1.executescript(v1schema)
v1.execute("INSERT INTO clients(name,created_at,updated_at,stage,signed_at,contract_amount,commission_rate,received_amount) VALUES('v1客户',3,3,'已签约',900,30000,2,300)")
v1.execute("ALTER TABLE clients ADD COLUMN commission_type TEXT NOT NULL DEFAULT 'percent'")
v1.execute("ALTER TABLE clients ADD COLUMN fixed_commission REAL NOT NULL DEFAULT 0")
v1.execute("ALTER TABLE clients ADD COLUMN acquired_at INTEGER NOT NULL DEFAULT 0")
v1.execute("UPDATE clients SET acquired_at=created_at")
v1.execute(sql_constant('CONTRACT_TABLE'));v1.execute(sql_constant('RECEIPT_TABLE'))
for sql in re.findall(r'd\.execSQL\("(INSERT INTO (?:contracts|receipts)\([^\"]+)"\)',code):v1.execute(sql)
assert v1.execute("SELECT amount,commission_type,commission_rate FROM contracts").fetchone()==(30000,'percent',2)
assert v1.execute("SELECT received_at,amount FROM receipts").fetchone()==(0,300)
assert v1.execute("SELECT acquired_at FROM clients").fetchone()[0]==3
v1.execute("ALTER TABLE clients ADD COLUMN gender TEXT NOT NULL DEFAULT '未选择'")
assert v1.execute('SELECT gender FROM clients').fetchone()[0]=='未选择'
# Verify known static regression hazards
assert 'if(!"已签约".equals(c.stage)) c.signedAt=0' not in code
assert 'db.getContracts' in main and 'db.receiptsMonth' in main and 'showMonthReceipts' in main
assert 'dateOnly(acquiredAt[0]' in main and 'happenedAt[0]' in main
assert 'data.put("version",4)' in transfer
assert 'd.beginTransaction()' in transfer and 'd.setTransactionSuccessful()' in transfer
assert 'importExcel(Db db' in transfer and 'ZipInputStream' in transfer
assert 'case "待判断":return BLUE;' in main
print('PASS: XML、SQLite建表及旧库迁移、不同月份合同和到账、删除联动、无联网权限、备份契约')

# Priority ordering is compiled from the same Java class used in the app.
import subprocess,sys
subprocess.run([sys.executable,str(P/"tools/verify_priority.py")],check=True)

subprocess.run([sys.executable,str(P/"tools/verify_v105_ui.py")],check=True)

subprocess.run([sys.executable,str(P/"tools/verify_v105_data.py")],check=True)

# Current version regression is deliberately chained into verify_project.py: the published GitHub ZIP wrapper invokes this file.
subprocess.run([sys.executable,str(P/"tools/verify_v106.py")],check=True)
subprocess.run([sys.executable,str(P/"tools/verify_v112_navigation.py")],check=True)
