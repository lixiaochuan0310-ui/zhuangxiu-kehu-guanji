"""V1.1.1 layout/navigation regression checks for approved UX changes."""
from pathlib import Path
s = (Path(__file__).resolve().parents[1] / 'app/src/main/java/com/decor/clientmanager/MainActivity.java').read_text(encoding='utf-8')
grad = s[s.index('private LinearLayout gradientHeading('):s.index('private Calendar[] monthBounds()')]
assert 'GradientDrawable.Orientation.LEFT_RIGHT' in grad
home = s[s.index('private void showHome()'):s.index('private void showMonthSignedClients(')]
assert '今日工作安排' not in home, 'duplicate schedule entry must be removed from home'
assert 'gradientHeading("今日待跟进（' in home
assert 'gradientHeading("我的客户与业绩"' in home
assert 'homePriorityTasks(3,' in home and 'homeQuickAdd();' in home
clients = s[s.index('private void showClients(String search,String stage,String intent,String source,int requestedLimit)'):s.index('private static String[] concat(')]
assert '客户来源统计' in clients and 'showSourceStatistics()' in clients, 'source stats must be reachable from clients page'
stat = s[s.index('private void showStats()'):s.index('private void showSourceStatistics()')]
assert '近6个月签约业绩趋势' in stat
assert stat.index('近6个月签约业绩趋势') < stat.index('metricGrid('), 'trend chart must be above KPI cards'
assert '客户来源统计' not in stat, 'source stats cannot remain in my/stats page'
assert 'section("数据管理")' not in stat and 'menuItem("cloud"' not in stat and 'menuItem("excel"' not in stat, 'no duplicate data management on my page'
assert 'screen("业绩统计","mine",true)' in stat
settings = s[s.index('private void showSettings()'):s.index('private void saveFile(')]
for name in ('完整备份（JSON）', '恢复备份数据', '导出Excel（.xlsx）', '导入Excel客户资料'):
    assert name in settings, f'settings must retain {name}'
assert 'showClients(savedClientSearch,savedClientStage,savedClientIntent,savedClientSource)' in s[s.index('public void onBackPressed()'):s.index('private int dp(')]
assert '"source_stats".equals(page)?"clients":page' in s, 'customer tab selected in source statistics'
source = s[s.index('private void showSourceStatistics()'):s.index('private LinearLayout menuItem(')]
assert 'selectSourceMonth()' in source and 'sourceMiniChart(amounts)' in source
build = (Path(__file__).resolve().parents[1] / 'app/build.gradle').read_text()
assert "versionName '1.1.2'" in build
assert 'versionCode 13' in build
print('PASS V1.1.1 navigation, gradient, source statistics, and settings scope')
