"""Regression: the customer page has exactly two side-by-side filters at all font sizes,
without a redundant source filter; My has no duplicate settings control."""
from pathlib import Path
import re
s=(Path(__file__).resolve().parents[1]/'app/src/main/java/com/decor/clientmanager/MainActivity.java').read_text(encoding='utf-8')
clients=s.split('private void showClients(String search,String stage,String intent,String source,int requestedLimit)',1)[1].split('private static String[] concat(',1)[0]
assert '全部来源 ▾' not in clients, 'client list still shows redundant source filter'
assert 'bySource' not in clients, 'client source filter control still exists'
assert '客户来源统计' in clients and 'showSourceStatistics()' in clients, 'source statistics must remain accessible'
assert 'if(fontIndex>=2)' not in clients, 'font size must not turn two filters into stacked rows'
assert 'f.addView(byStage,new LinearLayout.LayoutParams(0,dp(52),1))' in clients
assert 'f.addView(byIntent,p)' in clients
assert 'body.addView(f,lp(-1,-2))' in clients
assert 'savedClientSource=null;' in clients, 'stale source filter must not silently filter customers'
assert 'db.clientsPage(search,stage,intent,clientSourceFilter,clientListLimit,0)' in clients
assert 'db.clientsCount(search,stage,intent,clientSourceFilter)' in clients
stats=s.split('private void showStats()',1)[1].split('private void selectSourceMonth()',1)[0]
assert 'showSettings()' not in stats and '设置与字体大小' not in stats, 'My page still repeats settings'
settings=s.split('private void showSettings()',1)[1].split('private void saveFile(',1)[0]
assert 'FONT_LABELS' in settings and '完整备份（JSON）' in settings
print('PASS: unified V1.1.2 customer filters and single settings entry')
