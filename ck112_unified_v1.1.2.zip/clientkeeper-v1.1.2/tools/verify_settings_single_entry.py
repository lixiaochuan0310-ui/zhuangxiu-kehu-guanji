"""Only home gear opens settings; My/Stats page must not duplicate settings or font controls."""
from pathlib import Path
src = (Path(__file__).resolve().parents[1] / 'app/src/main/java/com/decor/clientmanager/MainActivity.java').read_text(encoding='utf-8')
home = src[src.index('private void showHome()'):src.index('private void showMonthSignedClients(')]
settings = src[src.index('private void showSettings()'):src.index('private void saveFile(')]
stats = src[src.index('private void showStats()'):src.index('private void selectSourceMonth()')]
assert 'setOnClickListener(v->showSettings())' in src[:src.index('private void showHome()')], 'Home must retain settings gear'
assert '设置与字体大小' not in stats, 'My/Stats page still has duplicate settings/font button'
assert 'showSettings()' not in stats, 'My/Stats page still opens settings'
assert 'FONT_LABELS' in settings, 'Settings must contain font size choices'
for item in ['完整备份（JSON）','恢复备份数据','导出Excel（.xlsx）','导入Excel客户资料']:
    assert item in settings, f'Settings lost {item}'
print('PASS settings only from Home gear; no duplicate on My; font and data management retained')
