"""V1.0.10 visual behavior checks; source contracts, not screenshot proof."""
from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'app/src/main/java/com/decor/clientmanager/MainActivity.java').read_text(encoding='utf8')
# Four dashboard cards stay 2 x 2 at every font-size setting.
section=s[s.index('private void metricGrid(String[] names,String[] values,int[] colors,View.OnClickListener[] actions)'):s.index('private Calendar[] monthBounds()')]
assert 'int columns=2;' in section, 'Metric grid must remain two columns in all four text-size modes'
assert 'dp("home".equals(currentPage)?116:132)' in section, 'Card background height must be independent of font size'
assert 'tile.setMinimumHeight' not in section
# Source chart discoverable from customer management, not statistics/backup.
clients=s[s.index('private void showClients(String search,String stage,String intent,String source,int requestedLimit)'):s.index('private static String[] concat(')]
assert '客户来源统计' in clients and 'showSourceStatistics()' in clients
stats=s[s.index('private void showStats()'):s.index('private void selectSourceMonth()')]
assert '客户来源统计' not in stats
# Source dashboard visually follows approved mockup: donut with center count, percentages, icon-labeled source rows.
source=s[s.index('private void showSourceStatistics()'):s.index('private LinearLayout menuItem(')]
assert 'sourceMiniChart(amounts)' in source
assert 'sourceIcon(item.source)' in source
assert '占比' in source
assert '新增客户' in source and '签约客户' in source
assert 'reportingMonth.label()' in source
chart=s[s.index('private void sourceMiniChart('):s.index('private void homeHero()')]
assert 'SourceDonutView' in chart and 'SourcePalette.color(i)' in chart
assert '百分比' in chart
print('PASS V1.0.10 visual behavior source contract')
