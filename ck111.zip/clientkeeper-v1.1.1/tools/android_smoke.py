#!/usr/bin/env python3
"""GitHub Actions emulator smoke: launch the actual compiled APK and screenshot six entry screens.
Never inserts mock customer data into the release app.
"""
from pathlib import Path
import os,re,subprocess,time,xml.etree.ElementTree as ET
PKG='com.decor.clientmanager'
APK=os.environ.get('CLIENTKEEPER_DEBUG_APK','app/build/outputs/apk/debug/app-debug.apk')
DEST=Path(os.environ.get('CLIENTKEEPER_SCREENSHOT_DIR','build/verification-screens'))
DEST.mkdir(parents=True,exist_ok=True)

def adb(*args,check=True):
    run=subprocess.run(['adb',*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=check)
    return run.stdout

def screenshot(name):
    data=adb('exec-out','screencap','-p')
    if not data.startswith(b'\x89PNG'):
        raise RuntimeError('Screenshot did not return PNG bytes')
    (DEST/f'{name}.png').write_bytes(data)
    print('Screenshot:',name,len(data),'bytes')

def hierarchy():
    adb('shell','uiautomator','dump','/sdcard/window.xml')
    xml=adb('exec-out','cat','/sdcard/window.xml')
    return ET.fromstring(xml.decode('utf-8-sig').strip())

def find_text(text,allow_substr=False):
    for n in hierarchy().iter('node'):
        content=n.get('text','')
        if (text in content if allow_substr else text==content):
            bounds=n.get('bounds','')
            box=re.findall(r'\[(\d+),(\d+)\]',bounds)
            if len(box)==2:
                (x0,y0),(x1,y1)=map(lambda v:(int(v[0]),int(v[1])),box)
                return (x0+x1)//2,(y0+y1)//2
    return None

def click(label,search=False,scroll=False):
    for _ in range(7 if scroll else 1):
        xy=find_text(label,search)
        if xy:
            adb('shell','input','tap',str(xy[0]),str(xy[1]))
            time.sleep(2)
            return
        if scroll:
            adb('shell','input','swipe','550','1680','550','430','350')
            time.sleep(1)
    raise RuntimeError('Cannot find visible UI control: '+label)

def go_home():
    adb('shell','am','force-stop',PKG)
    adb('shell','am','start','-W','-n',PKG+'/.MainActivity')
    time.sleep(3)
    if not adb('shell','pidof',PKG).strip():
        raise RuntimeError('App is not running')

assert Path(APK).is_file(),f'APK missing: {APK}'
adb('install','-r',APK)
go_home();screenshot('01-home')
click('客户');screenshot('02-clients')
click('新增客户',search=True,scroll=True);screenshot('03-client-form')
go_home();click('提醒');screenshot('04-reminders')
go_home();click('我的');screenshot('05-statistics')
go_home();click('客户');click('客户来源统计',search=True,scroll=True);screenshot('06-source-statistics')
print('Android emulator smoke PASS: app installed and six screens opened')
