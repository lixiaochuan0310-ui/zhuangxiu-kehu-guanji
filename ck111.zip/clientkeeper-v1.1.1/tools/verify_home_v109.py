"""Visual-layout regression gates for the homepage requests (source-level)."""
from pathlib import Path

src = Path(__file__).resolve().parents[1] / 'app/src/main/java/com/decor/clientmanager/MainActivity.java'
s = src.read_text(encoding='utf-8')

# The dashboard must keep two columns even at the largest in-app type size.
start = s.index('private void metricGrid(String[] names,String[] values,int[] colors,View.OnClickListener[] actions)')
end = s.index('private Calendar[] monthBounds()', start)
grid = s[start:end]
assert 'int columns=2;' in grid, 'Dashboard must retain two columns at all font sizes'
assert 'Math.min(i+columns,names.length)' in grid, 'Do not lose any of the four cards'
assert 'statistic(names[j],values[j],colors[j])' in grid, 'Keep cards bound to their actual values'
assert 'dp("home".equals(currentPage)?116:132)' in grid, 'Card background size must stay fixed across font modes'

# Duplicate schedule entry is removed; the single today-reminder header has its own gradient.
start = s.index('private void showHome()')
end = s.index('private void showMonthSignedClients(', start)
home = s[start:end]
assert '今日工作安排' not in home, 'Do not display redundant schedule entry'
assert 'gradientHeading("今日待跟进（' in home, 'Today reminders need gradient heading'
assert 'gradientHeading("我的客户与业绩"' in home, 'Metrics need gradient heading'
assert 'homePriorityTasks(3,' in home, 'Never show more than 3 reminders on the dashboard'
assert 'homeQuickAdd()' in home, 'Keep pinned add-customer action'
assert '今日待跟进' in home, 'Keep the home reminder section'
assert '查看全部' in home, 'Keep the only view-all shortcut'
print('PASS: home 2x2 metrics, two gradient headings, three reminders, pinned add action')
