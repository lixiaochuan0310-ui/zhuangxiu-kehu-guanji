from pathlib import Path
import unittest
BASE=Path(__file__).resolve().parents[1]
SRC=BASE/'app/src/main/java/com/decor/clientmanager'
RES=BASE/'app/src/main/res/drawable-nodpi'
class Requirements(unittest.TestCase):
 def test_gender_persistence(self):
  d=(SRC/'Db.java').read_text()
  self.assertIn('gender TEXT NOT NULL',d)
  self.assertIn('c.gender',d)
  t=(SRC/'Transfer.java').read_text()
  self.assertIn('"gender"',t)
  self.assertIn('"未选择"',t)
 def test_real_avatars(self):
  for name in ('avatar_male.png','avatar_female.png','avatar_neutral.png'):self.assertTrue((RES/name).exists())
  a=(SRC/'MainActivity.java').read_text()
  self.assertIn('avatarView(',a)
 def test_priority_home(self):
  a=(SRC/'MainActivity.java').read_text()
  self.assertIn('homePriorityTasks(3,',a)
  self.assertIn('gradientHeading("今日待跟进（',a)
  self.assertIn('ReminderPriority', (SRC/'Db.java').read_text())
 def test_six_page_style(self):
  a=(SRC/'MainActivity.java').read_text()
  for word in ('sourceMiniChart','showTasks','showSourceStatistics','showStats','showClients','showClientForm','homeHero'):
   self.assertIn(word,a)
 def test_scope_source(self):
  d=(SRC/'Db.java').read_text()
  self.assertNotIn('"公司分配"',d)
if __name__=='__main__': unittest.main()
